# 実装計画: [機能]

**ブランチ**: `[###-feature-name]` | **日付**: [DATE] | **仕様**: [link]
**入力**: `/specs/[###-feature-name]/spec.md`からの機能仕様

**注**: このテンプレートは`/speckit.plan`コマンドによって記入されます。実行ワークフローについては`.specify/templates/commands/plan.md`を参照してください。

## サマリー

[機能仕様から抽出: 主要要件 + 研究からの技術的アプローチ]

## 技術的コンテキスト

<!--
  アクション必須: このセクションの内容をプロジェクトの技術詳細に置き換えてください。
  ここに示す構造は、反復プロセスをガイドするためのアドバイザリーな能力で提示されています。
-->

**言語/バージョン**: [例：Python 3.11、Swift 5.9、Rust 1.75 または明確化が必要]  
**主要依存関係**: [例：FastAPI、UIKit、LLVM または明確化が必要]  
**ストレージ**: [該当する場合、例：PostgreSQL、CoreData、ファイル または N/A]  
**テスト**: [例：pytest、XCTest、cargo test または明確化が必要]  
**ターゲットプラットフォーム**: [例：Linuxサーバー、iOS 15+、WASM または明確化が必要]
**プロジェクトタイプ**: [single/web/mobile - ソース構造を決定]  
**パフォーマンス目標**: [ドメイン固有、例：1000 req/s、10k lines/sec、60 fps または明確化が必要]  
**制約**: [ドメイン固有、例：<200ms p95、<100MBメモリ、オフライン対応 または明確化が必要]  
**スケール/スコープ**: [ドメイン固有、例：10kユーザー、1M LOC、50画面 または明確化が必要]

## 憲法チェック

*ゲート: フェーズ0の研究の前に合格する必要があります。フェーズ1の設計後に再チェックしてください。*

[憲法ファイルに基づいて決定されたゲート]

## プロジェクト構造

### ドキュメント（この機能）

```text
specs/[###-feature]/
├── plan.md              # このファイル（/speckit.planコマンドの出力）
├── research.md          # フェーズ0の出力（/speckit.planコマンド）
├── data-model.md        # フェーズ1の出力（/speckit.planコマンド）
├── quickstart.md        # フェーズ1の出力（/speckit.planコマンド）
├── contracts/           # フェーズ1の出力（/speckit.planコマンド）
└── tasks.md             # フェーズ2の出力（/speckit.tasksコマンド - /speckit.planでは作成されません）
```

### ソースコード（リポジトリルート）
<!--
  アクション必須: 以下のプレースホルダーツリーをこの機能の具体的なレイアウトに置き換えてください。
  未使用のオプションを削除し、選択した構造を実際のパス（例：apps/admin、packages/something）で展開してください。
  提供される計画にはオプションラベルを含めないでください。
-->

```text
# [REMOVE IF UNUSED] Option 1: Single project (DEFAULT)
src/
├── models/
├── services/
├── cli/
└── lib/

tests/
├── contract/
├── integration/
└── unit/

# [REMOVE IF UNUSED] Option 2: Web application (when "frontend" + "backend" detected)
backend/
├── src/
│   ├── models/
│   ├── services/
│   └── api/
└── tests/

frontend/
├── src/
│   ├── components/
│   ├── pages/
│   └── services/
└── tests/

# [REMOVE IF UNUSED] Option 3: Mobile + API (when "iOS/Android" detected)
api/
└── [same as backend above]

ios/ or android/
└── [platform-specific structure: feature modules, UI flows, platform tests]
```

**構造決定**: [選択された構造を文書化し、上記でキャプチャされた実際のディレクトリを参照]

## 複雑さの追跡

> **憲法チェックに正当化が必要な違反がある場合のみ記入**

| 違反 | 必要な理由 | より簡単な代替案が拒否された理由 |
|-----------|------------|-------------------------------------|
| [例：4番目のプロジェクト] | [現在の必要性] | [3つのプロジェクトが不十分な理由] |
| [例：リポジトリパターン] | [特定の問題] | [直接DBアクセスが不十分な理由] |
