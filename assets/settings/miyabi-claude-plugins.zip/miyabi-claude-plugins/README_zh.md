[![Built by 合同会社みやび](https://img.shields.io/badge/Built%20by-合同会社みやび-blue?style=flat-square&logo=github)](https://miyabi-ai.jp)

# Miyabi Plugins for Claude Code

[English](./README.md) | **中文** | [日本語](./README_ja.md)

![Downloads](https://img.shields.io/badge/Cloned_by-270%2B_developers-blue?style=for-the-badge)
![Stars](https://img.shields.io/github/stars/ShunsukeHayashi/miyabi-claude-plugins?style=for-the-badge&color=yellow)
![Forks](https://img.shields.io/github/forks/ShunsukeHayashi/miyabi-claude-plugins?style=for-the-badge&color=green)

完整的自主 AI 开发运维平台 — 将 Claude Code 打造成强大的开发助手，配备 25+ AI Agent、22 项技能和 50+ 命令。

## 目录

- [前提条件](#前提条件)
- [安装指南](#安装指南)
- [验证安装](#验证安装)
- [入门教程](#入门教程)
- [可用插件](#可用插件)
- [核心功能](#核心功能)
- [配置说明](#配置说明)
- [常见问题](#常见问题)
- [支持渠道](#支持渠道)

---

## 前提条件

安装 Miyabi 插件之前，请确保已具备：

### 必需

| 依赖 | 版本 | 检查命令 |
|------|------|----------|
| **Claude Code CLI** | 最新版 | `claude --version` |
| **Node.js** | 18.0+ | `node --version` |
| **npm** | 9.0+ | `npm --version` |

### 可选（完整功能）

| 依赖 | 用途 | 设置方法 |
|------|------|----------|
| **GitHub Token** | GitHub 集成（Issues、PRs） | [创建 Token](https://github.com/settings/tokens) |
| **tmux** | 多 Agent 编排 | `brew install tmux` (macOS) |

### 安装 Claude Code CLI

如果尚未安装 Claude Code CLI：

```bash
# 通过 npm 安装
npm install -g @anthropic-ai/claude-code

# 验证安装
claude --version
```

---

## 安装指南

### 步骤 1: 添加市场源

打开 Claude Code 并运行以下命令：

```bash
/plugin marketplace add ShunsukeHayashi/miyabi-claude-plugins
```

**预期输出：**
```
Marketplace 'miyabi-plugins' added successfully
  Source: https://github.com/ShunsukeHayashi/miyabi-claude-plugins
  Plugins available: 8
```

### 步骤 2: 安装插件

选择以下其中一个选项：

#### 选项 A: 完整包（推荐）

```bash
/plugin install miyabi-full@miyabi-plugins
```

包含所有内容：38 个 Agent、56 个命令、25 项技能、Hooks 和 MCP 集成。

#### 选项 B: 按需安装

```bash
# 编码自动化
/plugin install miyabi-coding-agents@miyabi-plugins

# 业务自动化
/plugin install miyabi-business-agents@miyabi-plugins

# 仅命令
/plugin install miyabi-commands@miyabi-plugins

# 仅技能
/plugin install miyabi-skills@miyabi-plugins
```

### 步骤 3: 重启 Claude Code

安装后，重启 Claude Code 以加载插件：

```bash
# 退出当前会话
/exit

# 启动新会话
claude
```

---

## 验证安装

### 检查已安装的插件

```bash
/plugin list
```

### 测试 MCP 连接

```bash
/miyabi-full:health-check
```

### 测试命令

```bash
/miyabi-full:dashboard
```

---

## 入门教程

### 教程 1: 你的第一个 Agent

让 Claude 使用 CodeGen Agent：

```
使用 CodeGen Agent 创建一个简单的 React 用户资料卡片组件。
```

### 教程 2: 运行命令

在 GitHub 上创建 Issue：

```bash
/miyabi-full:issue-create --title "Test issue" --body "Testing Miyabi integration"
```

### 教程 3: 使用技能

触发 git-workflow 技能：

```
帮我处理 git 工作流 — 我需要创建一个功能分支并提交更改。
```

### 教程 4: Agent 编排（进阶）

多 Agent 工作流：

```
使用 Coordinator Agent：
1. 分析当前代码库
2. 使用 CodeGen 生成代码改进
3. 使用 ReviewAgent 审查更改
4. 使用 PRAgent 创建 PR
```

---

## 可用插件

| 插件 | 描述 | 内容 |
|------|------|------|
| **miyabi-full** | 完整包（推荐） | 所有 Agent、技能、命令、Hooks |
| **miyabi-coding-agents** | 开发自动化 | 9 个编码 Agent |
| **miyabi-business-agents** | 业务自动化 | 16 个业务 Agent |
| **miyabi-commands** | 斜杠命令 | 50+ 命令 |
| **miyabi-skills** | 开发技能 | 22 项技能 |
| **miyabi-hooks** | 自动化 Hooks | Pre/Post 工具 Hooks |
| **miyabi-guardian** | 事件响应 | Guardian Agent |
| **miyabi-honoka** | 课程创作 | Udemy 专家 |

---

## 核心功能

### 编码 Agent（9 个）

| Agent | 用途 | 触发词 |
|-------|------|--------|
| **CoordinatorAgent** | 任务编排和委派 | "coordinate", "orchestrate" |
| **CodeGenAgent** | 代码生成 | "generate code", "implement" |
| **ReviewAgent** | 代码审查和质量 | "review", "check code" |
| **PRAgent** | Pull Request 管理 | "create PR", "merge" |
| **DeploymentAgent** | 部署自动化 | "deploy", "release" |
| **IssueAgent** | GitHub Issue 管理 | "create issue", "track" |
| **RefresherAgent** | 上下文刷新 | "refresh context" |
| **BatchIssueAgent** | 批量操作 | "batch process" |
| **AWSAgent** | AWS 操作 | "AWS", "cloud" |

### 业务 Agent（16 个）

| Agent | 用途 |
|-------|------|
| **MarketingAgent** | 营销策略和活动 |
| **SalesAgent** | 销售自动化和外联 |
| **CRMAgent** | 客户关系管理 |
| **YouTubeAgent** | YouTube 内容策略 |
| **AnalyticsAgent** | 数据分析和报告 |
| **ContentCreationAgent** | 内容生成 |
| **FunnelDesignAgent** | 销售漏斗设计 |
| **PersonaAgent** | 客户画像创建 |
| **SNSStrategyAgent** | 社交媒体策略 |
| 以及 7 个更多... | |

### 命令（50+）

```bash
# 开发
/miyabi-full:deploy          # 部署应用
/miyabi-full:pr-create       # 创建 Pull Request
/miyabi-full:issue-create    # 创建 Issue
/miyabi-full:health-check    # 系统健康检查
/miyabi-full:review          # 代码审查

# Git 操作
/miyabi-full:worktree-create # 创建 git worktree
/miyabi-full:worktree-list   # 列出 worktrees

# 自动化
/miyabi-full:agent-run       # 运行指定 Agent
/miyabi-full:codex           # Codex 集成
/miyabi-full:tmux-control    # tmux 会话控制
/miyabi-full:parallel-execute # 并行任务执行

# 监控
/miyabi-full:dashboard       # 项目仪表盘
/miyabi-full:logs            # 查看日志
/miyabi-full:quality-score   # 代码质量指标
```

### 技能（22 项）

| 类别 | 技能 |
|------|------|
| **开发** | rust-development, tdd-workflow, git-workflow |
| **质量** | security-audit, performance-analysis, debugging-troubleshooting |
| **文档** | documentation-generation, context-eng |
| **业务** | business-strategy-planning, market-research-analysis |
| **集成** | mcp-integration, tmux-iterm-integration |

---

## 配置说明

### 环境变量

在 shell 配置文件（`~/.zshrc` 或 `~/.bashrc`）中创建或更新：

```bash
# GitHub 集成必需
export GITHUB_TOKEN="your_github_personal_access_token"
export GITHUB_DEFAULT_OWNER="your_github_username_or_org"
export GITHUB_DEFAULT_REPO="your_default_repo"

# 高级功能可选
export GOOGLE_API_KEY="your_google_api_key"        # 图像生成
export DISCORD_BOT_TOKEN="your_discord_bot_token"  # Discord 集成
```

应用更改：

```bash
source ~/.zshrc  # 或 source ~/.bashrc
```

### GitHub Token 权限

创建 GitHub Token 时，请启用以下权限范围：

- `repo` - 完全控制私有仓库
- `workflow` - 更新 GitHub Action 工作流
- `read:org` - 读取组织成员信息

### MCP 服务器

`miyabi-full` 插件会自动配置以下 MCP 服务器：

| 服务器 | 描述 | 状态 |
|--------|------|------|
| `miyabi-mcp-bundle` | 172+ 工具（Git、GitHub、Docker、K8s 等） | 已启用 |
| `filesystem` | 文件系统访问 | 已启用 |

---

## 常见问题

### 找不到插件

**症状:** `/plugin install miyabi-full@miyabi-plugins` 返回 "plugin not found"

**解决方案:**
```bash
# 重新添加市场源
/plugin marketplace remove miyabi-plugins
/plugin marketplace add ShunsukeHayashi/miyabi-claude-plugins

# 重新安装
/plugin install miyabi-full@miyabi-plugins
```

### MCP 连接失败

**症状:** "MCP server miyabi-mcp-bundle not connected"

**解决方案:**
```bash
# 确保 Node.js 已安装
node --version

# 手动测试 MCP 服务器
npx miyabi-mcp-bundle

# 如果报错，全局安装
npm install -g miyabi-mcp-bundle
```

### 命令不工作

**症状:** `/miyabi-full:deploy` 返回 "command not found"

**解决方案:**
```bash
# 检查插件是否已安装
/plugin list

# 重新安装插件
/plugin uninstall miyabi-full@miyabi-plugins
/plugin install miyabi-full@miyabi-plugins

# 重启 Claude Code
/exit
claude
```

### GitHub 集成不工作

**症状:** GitHub 命令因认证错误失败

**解决方案:**
```bash
# 检查 Token 是否已设置
echo $GITHUB_TOKEN

# 测试 Token
curl -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/user
```

---

## 更新插件

```bash
# 检查更新
/plugin outdated

# 更新插件
/plugin update miyabi-full@miyabi-plugins

# 更新所有插件
/plugin update --all
```

---

## 采用情况

- **最近 14 天内 2,400+ 次克隆**
- **270+ 独立开发者** 正在使用这些插件
- 来自 **ByteDance**、**Google**、**Bing** 等的流量
- 在 **X/Twitter** 和 **Lark**（ByteDance 协作平台）上被引用

---

## 卸载

```bash
# 移除插件
/plugin uninstall miyabi-full@miyabi-plugins

# 移除市场源
/plugin marketplace remove miyabi-plugins
```

---

## 许可证

Apache-2.0

---

## 支持渠道

| 渠道 | 链接 |
|------|------|
| **GitHub Issues** | [报告 Bug](https://github.com/ShunsukeHayashi/miyabi-claude-plugins/issues) |
| **Discord** | [Miyabi 社区](https://discord.gg/miyabi) |
| **文档** | [Miyabi 文档](https://miyabi-world.com/docs) |

---

## 关于开发者

**林 駿甫 (Shunsuke Hayashi)** — 一位运营 40 个 AI Agent 的个人开发者。

- [miyabi-ai.jp](https://www.miyabi-ai.jp)
- X/Twitter: [@The_AGI_WAY](https://x.com/The_AGI_WAY)
- GitHub: [@ShunsukeHayashi](https://github.com/ShunsukeHayashi)

---

## 相关项目

| 项目 | 描述 | 链接 |
|------|------|------|
| **miyabi-mcp-bundle** | 172+ 工具的 MCP 服务器 | [npm](https://www.npmjs.com/package/miyabi-mcp-bundle) |
| **Claude Code** | Anthropic 的 Claude CLI | [Anthropic](https://claude.ai/code) |

---

<div align="center">

如果觉得有用，请给这个项目点个 Star！

</div>
