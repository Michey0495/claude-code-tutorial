# miyabi-claude-plugins

Claude Code skill definitions for the Miyabi ecosystem.
This repo contains **agent prompts, command definitions, hooks, and skills** — no execution logic.
Execution engine lives in [miyabi CLI](https://github.com/ShunsukeHayashi/Miyabi).

## Directory Structure

\\\
miyabi-claude-plugins/
├── miyabi-business-agents/   # 25 business agents (marketing, sales, content, etc.)
│   └── agents/*.md
├── miyabi-coding-agents/     # 14 coding agents (codegen, review, deploy, etc.)
│   └── agents/*.md
├── miyabi-commands/          # 50+ command definitions
│   └── commands/*.md
├── miyabi-guardian/          # Guardian security agent
│   └── agents/GuardianAgent.md
├── miyabi-honoka/            # Honoka specialization agent
│   └── agents/honoka-agent.md
├── miyabi-hooks/             # Git hooks (pre-commit, post-commit, etc.)
├── miyabi-skills/            # 22 Claude Code skills + X account ops
│   ├── skills/*/SKILL.md
│   └── xai-account-ops/
├── AGENTS.md                 # Agent registry
├── README.md                 # Project overview
├── index.html                # Marketplace UI
└── marketplace.json          # Agent/skill catalog
\\\

## Key Counts

- **Business agents**: 25 (honoka, analytics, crm, funnel, marketing, etc.)
- **Coding agents**: 14 (codegen, review, deploy, coordinator, etc.)
- **Commands**: 50+ (agent-run, deploy, pr-create, security-scan, etc.)
- **Skills**: 22 (issue-analysis, git-workflow, tdd-workflow, etc.)

## How It Works

1. Claude Code reads agent .md files as skill definitions
2. miyabi CLI dispatches tasks to the appropriate agent
3. Hooks run automatically on git operations
4. Skills provide specialized capabilities (debugging, docs, security, etc.)

## Important

- This repo is **prompt definitions only** — no runtime code
- The execution engine is in the [Miyabi CLI](https://github.com/ShunsukeHayashi/Miyabi)
- Agent files (.md) are the single source of truth for agent behavior
- Do NOT create duplicate directories — each agent/command/skill exists in exactly one location
