"""CLI-specific adapter implementations."""
