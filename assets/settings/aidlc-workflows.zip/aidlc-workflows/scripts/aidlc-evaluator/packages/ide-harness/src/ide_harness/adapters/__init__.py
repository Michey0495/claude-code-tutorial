"""IDE-specific adapter implementations."""
