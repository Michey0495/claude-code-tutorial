# Claude Code Starter Kit

[日本語 README](README.md) | [Changelog](CHANGELOG.md)

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Platform: macOS/Windows](https://img.shields.io/badge/Platform-macOS%20%7C%20Windows-blue.svg)](#installation)

One-command setup of a complete Claude Code development environment with an interactive wizard.

> **This kit reproduces the exact Claude Code environment used by Shinji Saito, CEO of Cloud Native Inc. and Chief Information Security Advisor to Japan's Ministry of Education, Culture, Sports, Science and Technology (MEXT).**

## Quick Start

**Mac:**

```bash
curl -fsSL https://raw.githubusercontent.com/cloudnative-co/claude-code-starter-kit/main/install.sh | bash
```

**Windows (run PowerShell as Administrator):**

```powershell
irm https://raw.githubusercontent.com/cloudnative-co/claude-code-starter-kit/main/install.ps1 | iex
```

> Restart your terminal after install, then run `claude`. See [Installation](#installation) for details.

---

## Table of Contents

- [Why This Repo](#why-this-repo)
- [Features](#features)
- [Installation](#installation)
- [Wizard Flow](#wizard-flow)
- [Wizard Config Mapping](docs/wizard-config-mapping.en.md)
- [Profiles](#profiles)
- [Usage](#usage)
- [Non-Interactive Mode](#non-interactive-mode)
- [Directory Structure](#directory-structure)
- [Customization](#customization)
- [Uninstall](#uninstall)
- [Changelog](#changelog)
- [License](#license)

## Why This Repo

Claude Code Starter Kit bootstraps a consistent, high-quality Claude Code environment in minutes. It ships opinionated agents, rules, commands, skills, hooks, and plugin recommendations so teams can start coding with shared standards immediately.

## Features

- **3 profiles**: Minimal, Standard (recommended), Full
- **9 agents**: planner, architect, tdd-guide, code-reviewer, security-reviewer, build-error-resolver, e2e-runner, refactor-cleaner, doc-updater
- **10 rules**: coding-style, git-workflow, hooks, patterns, performance, security, testing, agents, anti-patterns, permissions-guide
- **17 slash commands**: /plan, /tdd, /build-fix, /code-review, /e2e, /verify, /research, /handover, /update-kit, and more
- **12 skill modules**: backend-patterns, frontend-patterns, security-review, tdd-workflow, prompt-patterns, and more
- **12 optional hooks**: safety net (cc-safety-net), auto update, tmux reminder, git push review, doc blocker, prettier, console.log guard, memory persistence, strategic compact, PR creation log, pre-compact auto-commit, doc size guard (Full only)
- **14 plugins** from multiple marketplaces: security-guidance, commit-commands, pr-review-toolkit, feature-dev, code-review, claude-md-management, superpowers, code-simplifier, document-skills, example-skills, typescript-lsp, gopls-lsp, pyright-lsp, rust-analyzer-lsp
- **i18n**: English & Japanese
- **Codex MCP** sub-agent integration (optional, supports ChatGPT sign-in or OpenAI API key auth)
- **Non-interactive mode** for CI/automation

## Prerequisites

**Bash 4+** is required. macOS ships with Bash 3.2 by default — the kit auto-detects Bash 4+ (e.g., from `brew install bash`) and re-execs. Linux/WSL typically has Bash 4+ pre-installed.

### Claude Account (Paid)

**Claude Code requires a paid Anthropic account.** It does not work with free plans.

### Pricing

| Plan | Price | For | Features |
|------|-------|-----|----------|
| **Pro** | $20/mo | Individuals (starter) | Claude Code access, standard usage |
| **Max (5x)** | $100/mo | Individuals (heavy use) | 5x Pro usage, ideal for extended coding |
| **Max (20x)** | $200/mo | Individuals (power user) | 20x Pro usage, for large-scale projects |
| **Teams Standard** | $25/user/mo | Teams | Shared workspace, admin controls, SSO (SAML) |
| **Teams Premium** | $150/user/mo | Teams (advanced) | All Standard features + higher usage limits |
| **Enterprise** | Contact sales | Large orgs | Custom contracts, audit logs, advanced security |

> **Note**: Prices shown are as of March 2026. Check [claude.com/pricing](https://claude.com/pricing) for current rates.
> Using Codex MCP (OpenAI integration) requires either an eligible ChatGPT plan for Codex sign-in, or OpenAI API key authentication with OpenAI API usage fees.

> **Linux**: This kit is designed for macOS and Windows. If you want to use it on Linux, adjustments may be needed depending on your distribution (Ubuntu, Fedora, etc.) and desktop environment (GNOME, KDE, etc.). Try the one-liner or manual installation method.

### For individuals

Subscribe to [Claude Pro or Max](https://claude.com/pricing). Create an account at [claude.ai](https://claude.ai) and upgrade your plan.

### For teams and organizations

Use **Claude for Teams** or **Claude for Enterprise**. If your organization already has a plan, ask your admin to invite you. For cloud provider integration (AWS Bedrock, Google Vertex AI, Microsoft Foundry), see the [third-party integration docs](https://code.claude.com/docs/en/third-party-integrations).

### First-time login

When you run `claude` for the first time, you'll be asked to choose an authentication method:

| Method | Recommended for | Description |
|--------|----------------|-------------|
| **Claude.ai account (OAuth)** (Recommended) | Individuals & teams | Browser opens, log in to claude.ai. Works with Pro/Max/Teams/Enterprise |
| **Anthropic Console (API key)** | Developers preferring per-token billing | Generate a key at [console.anthropic.com](https://console.anthropic.com) |

**If unsure, choose OAuth.** Just log in via browser — no additional setup needed.

## Installation

### One-liner (macOS)

```bash
curl -fsSL https://raw.githubusercontent.com/cloudnative-co/claude-code-starter-kit/main/install.sh | bash
```

**Non-interactive one-liner** (skips wizard, uses Standard profile defaults):

```bash
curl -fsSL https://raw.githubusercontent.com/cloudnative-co/claude-code-starter-kit/main/install.sh | bash -s -- --non-interactive
```

### Windows PowerShell (uses WSL2)

Run PowerShell **as Administrator**, then:

```powershell
irm https://raw.githubusercontent.com/cloudnative-co/claude-code-starter-kit/main/install.ps1 | iex
```

> **Important**: After setup, use **Windows Terminal + WSL (Ubuntu)** to run `claude`.
> Open Windows Terminal → click the dropdown arrow → select **Ubuntu**.
>
> If admin is unavailable, use Git Bash mode: `powershell -File install.ps1 --git-bash`

### Manual

```bash
git clone https://github.com/cloudnative-co/claude-code-starter-kit.git
cd claude-code-starter-kit
./setup.sh
```

## Wizard Flow

```
Language → Profile → Codex MCP → New /init → Editor → Hooks → Plugins → Claude Code Attribution → Confirm & Deploy
```

Each step shows numbered options with descriptions. Recommended choices are marked.

> **About the Editor step**: The wizard asks which code editor you use. This is for the git push review hook (opens a diff view in your editor before pushing code). **If you don't have an editor installed or aren't sure, choose "None"** — Claude Code works entirely in the terminal and does not require an editor.

> **Want to know where each choice is applied?** See [Wizard Config Mapping](docs/wizard-config-mapping.en.md). It explains which values are written to `settings.json`, which are used only during setup, and which act as presets.
>
> **About the new /init mode**: Minimal, Standard, and Full enable Claude Code's new interactive `/init` mode by default. Custom asks whether you want to enable it.

### Editor Setup (Optional)

A code editor is a dedicated application for writing and editing code. While Claude Code runs in the terminal and doesn't require one, having an editor enables the git push review hook feature.

**Recommended: [VS Code](https://code.visualstudio.com/)** (free, by Microsoft)
- **macOS**: Download from [code.visualstudio.com](https://code.visualstudio.com/), then run `Cmd + Shift + P` → "Shell Command: Install 'code' command in PATH"
- **Windows**: Download and run the installer from [code.visualstudio.com](https://code.visualstudio.com/)

Other supported editors: [Cursor](https://www.cursor.com/) (AI-native), [Zed](https://zed.dev/) (fast & lightweight), [Neovim](https://neovim.io/) (advanced, terminal-based).

## Profiles

| Profile | Agents | Rules | Commands | Skills | Hooks | Memory | Plugins | Codex MCP | Ghostty |
|---------|--------|-------|----------|--------|-------|--------|---------|-----------|---------|
| Minimal | Yes | Yes | - | - | - | - | - | - | - |
| Standard (Recommended) | Yes | Yes | Yes | Yes | Core | Yes | 10 | Optional | - |
| Full | Yes | Yes | Yes | Yes | All | Yes | 14 | Yes | macOS only |

- **Minimal**: Lightweight start with just agents and rules
- **Standard**: Best for most teams. Includes commands, skills, core hooks, and memory
- **Full**: Everything enabled including all hooks and Codex MCP sub-agent delegation

### Hooks

Hooks are automated safety checks that run automatically when Claude Code executes commands or edits files.

| Hook | Description |
|---|---|
| **Safety Net** | Blocks destructive git/filesystem commands (`git reset --hard`, `rm -rf`, `git push --force`, etc.) before execution |
| **Auto Update** | Checks for starter kit updates on session start and applies them in the background |
| Tmux Reminder | Suggests tmux for long-running commands |
| Git Push Review | Pauses before git push for code review |
| Doc Blocker | Prevents creation of unnecessary .md/.txt files |
| Prettier Auto-format | Formats JS/TS files after edits |
| Console.log Guard | Warns about console.log statements left in code |
| Memory Persistence | Saves/restores session state across sessions |
| Strategic Compact | Suggests /compact at logical intervals |
| PR Creation Log | Logs PR URL after creation |
| Pre-compact Auto-commit | Auto-commits changes before context compaction |
| Doc Size Guard | Warns when CLAUDE.md/AGENTS.md exceeds recommended line count (Full only) |

#### Safety Net

[cc-safety-net](https://github.com/kenryu42/claude-code-safety-net) intercepts Bash commands via a PreToolUse hook and blocks destructive operations before they execute.

Blocked commands include:
- `git reset --hard` — discards uncommitted changes
- `git checkout -- <file>` — discards file changes
- `git push --force` — overwrites remote history
- `rm -rf` — irreversible file/directory deletion

STRICT mode (`SAFETY_NET_STRICT=1`) is enabled by default, causing unparseable commands to be blocked (fail-closed).

> **Enabled by default in Standard / Full profiles.** Requires `npm install -g cc-safety-net`.

#### Auto Update

Automatically checks for new starter kit releases on GitHub at the start of each Claude Code session.

- **24-hour cache**: Only checks once per day (cache-hit exits in < 1ms)
- **Background execution**: Updates run in the background, so session startup is not blocked
- **Settings preserved**: 3-way merge keeps your customizations intact
- **One-liner installs only**: Only works when the kit is installed at `~/.claude-starter-kit/`
- Changes take effect on the next session

> **Enabled by default in Standard / Full profiles.** Disable with `ENABLE_AUTO_UPDATE=false` in the hooks selection.

## Usage

> **Important: You must restart your terminal after setup.**
> PATH and shell settings added during setup won't take effect until you open a new terminal window. Close your current terminal and open a new one before running `claude`.

After restarting your terminal, start `claude` in your project directory. The installed slash commands and agents are immediately available:

```bash
/plan            # Structured planning
/tdd             # Test-driven development flow
/code-review     # Code review mode
/build-fix       # Fix build errors
/e2e             # End-to-end testing
/verify          # Final verification
/checkpoint      # Record current work as a checkpoint
/refactor-clean  # Find and clean up unused code
/update-docs     # Update documentation to latest state
/research        # Deep codebase investigation (RPI workflow)
/handover        # Structured session handover document
/update-kit      # Manually update starter kit to latest version
```

### Deployment: Let Claude Code Set Up Your Infrastructure

Not sure how to deploy your application? Just ask Claude Code — it can guide you through the entire process:

**Deploy to AWS Lambda:**

```
I want to deploy this project to AWS Lambda.
Please set up all necessary config files, IAM roles, and deployment steps.
```

**Deploy to Google Cloud Functions:**

```
I want to deploy this to Google Cloud Functions.
Please set up the required configuration and walk me through the process.
```

**Not sure which platform to use:**

```
I want to run this in production.
Compare AWS Lambda, Google Cloud Functions, and Vercel,
and recommend the best option for this project.
```

Claude Code helps with more than just writing code — it can set up **infrastructure, deployment configs, and CI/CD pipelines** too.

### Sending Screenshots to Claude Code

You can send screenshots directly to Claude Code to show UI bugs, error screens, or layout issues. Claude Code understands images and can fix problems just by seeing them.

**macOS:**

| Step | Action | Description |
|------|--------|-------------|
| 1. Take screenshot | `Cmd + Shift + Ctrl + 4` | Select an area to copy to clipboard |
| 2. Paste into Claude Code | `Ctrl + V` (NOT `Cmd + V`) | Paste while Claude Code prompt is focused |

> **Important**: Use `Ctrl + V` (not `Cmd + V`) to paste screenshots into Claude Code. This is easy to mix up.

**Windows (WSL):**

| Step | Action | Description |
|------|--------|-------------|
| 1. Take screenshot | `Win + Shift + S` | Snipping Tool opens, select area to copy |
| 2. Paste into Claude Code | `Ctrl + V` | Paste in Windows Terminal |

You can also **drag and drop image files** into the terminal to send them to Claude Code.

## Non-Interactive Mode

For CI, automation, or scripted setups:

```bash
# One-liner non-interactive install (Standard profile + all default plugins)
curl -fsSL https://raw.githubusercontent.com/cloudnative-co/claude-code-starter-kit/main/install.sh | bash -s -- --non-interactive

# Or use NONINTERACTIVE env var (same convention as Homebrew)
NONINTERACTIVE=1 bash -c "$(curl -fsSL https://raw.githubusercontent.com/cloudnative-co/claude-code-starter-kit/main/install.sh)"

# Use standard profile with English and VS Code
./setup.sh --non-interactive --profile=standard --language=en --editor=vscode

# Full control over hooks and plugins (use name@marketplace for disambiguation)
./setup.sh --non-interactive \
  --profile=standard \
  --language=en \
  --editor=cursor \
  --new-init=true \
  --codex-mcp=false \
  --commit-attribution=false \
  --hooks=safety-net,auto-update,tmux,git-push,prettier,console,memory,compact,pr-log,pre-commit \
  --plugins=security-guidance,commit-commands,pr-review-toolkit@claude-plugins-official,pr-review-toolkit@claude-code-plugins

# Reuse a saved config
./setup.sh --non-interactive --config=./my-config.conf
```

> **Plugin naming**: When the same plugin name exists in multiple marketplaces, use `name@marketplace` format (e.g., `pr-review-toolkit@claude-code-plugins`). Plugins without name conflicts can be specified by name alone.
>
> **Notes**:
> - `--profile` selects a preset bundle of lower-level flags rather than a single final runtime key
> - `--new-init=true` enables Claude Code's new interactive `/init` flow
> - `--commit-attribution=false` disables Claude Code attribution in both commits and PRs
> - For full mapping details, see [Wizard Config Mapping](docs/wizard-config-mapping.en.md)

> **Customizing CLAUDE.md**:
> - `~/.claude/CLAUDE.md` is split into a kit-managed section (`<!-- BEGIN STARTER-KIT-MANAGED -->` ... `<!-- END STARTER-KIT-MANAGED -->`) and a user section (`# User Settings`)
> - Add your custom instructions in the user section. Updates only touch the kit section; your content is preserved
> - If your existing CLAUDE.md has no markers, an interactive migration is offered on first update
>
> **Existing users**:
> - If you already use this starter kit, prefer `/update-kit` or `./setup.sh --update`. Conflicts are resolved interactively with `[RK]/[RU]` remember options. Use `--reset-prefs` to clear saved decisions.
> - **First-time kit users with existing `~/.claude/settings.json`**: settings.json is merged (not overwritten), and other files are confirmed per-directory.
> - `--non-interactive` is intended for CI/automation. Interactive mode is recommended for existing users.
> - A backup is automatically created at `~/.claude.backup.<timestamp>` before every update or first install with existing files.
> - **Dirty check**: If the kit repo has local changes, update is blocked with a `git stash` hint (applies to auto-update, install.sh, and /update-kit).
> - **Recovery**: If an update fails, backup path and restore commands are shown. The latest backup path is saved in `~/.claude/.starter-kit-last-backup`.
>
> **Dry-run (preview before deploying)**:
> - Use `/update-kit-dry-run` or `bash setup.sh --update --dry-run` to preview what an update would change. Shows files to create/modify/delete/skip, a settings.json diff, and external operations as `[WOULD RUN]`.
> - During interactive install/update, if existing settings could be affected, you'll be asked "Would you like to preview changes?" automatically. Clean-slate installs skip this prompt.
> - `--non-interactive --dry-run` installs nothing and exits immediately.

## Directory Structure

```
claude-code-starter-kit/
├── install.sh              # One-liner bootstrap (macOS/Linux/WSL)
├── install.ps1             # Windows PowerShell bootstrap
├── setup.sh                # Main setup script (wizard + deploy)
├── uninstall.sh            # Manifest-based clean uninstall
├── lib/                    # Shell libraries
│   ├── colors.sh           # Terminal color helpers
│   ├── detect.sh           # OS/WSL detection
│   ├── prerequisites.sh    # Dependency checks
│   ├── template.sh         # Text template engine
│   └── json-builder.sh     # JSON builder (jq-based)
├── wizard/                 # Interactive wizard
│   ├── wizard.sh           # 8-step wizard logic
│   └── defaults.conf       # Default values
├── config/                 # Configuration templates
│   ├── settings-base.json  # Base settings.json structure
│   ├── permissions.json    # Tool permissions
│   └── plugins.json        # Plugin catalog
├── profiles/               # Profile presets
│   ├── minimal.conf
│   ├── standard.conf
│   └── full.conf
├── features/               # Optional feature modules
│   ├── */feature.json      # Feature metadata
│   └── */hooks.json        # Hook fragments
├── i18n/                   # Internationalization
│   ├── en/                 # English templates & strings
│   └── ja/                 # Japanese templates & strings
├── agents/                 # Agent definitions (9 files)
├── rules/                  # Rule files (10 files)
├── commands/               # Slash commands (17 files)
├── skills/                 # Skill modules (12 dirs)
└── memory/                 # Best practice memory (5 files)
```

## Customization

After installation, you can extend or modify any component:

- **Add an agent**: Create a new `.md` file in `~/.claude/agents/`
- **Add a rule**: Create a new `.md` file in `~/.claude/rules/`
- **Add a command**: Create a new `.md` file in `~/.claude/commands/`
- **Add a skill**: Create a new directory under `~/.claude/skills/` with a `SKILL.md`
- **Modify hooks**: Edit `~/.claude/settings.json` hooks section

To re-apply the starter kit config (e.g., after updating the repo), run `./setup.sh` again. Your previous selections are remembered in `~/.claude-starter-kit.conf`.

## Uninstall

If you installed via the one-liner, the repo is saved at `~/.claude-starter-kit/`.

**Mac / Linux:**

```bash
~/.claude-starter-kit/uninstall.sh
```

**Windows (WSL):**

From PowerShell or Terminal:

```bash
wsl -d Ubuntu -- bash -lc '~/.claude-starter-kit/uninstall.sh'
```

**If you cloned manually**, run from the cloned directory:

```bash
cd claude-code-starter-kit
./uninstall.sh
```

Only files deployed by the starter kit (tracked in `~/.claude/.starter-kit-manifest.json`) are removed. User-added files are preserved.

## Development

Shell scripts are statically analyzed with [ShellCheck](https://www.shellcheck.net/). It runs automatically via GitHub Actions on PRs. To run locally:

```bash
shellcheck setup.sh install.sh uninstall.sh lib/*.sh wizard/wizard.sh
```

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a detailed history of changes.

## Acknowledgements

- The Braille Dots status line pattern is inspired by [Nyosegawa's article](https://nyosegawa.com/posts/claude-code-statusline-rate-limits/)

## License

MIT. See [LICENSE](LICENSE).
