#!/bin/bash
# shellcheck disable=SC2034
# lib/colors.sh - Color output helpers for terminal messages
# Works on macOS and Linux. Falls back to plain text if terminal lacks color support.
#
# Requires: nothing (self-contained, first lib to be sourced)
# Exports: info(), ok(), warn(), error(), section(), _register_tmp()
# Exports: RED, GREEN, YELLOW, BLUE, CYAN, BOLD, NC (color codes)
# Dry-run: transparent (no special behavior)
set -euo pipefail

# ---------------------------------------------------------------------------
# Color codes (disabled when stdout is not a terminal or TERM is dumb)
# ---------------------------------------------------------------------------
if [[ -t 1 ]] && [[ "${TERM:-}" != "dumb" ]]; then
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  YELLOW='\033[0;33m'
  BLUE='\033[0;34m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m' # No Color / reset
else
  RED=''
  GREEN=''
  YELLOW=''
  BLUE=''
  CYAN=''
  BOLD=''
  NC=''
fi

# ---------------------------------------------------------------------------
# Output functions
# ---------------------------------------------------------------------------

# Informational message (blue)
info() {
  printf "${BLUE}[INFO]${NC} %s\n" "$*"
}

# Success message (green)
ok() {
  printf "${GREEN}[  OK]${NC} %s\n" "$*"
}

# Warning message (yellow) - prints to stderr
warn() {
  printf "${YELLOW}[WARN]${NC} %s\n" "$*" >&2
}

# Error message (red) - prints to stderr
error() {
  printf "${RED}[ERROR]${NC} %s\n" "$*" >&2
}

# Section header with a visual separator
section() {
  printf "\n${BOLD}── %s ──${NC}\n\n" "$*"
}

# ---------------------------------------------------------------------------
# _register_tmp - Register a temporary file/dir for cleanup on exit
#
# Usage: _register_tmp <path>
#
# Appends to _SETUP_TMP_FILES[] which is cleaned up by _cleanup_tmp() trap.
# Safe to call even if _SETUP_TMP_FILES is not yet declared (no-op in that case).
# ---------------------------------------------------------------------------
_register_tmp() {
  # Guard: only append if the tracking array exists (sourced from setup.sh)
  if declare -p _SETUP_TMP_FILES &>/dev/null; then
    _SETUP_TMP_FILES+=("$1")
  fi
}
