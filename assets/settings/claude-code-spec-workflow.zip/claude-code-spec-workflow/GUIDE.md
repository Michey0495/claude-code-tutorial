# 📚 使い方ガイド: claude-code-spec-workflow

> 自動生成日: 2026-01-13

---

## 📋 プロジェクト概要

**⚠️ IMPORTANT NOTICE:** Development focus has shifted to the **MCP (Model Context Protocol) version** of this workflow system. The MCP version provides enhanced features, real-time dashboard, and broader AI tool compatibility. **🚀 [View the new Spec Workflow MCP →](https://github.com/Pimzino/spec-workflow-mcp)**

**リポジトリ**: https://github.com/Pimzino/claude-code-spec-workflow.git

---

## 🛠️ 技術スタック

- **言語**: Node.js
- **フレームワーク**: React, Vue
- **主要な依存関係**: README.mdまたはpackage.json/requirements.txtを参照してください

---

## 🚀 セットアップ手順

```bash
# 1. ディレクトリに移動
cd /Users/coelaqanth_006/Desktop/02forAI/07Gitsutar/claude-code-spec-workflow

# 2. 依存関係のインストール
npm i -g @pimzino/claude-code-spec-workflow
claude-code-spec-workflow
```

環境変数の設定が必要な場合は、.env.exampleを参照して.envファイルを作成してください。

---

## 💡 基本的な使い方

詳細な使い方については、プロジェクトの[README.md](/Users/coelaqanth_006/Desktop/02forAI/07Gitsutar/claude-code-spec-workflow/README.md)を参照してください。

基本的なコマンド:
```bash
# 開発サーバーの起動（プロジェクトにより異なります）
npm start
# または
npm run dev
```

---

## 🎯 最初の練習動作

**目標**: プロジェクトをセットアップして基本機能を確認する

**手順**:
1. 上記のセットアップ手順に従って依存関係をインストールします
2. README.mdを読んで、プロジェクトの目的と機能を理解します
3. 環境変数や設定ファイルが必要な場合は、適切に設定します
4. サンプルやテストを実行して、正常に動作することを確認します

**期待される結果**:
- 依存関係が正しくインストールされる
- プロジェクトがエラーなく起動する
- 基本的な機能が使用できる

---

## 📖 参考リンク

- [GitHub Repository]({git_url})
- [npm Documentation](https://docs.npmjs.com/)
- [Node.js Documentation](https://nodejs.org/docs/)

---

**作成者**: Claude Code
**最終更新**: 2026-01-13
