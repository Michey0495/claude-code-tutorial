# エージェントに醜い UI を出させるのはやめよう。

AI エージェントでちゃんとデザインされた UI を作る方法。

Hassan El Mghari · Together AI · AI Engineer World's Fair · 2026

---

> **このデック概要** — これはどの AI エンジニアにも当てはまる汎用プレイブックで、プロダクトピッチではない。Hallmark はスライド 15 で 1 度だけ、私たちのチームが作ったオープンソース例として登場する。7 つの修正は v0、Lovable、Bolt、Cursor、Claude Code、あるいは自作エージェントすべてに効く。
>
> **ビジュアルスタイル** — ダークスレート `#0b1117`、オフホワイトのインク `#e6edf3`、GitHub クールブルーアクセント `#58a6ff`。書体は Inter、コードは Roboto Mono。スライドはすべてクロムフリー。eyebrow ラベルなし、装飾ヘアラインなし。フッターは左下に Together AI ロゴ、右下にページ番号のみ。
>
> **テンポ** — 17 スライド、18 分。1 スライド約 60 秒。セクションオープナー（S05）は 10 秒の間。S08（ワイヤーフレーム）、S11（8 ステート）、S13（システムプロンプト）は少し時間を取りたい。

---

## 01 · 表紙

# エージェントに醜い UI を出させるのはやめよう。

*AI エージェントでちゃんとデザインされた UI を作る方法。*

— Hassan El Mghari · Together AI · AI Engineer World's Fair · 2026

*話者: 私は Hassan、Together AI で DX を率いています。今年 AI アプリを作って、ポートフォリオには絶対載せたくない UI が出てくるのを見た人がほとんどでしょう。今日はなぜそれが起きるのか、そしてどのエージェントでも効く 7 つの具体的な修正の話です。*

---

## 02 · 問題

# 今あなたのエージェントが出してくるもの。

*(ビジュアル: 実際の DevForge スクリーンショット。生成された開発者カンファレンスのランディングページ。見出しに紫シアンのグラデーション、中央寄せヒーロー、4 カラムの数値行、本文も見出しも Inter。)*

> 素のプロンプト。毎回同じ形。

*話者: 同じプロンプトを 12 のエージェントに与えました。「開発者カンファレンスのランディングページを作って、ダークテーマ、ブルックリン」。返ってきたのはほぼこれです。違うモデル、違うスタック、同じページ。*

---

## 03 · 期待

# こちらを出すことだってできる。

*(ビジュアル: Hyperlane のスクリーンショット。同じ要件で再構築。大きなサンセリフ見出しにイタリックセリフのアクセント、非対称レイアウト、単一の暖色アクセント、メタはモノスペース。)*

> 同じ要件。1 つの欠けていたレイヤーを足しただけ。

*話者: 同じ要件、同じエージェント。違いはプロンプトと出力の間にあるレイヤー。残りの時間はそのレイヤーの話に使います。*

---

## 04 · 理由

# モデルは学習データの平均を出してくる。

*2019 年以降のあらゆる SaaS サイトが同じ形で学習された。外部からの操舵がなければ、エージェントはそこに回帰する。*

> ここから先のすべては、プロンプトと少しの構造で直せる。

*話者: これはモデルの失敗ではありません。Claude はあなたが説明したものを何でもレンダリングできる。「ランディングページを作って」が、2019 年以降のあらゆる SaaS サイトが住む多様体の領域に写像されているだけ。良いニュース: ここから先の修正は、どのエージェントでも今日からできることです。*

---

## 05 · セクションオープナー

# それを直す 7 つのこと。

*ツール非依存。v0、Lovable、Bolt、Cursor、Claude Code、自作エージェントで動く。*

*話者: ひとつひとつがスロップの 1 種類を閉じます。どれも今日から効きます。*

---

## 06 · Fix 01 — 実在のコンポーネントライブラリを使う

# 実在のコンポーネントライブラリを使う。

shadcn/ui は生成 UI の共通言語。
主要な AI ツールはどれもこれで学習されている。Linear、Vercel、Stripe が出荷している。
採用すれば、初日から出力が 80% 良くなる。

```bash
$  npx shadcn@latest add button card dialog input table
```

→ *コンポーネントを置く。これで AI 生成は毎回、捏造プリミティブではなく実在のシステムから組み上がる。*

*話者: これが最も安く、最もレバレッジの効く一手。多くの AI エンジニアは shadcn/ui を知っていますが、実際に採用している人はもっと少ない。v0 はネイティブで出荷します。Cursor も読みます。Claude Code も読みます。モデルはこれらのコンポーネントを何百万例も見ていて、組み合わせ方を知っています。*

---

## 07 · Fix 02 — デザインシステムを固定する

# デザインシステムを固定する。

ルートに 1 ファイル、エージェントが毎回読む。
1 パレット、1 タイプペアリング、1 スケール。レンダリング中の即興は禁止。

```css
/* DESIGN.md  or  app/globals.css  —  Tailwind v4  @theme block */

@theme {
   --color-paper:    oklch(0.13 0.01 250);   /* one surface, not five */
   --color-ink:      oklch(0.93 0.01 250);   /* one ink */
   --color-accent:   oklch(0.65 0.18 250);   /* one accent, under 5% */
   --font-display:   "Inter Tight", sans-serif;
   --font-body:      "Inter", sans-serif;
   --space-1:        0.25rem;                /* 4-pt scale */
   --ease-out:       cubic-bezier(.2,0,0,1);
}
```

*話者: Tailwind v4 でこれが以前より簡単になりました。`@theme` ブロック 1 つ、色は OKLCH、意味的な名前付け。隣に `DESIGN.md` を置き、ブランドが何を語り、何でないかを平文の英語で書きます。エージェントは毎回両方を読みます。*

---

## 08 · Fix 03 — 形を指定する

# 機能のリストではなく、形を頼む。

*「ヒーローと特徴 3 つ」をやめる。marquee、bento、long-document、stat-led と言う。*

*(ビジュアル: Figma で描いた抽象ワイヤーフレーム 4 種を並べる。)*

- **MARQUEE** · エディトリアルな 1 アイデア、左寄り
- **LONG DOCUMENT** · 手紙のように読める、マーケティングクロムなし
- **BENTO** · 多数のエントリー、不規則グリッド
- **STAT-LED** · プロダクトが見出し、数字が運ぶ

*話者: これが「どのページも SaaS ランディングに見える」アトラクタを壊す一手。特徴を列挙しない。ページのカテゴリを選ぶ。Linear のホームと Stripe のホームが形を共有していないのと同じ。彼らはカテゴリを共有しているだけ。*

---

## 09 · Fix 04 — リファレンスを見せる

# スクリーンショットを貼る。説明しない。

AI は読むより見るほうが分かる。
リファレンス画像は形容詞の段落より多くの趣味を運ぶ。

```
→  好きな実在サイトを 1 つ選ぶ。
→  エージェントに構造を抽出するよう頼む、ピクセルをコピーするのではなく。
→  タイプの役割を命名する（"italic editorial serif"）、フォント名ではなく。
```

*(右ビジュアル: calendly.com の実スクリーンショット。実際に貼り付けるリファレンス。)*

> 例 · エージェントに calendly.com を貼った

*話者: デザイナーは昔からこれをやってきました。「こんな感じにして」。少し前まではエージェントに同じ手は通じなかった。今は通じます。趣味を説明せず、見せる。そしてピクセルではなく構造を抽出させる。欲しいのはリズムであって、コピー品ではない。*

---

## 10 · Fix 05 — 兆候を禁じる

# やってほしくないことを伝える。

*指示より制約のほうが効く。システムプロンプトに入れる:*

- ✕  紫 → 青のグラデーションヒーロー
- ✕  ディスプレイと本文の両方が Inter / Roboto
- ✕  アイコンが見出しの上にある等幅 3 カラム
- ✕  `min-height: 100vh` で全部中央寄せ
- ✕  意味のないカード in カード
- ✕  見出しに `background-clip` のテキストグラデーション
- ✕  純 `#000` や純 `#fff` のサーフェス
- ✕  捏造した数値、推薦の声、ロゴ

*話者: 直感に反しますが、モデルに「やるな」と伝えるほうが、欲しいものを記述するより強い。この 8 つの兆候は AI 生成 UI の指紋です。禁じれば、モデルは別の場所に手を伸ばすしかなくなります。*

---

## 11 · Fix 06 — 8 ステート

# 操作可能な要素はすべて 8 ステートを出荷する。

*エージェントが 2 つしか出さないなら、あなたの UI は壊れて出荷されている。*

*(ビジュアル: 4×2 グリッドに実際のボタン 8 つ、それぞれ別ステート — default、hover、focus-visible、active、disabled、loading、error、success。)*

| state | 何が違うか |
| --- | --- |
| `default` | 静止時のスタイル |
| `hover` | 一段明るく |
| `:focus-visible` | 2px のアクセントリング、即時（フェードインなし） |
| `:active` | インクを反転、アクセントで塗りつぶし |
| `disabled` | 不透明度 50%、ポインタなし |
| `loading` | `· · · working` |
| `error` | 赤いボーダー、⚠ retry |
| `success` | 緑のボーダー、✓ saved |

*話者: AI 出力に対して走らせられる最速の「本物か雰囲気か」テスト。Tab でページを移動する。フィールドを無効化する。何かをロードさせる。8 ステートのうち 3 つでも未スタイルなら、エージェントはコンポーネントではなくスクリーンショットを出している。*

---

## 12 · Fix 07 — 出力前に自己採点

# エージェントに、まず自分の仕事を採点させる。

*システムプロンプトに 1 行入れれば、出力前に批判的な走査が強制される。2 周は普通。*

- **DISTINCTIVENESS** · これは*この*要件らしく見えるか、それともどの要件にも見えるか
- **HIERARCHY** · 2 秒で 1 番目 / 2 番目 / 3 番目が分かるか
- **EXECUTION** · 細部は正しいか（ルール、余白、フォーカスリング）
- **RESTRAINT** · 居場所を稼げていないものを削れ

各項目を 1〜5 で採点。3 未満があれば修正パス。

*話者: トリックはルーブリックではなく、モデルに自分の出力を返す前に批判的に見させること。2 周は普通です。3 周になるなら要件が曖昧すぎる。*

---

## 13 · プレイブック全文

# プレイブック全体は 1 段落に収まる。

```md
# system_prompt.md

You are a designer, not a templater. Before you write code:

  1. use shadcn/ui — never re-invent a primitive that already exists.
  2. read  DESIGN.md  for tokens. Use only those.
  3. pick ONE page shape (marquee, long-document, bento, stat-led, manifesto, catalogue).
  4. ban: purple-cyan gradients, Inter on Inter, 3-col icon grids, 100vh centered hero,
     card-in-card, background-clip text, pure #000 / #fff, invented metrics.
  5. ship 8 states for every interactive element.
  6. score  Distinctiveness · Hierarchy · Execution · Restraint  on 1–5.
     anything <3 triggers a revision pass.
```

*話者: これで全部です。7 行。どのエージェントのシステムプロンプトにも入れられます。Cursor `.mdc`、Claude Code スキル、v0 プロジェクト指示。次のレンダリングで違いを感じてください。*

---

## 14 · ツール

# 武器を選ぶ。

*同じ 7 つの修正。違うサーフェス。*

| | | |
| --- | --- | --- |
| **v0** | shadcn / Tailwind プレイグラウンド | 箱から出した時点で UI 品質が最良 |
| **Lovable** | フルスタックのチャット&ビルド | 視覚的に編集、ライブで出荷 |
| **Bolt** | StackBlitz での高速プロトタイピング | 速度 |
| **Cursor** | IDE 内アシスタント | エディタに住む |
| **Claude Code** | エージェントループ · ファイル認識 · スキル | 最長コンテキストのコーダー |

*話者: 7 つの修正を入れれば、どれも美しい仕事ができます。あなたのスタックに合うものを選んでください。*

---

## 15 · Hallmark — チームが OSS にした一例

# Hallmark。

*私たちのチームが OSS にした一例。*

7 つの修正を全部焼き込んだ Claude Code スキル。

→ `github.com/nutlope/hallmark`

*(ビジュアル: Hallmark の OG 画像 — "The best landing pages built with AI" と、実例ページ 3 つを焼き込んだもの。)*

*話者: Together AI で自分たち用に 7 つの修正を Claude Code スキルにパッケージし、その後 OSS にしました。これは 1 つのアプローチで、他にも Anthropic の frontend-design スキル、Taste、Impeccable などがあります。原理は同じ。エージェントにルールを発明させない。システムを渡す。*

---

## 16 · 大きな考え

# デザインの趣味はエージェントスタックの 1 レイヤー。

```
MODELS
TOOLS
MEMORY
RAG
EVALS
TASTE   ← here
ORCHESTRATION
```

*スタックに入れなければ、モデルは平均を選ぶ。*

*話者: 私たちは eval をファーストクラスのレイヤーとして扱う。モデルが eval なしだと間違ったものに最適化することを知っているから。趣味も同じ。最後に足す磨きの工程ではなく、レイヤー。あなたが既に使っているスタック、新しい 1 行。*

---

## 17 · 御礼

# ありがとう。

```
github.com/nutlope/hallmark
together.ai
```

`@nutlope`   `@YoussefXLM`

*(右ビジュアル: Hallmark リポジトリへの実 QR コード。)*

> スキャンしてインストール

*話者: ありがとう。スキルは今日からオープンです。皆さんが何を作るか、そして自分のエージェントスタックにどんな修正を加えるか、見せてもらえると嬉しい。*

---

# デザイナー / 制作ノート

**クロムは意図的にミニマル**

- スライド上部に eyebrow ラベルなし。
- 装飾のヘアライン、区切り線、アクセントルールなし。
- フッターは 2 要素のみ。左下に Together AI ロゴ（32×32）、右下にスライド番号。
- 機能的な矩形（コードブロックのサーフェス、S11 のボタン形状、S12 の軸カード）は残す。コンテンツを運んでいるから。

**パレットは固定**

- BG `#0b1117`（ディープスレート）
- サーフェス `#161b22`（コードブロック、カード）
- インク主 `#e6edf3`
- インク副 `#7d8590`
- アクセント `#58a6ff`（GitHub クールブルー — リンク、キーラベル、アクセント塗り）
- アラート `#f85149`（Fix 05 の禁止リストと Fix 06 のエラーボタンのみ）
- 成功 `#3fb950`（Fix 06 の成功ボタンのみ）

**書体**

- ディスプレイ: Inter（Black / Bold を巨大サイズで）
- 本文: Inter Regular / Light
- コード &amp; モノラベル: Roboto Mono

**ペーシング**

17 スライドで 18 分枠 ≈ 1 スライド 60 秒。セクションオープナー（S05）は 10 秒の間。システムプロンプトのスライド（S13）は Hassan が音読する時間を取りたい。Hallmark のスライド（S15）は意図的に静か。ラベルだけ読み、留まらない。

**時間が押した場合**

順に: S04（Why — S02 のナレーションに畳み込める）、S16（スタック図 — S15 の後に 1 文で言える）。S05、S08、S09、S11 は決して落とさない。

**時間が余った場合**

S09 の後にライブデモを足す。デザインされたサイトのスクリーンショットを貼り、エージェントを走らせ、出力を見せる。90 秒以内。

**Markdown 成果物**

このファイル（`docs/talk-slides.md`）が正本。Figma ファイルが再編されても、こちらが権威を保つ。

---

# 出典

- ["shadcn/ui March 2026 Update: CLI v4, AI Agent Skills and Design System Presets"](https://medium.com/@nakranirakesh/shadcn-ui-march-2026-update-cli-v4-ai-agent-skills-and-design-system-presets-d30cf200b0e9)
- ["AI-First UIs: Why shadcn/ui's Model is Leading the Pack" — Refine](https://refine.dev/blog/shadcn-blog/)
- ["Design Systems for the Vibe-Coding Era" — Anna Arteeva, Design Systems Collective](https://www.designsystemscollective.com/design-systems-for-the-vibe-coding-era-42282e1affef)
- [Anthropic — "Improving frontend design through Skills"](https://claude.com/blog/improving-frontend-design-through-skills)
- ["v0 by Vercel — Complete Guide 2026"](https://www.nxcode.io/resources/news/v0-by-vercel-complete-guide-2026)
- ["The Vibe-Coder's Prompting Guide" — Anna Arteeva, Medium](https://annaarteeva.medium.com/the-vibe-coders-prompting-guide-e04ba0295a18)
- ["Choosing your AI prototyping stack: Lovable, v0, Bolt, Replit, Cursor, Magic Patterns" — Anna Arteeva, Medium](https://annaarteeva.medium.com/choosing-your-ai-prototyping-stack-lovable-v0-bolt-replit-cursor-magic-patterns-compared-9a5194f163e9)
- [AI Engineer World's Fair 2026 — Jun 29 – Jul 2](https://www.ai.engineer/worldsfair)
- [Hassan El Mghari · DX at Together AI](https://www.nutlope.com/)
