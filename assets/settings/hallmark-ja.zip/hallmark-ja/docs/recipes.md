# レシピ集 — Hallmark 出力を生み出すコピペプロンプト

Hallmark スキルをインストールした Claude Code、Cursor、Codex に貼り付けて使える、実践済みの要件 8 本。各レシピは、プロンプト原文、スキルが推論した audience / use / tone、選ばれたマクロ構造 + テーマ + エンリッチメント、出力の 1 段落抜粋を示す。テストが [`site/_tests/`](../../site/_tests/) に存在する場合はライブページへのリンクも添える。

最初のレシピは **公式の「お試し」プロンプト**。新しいプロジェクトに貼り付けてスキルが正しく入っているか確認し、何も読む前に流れを掴むためのもの。

---

## 00 · Try it · Coffeebox

**プロンプト**（原文コピペ用）

> *"Build me a landing page for Coffeebox — a small-batch coffee subscription. Roast on Sunday, ship on Monday, drink Tuesday. Audience: people who already buy good coffee and want fewer trips to the shop. Tone: warm, hand-set, editorial — like a small café's chalkboard."*

**推論された 3 要素:** 明示（audience: 本格コーヒー購入層 · use: サブスク加入 · tone: editorial-warm）。

**選択:** Long Document · **Linen**（暖色ペーパーのローマンセリフ） · Tier-B 手書き SVG（小さなコーヒー豆アイコン、任意）。

**出力の抜粋:**

> *"Coffeebox · est. 2026 · n.º 12.* 最初のローストはドラムを日曜午前 6:14 に離れる。月曜朝にはあなたのポストの紙袋に。火曜にはキッチンがカフェの香りに。サブスク加入、1 週スキップ、ローストの変更、すべてメールから。昨日焼いたものを焼く。よく出たものを送る。メールには自分で返す。"

**これが公式お試しである理由:** 要件に明示的なコンテキストがあり（design-context-gate で詰まらない）、エディトリアルなトーンを持ち（どの AI 既定のランディングとも違う）、ドメイン（コーヒーサブスク）が SaaS / 開発ツールの常套句とまったく重ならない。このプロンプトで Hallmark が *Linen + イタリック Cormorant + 暖色ペーパー* を出すなら、スキルは正しく接続されている。

---

## 01 · Tide · インディーポッドキャスト

**プロンプト:**

> *"Design a landing page for Tide — an indie podcast about long-form interviews with small-studio designers. Just go ahead, pick the rest yourself."*

**推論された 3 要素**（ユーザーは委任）: audience = デザイナー、デザイン関心層 · use = 聴く + 購読 · tone = 静かなエディトリアル。

**選択:** Letter · **Salon**（暖色クリームペーパー、IBM Plex Mono マストヘッド、Cormorant Garamond 本文、暖色アンバーのキャレット） · エンリッチメントなし（タイポグラフィのみ）。

**抜粋:**

> *"Dear listener, Tide は小さなスタジオが実際にどう動いているかを扱うポッドキャストです。受注の話、未送信の請求書、シニアデザイナーが去った日、残った 4 人に何と言えばいいか分からずオフィスに座っている話。"* ヒーローは挨拶そのもの。下には、ホストの声で書かれた 3 段落、署名、そして「いつも聴いている場所で聴ける」リンクを 1 行（Apple、Spotify、Pocket Casts、Overcast、RSS）。モックアップなし、デモなし。声がブランドを運ぶ。

**ライブ:** [`_tests/01-tide-podcast/`](../../site/_tests/01-tide-podcast/index.html)

---

## 02 · Streampipe · オープンソース CLI

**プロンプト:**

> *"Build me a landing page for Streampipe — a small, fast, single-binary CLI for parsing log and event streams from stdin. Filter, transform, route. Composes with anything that emits lines. Audience: developers. Use: install + read docs. Tone: technical. Use the Terminal theme."*

**推論された 3 要素:** 明示。**テーマ指定あり。**

**選択:** Long Document · **Terminal**（ダークなフォスファーグリーン、随所モノスペース） · Tier-A インライン CSS アートのターミナルブロック（Lottie なし、実動画なし、スティッキーピンなし、散文中に埋め込み）。

**抜粋:**

> *"$ streampipe — a small, fast, single-binary CLI for parsing log and event streams from stdin."* に続いて、何をするかを説明する散文 1 段落、`tail -f access.log | streampipe parse --format nginx --filter 'status >= 500' --out json` を示すインライン `<pre>` と JSON 出力 3 行、もう 1 段落（Rust、1.2 MB バイナリ、デーモンなし、バッファなし）。下にはインストールセクション（brew · cargo · curl の 3 スニペット）、動作を説明する番号付き注 3 つ、6 行のフラグ表。純 CSS、スクリプトなし。

**ライブ:** [`_tests/02-streampipe-cli/`](../../site/_tests/02-streampipe-cli/index.html)

---

## 03 · Maple Street Bread · 職人ベーカリー

**プロンプト:**

> *"Build a landing page for Maple Street Bread — a small artisan bakery in Lisbon. Sourdough, slow, by hand. We open at seven, thirty loaves, gone by noon, no online orders. Audience: locals. Use: see what we bake, find us. Tone: warm, hand-set."*

**推論された 3 要素:** 明示。

**選択:** Catalogue · **Almanac**（暖色パーチメントペーパー、IM Fell のローマンセリフ、暖色アンバーのアクセント） · Tier-A 手書きインライン SVG のパンシルエット（1 アイテムにつき 1 つ、96 px、アニメーションなし）。

**抜粋:**

> プレートバナーのマストヘッド: *"Maple Street Bread · Lisbon · est. 2026 · n.º 47 · sourdough by hand."* 続いて中央寄せセクション: *"Today's bake — Saturday, 6:14 a.m., eight breads, gone by noon."* 下に 8 種のパンを並べた 2 列カタログ（Country sourdough · Baguette tradition · Focaccia rosemary · Boule miche · Rye dark · Brioche feuilletée · Walnut levain · Bola d'óleo）。各行に 96 px のパンシルエット、IM Fell の名前、1 行の説明、価格（または "sold out"）。下端の中央寄せ almanac パネルに来店情報と営業時間。CTA なし、要件は「何があるか見る + 行く」だから。

**ライブ:** [`_tests/03-maple-bakery/`](../../site/_tests/03-maple-bakery/index.html)

---

## 04 · Meridian · スタジオマニフェスト

**プロンプト:**

> *"A studio manifesto for Meridian — a small environmental-products design practice in Lisbon. Declarative, no flashy stuff."*

**推論された 3 要素**（部分的）: audience = 同業 + 顧客 · use = 読んで賛同するか離れる · tone = 宣言型エディトリアル。

**選択:** Quote-Led · **Brutal**（ほぼ黒のペーパー、Druk 系のコンデンスドディスプレイ、単一のイエローストライクアクセント） · エンリッチメントなし。

**抜粋:**

> 20 単語のプルクオート 1 本: *"We make products that don't outlive their use"* — "outlive" の背後に黄色のストライク。下に帰属: *"— The studio · the position we open with · this is the page."* ブリードイエローのルールの下、番号付きの原則 4 つ（Fewer things, made well · Material is the brief · Repair before replace · Slow is the deliverable）、各 1 段落の本文。最終 § Working rules — 5 つの簡潔な運用ステートメント（ショップは週 4 日稼働 · メールには自分で返す · 等）。CTA なし、推薦の声なし、ロードマップなし。

**ライブ:** [`_tests/04-meridian-manifesto/`](../../site/_tests/04-meridian-manifesto/index.html)

---

## 05 · Tracejam · SaaS オブザーバビリティ

**プロンプト:**

> *"Build me a landing page for Tracejam — a tracing/observability tool for distributed systems. Audience: SREs and platform engineers. Use case: try it / contact sales. Tone: technical."*

**推論された 3 要素:** 明示。

**選択:** Workbench · **Midnight**（ダーククールペーパー、Geist Mono ディスプレイ、フォスファーシアンアクセント） · Tier-A 純 CSS のスティッキートレースパネル（3 状態、スクロールで切り替わる、クリッピングされたブラウザフレームなし）。

**抜粋:**

> *"Tracejam · v0.4 · For SREs &amp; platform engineers. Distributed tracing that explains itself."* ヒーローは左寄せで CTA 2 つ（Try it free / Talk to sales）。右にはサンプルトレースカード、5 つのスパン（auth.verify、pricing.quote 赤・リグレッション、rates.fx オレンジ・警告、ledger.write）をフレックス子要素のバーで描画。下に 3 ステップ（open · find · read）のスティッキーウォークスルー、各ステップに 1 段落本文と小さな `$ tracejam ...` コマンド。右カラムには "REGRESSED" チップと "WHY" 説明をプレーンテキストで載せたトレースパネルがピン留め。インテグレーション 8 件のストリップ、3 ティア価格、1 行のコロフォン。

**ライブ:** [`_tests/05-tracejam-saas/`](../../site/_tests/05-tracejam-saas/index.html)

---

## 06 · Anya · パーソナル 1 ページ

**プロンプト:**

> *"Personal site for Anya — software architect in Lisbon. Don't ask, just figure it out."*

**推論された 3 要素**（ユーザーは委任）: audience = エンジニアリング採用担当 · use = 私が誰で何をしているか読む、仕事を見る · tone = 簡素、イタリックエディトリアル。

**選択:** Index-First · **Plain**（純白ペーパー #ffffff、Inter Tight ディスプレイ寄り、深いインクブルーのアクセント） · エンリッチメントなし。

**抜粋:**

> 番号付き TOC を持つスティッキー左サイドバー: *00 Index · 01 Now · 02 Years · 03 Writing · 04 Reach.* 右カラムの各セクションは自分の番号 + ラベルと clamp で設定された H2 から始まる。*"00 · Index"* は *"A small, scannable index of who I am and what I do."* で始まり、2 段落のバイオが続く。*"01 · Now"* は決済システムとモノリスからサービス移行への 2 案件同時稼働のコンサルティングを語る。*"02 · Years"* は表形式の職歴（Stripe → Monzo → Knot → independent）。*"03 · Writing"* は 5 件のリンク付き記事を日付列とともに並べる。*"04 · Reach"* は 4 セルの連絡先グリッド（email · GitHub · LinkedIn · Mastodon）。

**ライブ:** [`_tests/06-anya-portfolio/`](../../site/_tests/06-anya-portfolio/index.html)

---

## 07 · Foundry · コンプライアンス SaaS

**プロンプト:**

> *"Build me a landing page for Foundry — SOC 2 and ISO 27001 compliance automation for B2B SaaS. Show: how many companies got compliant, what it costs, who uses it. Audience: founders + CTOs. Tone: technical but trustworthy."*

**推論された 3 要素:** 明示。

**選択:** Bento Grid · **Newsprint**（暖色クリームペーパー、Source Serif 4 ディスプレイ、暖色ディープレッドのアクセント） · Tier-A 純 CSS のロゴグリッド（モノクロのワードマークプレースホルダー 8 個）。

**抜粋:**

> 新聞バナーのマストヘッドの中央にワードマーク。ヒーローは左寄り: *"Compliance, ground out in **days**, not in months."* — "days" の語を赤のイタリックで組む。右にはプルクオートパネルに CTO の推薦の声。下に 6 タイルのベントー — (1) "847." アンカー数値と 1 行キャプション、(2) 4×2 のロゴグリッドに 8 件のワードマーク、(3) 3 ティア価格スニペット（Starter $299 · Team $899 人気 · Scale カスタム）、(4) 2 つ目のプルクオート、(5) 「自動化される項目」6 行リスト、(6) 6 問の FAQ ティーザー。最後の CTA ストリップ: *"Start the trial. Cancel before the first invoice if it's not ready."* 1 行のコロフォン。

**ライブ:** [`_tests/07-foundry-compliance/`](../../site/_tests/07-foundry-compliance/index.html)

---

## 08 · Cohort · コホート型コース

**プロンプト:**

> *"Build a landing page for Cohort — the platform for cohort-based courses. Run live courses with 30 to 500 students. Built for educators, not LMS sales teams. Audience: course operators + indie creators. Tone: warm, salon-room, editorial."*

**推論された 3 要素:** 明示。

**選択:** Stat-Led · **Linen**（暖色ベージュペーパー、Inter Tight ジオメトリックサンス、暖色アンバーのアクセント） · エンリッチメントなし（タイポグラフィのみ。要件にある「30〜500」のレンジが視覚要素）。

**抜粋:**

> 中央寄せの eyebrow: *"Built for educators · not LMS sales teams."* ヒーローの数値は 22 rem で **"30 — 500"**（ダッシュは暖色アンバー）。見出し: *"Live courses, the size your roster actually is."* サブ: *"Cohort runs courses with thirty to five hundred students at once — the size of a real classroom, the size of a real lecture, and a few sizes between. With a date, a roster, and a room."* 下に補助の数値 3 つ（186 コホート実施 · 修了率 93% · 運営者 NPS 4.7/5）。運営者の推薦の声 2 つを並列。2 ティア価格（初回コホート無料 · Operator $199/月）。CTA ストリップ 1 つとコロフォン。マーキーなし、カードスタックなし、要件はタイポグラフィで運ぶ。

**ライブ:** [`_tests/08-cohort-courses/`](../../site/_tests/08-cohort-courses/index.html)

---

## レシピの整理方針

すべてのレシピは同じ 4 行構成。要件をざっと眺めて、*どの組み合わせが何に対して選ばれるか*をすぐ確認できる。

1. **プロンプト** — 原文のコピペ可能形式。
2. **推論された 3 要素** — design-context-gate が生成する内容（audience · use · tone）。3 つすべてユーザーが渡した場合は `明示`、そうでなければ `ユーザーは委任`。
3. **選択** — マクロ構造 · テーマ · エンリッチメントアーキタイプ。
4. **抜粋** — 生成された文言またはレイアウトの 1 段落。スキルを動かす前に出力が要件に合うか確認できる。

新しく何かを生成する際は、このファイル内で最も近いレシピを探し、自分の要件とレシピの**違いに注目**する。マクロ構造の選択は引き継がれることが多く、テーマは多様化ルールにより変わりやすく、エンリッチメントの Tier が動くこともある。

## レシピが*ではない*もの

- テンプレートではない。Hallmark の核心は構造的多様性であり、レシピをそのまま複製するのは **Specimen-fall-through** アンチパターン（[`SKILL.md`](../SKILL.md) のゲート 23）。
- 固定の選択ではない。同じプロジェクトでレシピ 00（Coffeebox）を続けて 2 回走らせると、*異なる*マクロ構造かテーマが出るはず。プロジェクトメモリ [`.hallmark/log.json`](../SKILL.md) がそれを強制する。
- 網羅的ではない。21 マクロ構造 × 16 テーマ × 8 エンリッチメントアーキタイプ = 2,688 種類のフィンガープリント。ここにある 9 レシピは取っかかりで、残りの 50 はあなたが発掘する。
