# Hallmark

**Claude Code、Cursor、Codex 向けのデザインスキル。AI 生成に見えることを拒む。**

[ライブデモ →](https://www.usehallmark.com) &nbsp;·&nbsp; 22 テーマ &nbsp;·&nbsp; 4 動詞コマンド &nbsp;·&nbsp; `T` キーで切り替え。

Made by Together AI.

<p align="center">
  <img src="site/OG-hallmark.png" alt="Hallmark — A design skill that refuses to look AI-generated" />
</p>

Hallmark は要件に合うマクロ構造を選び、22 テーマのいずれかをまとわせ、65 のスロップテストゲートと出力前の自己批評を走らせる。LLM が学習で身につけた既定値に乗り続けることを拒む。Hallmark が異なる要件で生成した 2 つのページは、同じテンプレートの色違いではなく別サイトに見える。

---

## 4 つの動詞コマンド

| 動詞コマンド | 動作 |
| --- | --- |
| *(デフォルト)* | 新規 UI を構築。マクロ構造を選び、ルールセットを適用し、スロップテストを実行してから返す。 |
| `hallmark audit <target>` | 既存コードをアンチパターンで採点。改善リストのみ、編集はしない。 |
| `hallmark redesign <target>` | 構造を捨て、文言・IA・ブランドは保持し、別のフィンガープリントで再構築。 |
| `hallmark study <screenshot \| URL>` | 気に入ったデザインから **DNA** を抽出。マクロ構造、タイポペアリング、カラーアンカー。ピクセルクローンと有料テンプレートは拒否。任意で他の AI ツールへの引き継ぎ用ポータブル `design.md` を出力。 |

---

## 要件が違えば形も違う

それぞれ別の要件でスキルを動かして生成したもの。スキルは毎回違う選択をし、マクロ構造もテーマも重ならない。

<table>
  <tr>
    <td width="25%"><a href="https://www.usehallmark.com/examples/tally/"><img src="docs/screenshots/hero-tally.jpg" alt="Tally — SaaS product page hero" /></a></td>
    <td width="25%"><a href="https://www.usehallmark.com/examples/wayfare/"><img src="docs/screenshots/hero-wayfare.jpg" alt="Wayfare travel booking hero" /></a></td>
    <td width="25%"><a href="https://www.usehallmark.com/_tests/09-slow-pour/"><img src="docs/screenshots/hero-slow-pour.jpg" alt="Slow Pour coffee subscription hero" /></a></td>
    <td width="25%"><a href="https://www.usehallmark.com/examples/bananastudio/"><img src="docs/screenshots/hero-bananastudio.jpg" alt="BananaStudio creative studio hero" /></a></td>
  </tr>
  <tr>
    <td><b>Tally</b><br/><sub>SaaS · modern-minimal</sub></td>
    <td><b>Wayfare</b><br/><sub>旅行 · atmospheric</sub></td>
    <td><b>Slow Pour</b><br/><sub>コーヒーサブスク</sub></td>
    <td><b>BananaStudio</b><br/><sub>スタジオ · playful</sub></td>
  </tr>
  <tr>
    <td><a href="https://www.usehallmark.com/_tests/06-anya-portfolio/"><img src="docs/screenshots/hero-anya.jpg" alt="Anya Reis personal site hero" /></a></td>
    <td><a href="https://www.usehallmark.com/examples/najm/"><img src="docs/screenshots/hero-najm.jpg" alt="NAJM Moroccan fashion brand hero" /></a></td>
    <td><a href="https://www.usehallmark.com/_tests/11-soroe-ceramics/"><img src="docs/screenshots/hero-soroe.jpg" alt="Søroe ceramics studio hero" /></a></td>
    <td><a href="https://www.usehallmark.com/examples/hyperlane/"><img src="docs/screenshots/hero-hyperlane.jpg" alt="Hyperlane developer infrastructure hero" /></a></td>
  </tr>
  <tr>
    <td><b>Anya Reis</b><br/><sub>パーソナルサイト</sub></td>
    <td><b>NAJM</b><br/><sub>ファッションブランド</sub></td>
    <td><b>Søroe</b><br/><sub>陶芸スタジオ</sub></td>
    <td><b>Hyperlane</b><br/><sub>開発インフラ</sub></td>
  </tr>
</table>

各ページは自己完結した HTML + CSS で、マクロ構造が CSS コメントに刻印されている。[usehallmark.com](https://www.usehallmark.com) または [`site/_tests/`](site/_tests/) で全件閲覧できる。

---

## インストール

```
npx skills add nutlope/hallmark
```

更新したいときは再実行。または [`SKILL.md`](SKILL.md) と [`references/`](references/) を以下にコピー。

- **Claude Code** — `~/.claude/skills/hallmark/`
- **Cursor** — `.cursor/rules/hallmark.mdc`（`SKILL.md` の本文、フロントマターなし）
- **Codex** — `~/.codex/skills/hallmark/`（個人）または `.codex/skills/hallmark/`（プロジェクト単位）

ルールセットの本体は [`SKILL.md`](SKILL.md) と [`references/`](references/) にある。実践例は [`docs/recipes.md`](docs/recipes.md) と [`docs/study-examples.md`](docs/study-examples.md)。

---

## ライセンス

MIT。使い、フォークし、出荷してよい。
