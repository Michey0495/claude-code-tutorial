# design.md — オプトインのポータブルデザインシステム

[`SKILL.md`](../SKILL.md) Step 6 から、ユーザーが現在のビルドのデザインシステムをポータブルファイルにロックするよう明示的に依頼したときのみ読み込まれる。デフォルトの動詞コマンドは `design.md` を自動生成しない。ユーザーは自由に反復し、システムが固まったと言ってから依頼する。

このファイルは [`study.md`](study.md) からも読み込まれる。`study` 診断が成功した後、ユーザーが DNA をポータブルシステムとして書き出すよう依頼したとき。下記のフォーマットは2経路で共有される。差分は § 2つの出力経路（default vs study）と [`study.md`](study.md) § Emitting a `design.md` from `study` で記述する。

## トリガー（フレーズのみ。新しい動詞コマンドではない）

ユーザーが下記のいずれかを言ったときだけ発火する。

- *"lock the system"* / *"lock the design system"* / *"lock the DNA"* / *"lock this DNA"*
- *"give me a design.md"* / *"write a design.md"* / *"export this as a design.md"*
- *"extract this to a design system"* / *"extract the tokens"* / *"extract the DNA"*
- *"make this portable"* / *"make the DNA portable"*
- *"I want to use this in another project"*

それ以外は全部スキップ。デフォルトのビルド、単一ページに対する redesign 動詞、同じ要件への自由な反復も含む。単一ページの redesign とデフォルトの動詞コマンドは `tokens.css` 経由でトークンをポータブルに保つ。`design.md` は明示的なロックインのステップ。

## 2つの出力経路（default vs study）

同じ `design.md` フォーマットを2つのエントリポイントから出す。どちらの信号を種にするか、拒否層の厳しさが違う。

| | **デフォルト動詞コマンド経路**（lock the system） | **study 動詞コマンド経路**（lock the DNA） |
| --- | --- | --- |
| **トリガー文脈** | 1回以上のビルドをユーザーが反復し、満足した後 | `study` 診断が成功した後（画像または URL） |
| **トークンの出処** | ビルドのインメモリのトークン状態 | 解析した DNA。URL モードでは CSS から正確に、画像モードでは帯から推定 |
| **拒否層** | なし。反復したビルドはユーザー自身のもの | より厳しい。[`study.md`](study.md) § Emission-refusal layer 参照。URL モードは認証応答が必要。第三者 URL は拒否 |
| **`## Provenance` ブロック** | 省略（システムはユーザー自身の作業） | 必須。ソースモード、URL または "image"、日付、認証応答、確度メモを記録 |
| **`## Notes` ブロック** | 任意。覚える価値のある決定を記す | 必須。診断の「持ち越さないアンチパターン」リストを記録 |

両経路とも以降の Hallmark 実行で読める `design.md` を生成する。書き出されたファイル形式は統一されている。

## スコープ

- **ページビルド限定。** コンポーネント単位はスキップ。単一コンポーネントはシステムには小さすぎる。
- **複数ページ redesign は既存挙動を維持。** `hallmark redesign --multi-page` は [`verbs/redesign.md`](verbs/redesign.md) § Multi-page flow に従って重量級の `design.md` を生成する。あちらは既にシステムをロックする前提なので、ルールは変えない。
- **上書き禁止ポリシー。** プロジェクトルートに `design.md` が既存ならば上書きしない。代わりに `## Exports` セクションを更新し、1行で出力する。*"design.md detected — refreshed Exports, system unchanged."*

## CTA — Step 5 プレビューでオファーを表面化する

デフォルト＋ redesign のページビルド後、プレビューブロックの末尾に控えめな1行を加える。

> *System portable? Say `lock the system` to extract this build's tokens + voice into a `design.md`.*

(a) ビルドがコンポーネント単位、または (b) プロジェクトに `design.md` が既存（既にロック済み）のときは CTA をスキップする。

## フォーマット（タイト版）

ファイルはプロジェクトルートに書く。プロジェクトの大文字小文字慣習に合わせる（`design.md` または `DESIGN.md`）。約45行を目標。実アプリの種になる量があり、維持するべき wiki にはならない量。フォーマット。

````markdown
# Design — <Project name>

Locked design system. Future Hallmark runs read this file first; pages defer
to it. Amend intentionally — the file is the rule.

## System
- Genre · <editorial / modern-minimal / atmospheric / playful>
- Macrostructure · <name>
- Theme · <catalog: NAME · or · custom (vibe: "<4–8 words>")>
- Axes · <paper-band> / <display-style> / <accent-hue>

## Tokens (canonical · `tokens.css` is the source of truth)
```css
:root {
  --color-paper:      oklch(<L> <C> <H>);
  --color-paper-2:    oklch(<L> <C> <H>);
  --color-ink:        oklch(<L> <C> <H>);
  --color-ink-2:      oklch(<L> <C> <H>);
  --color-rule:       oklch(<L> <C> <H>);
  --color-accent:     oklch(<L> <C> <H>);
  --color-accent-ink: oklch(<L> <C> <H>);
  --color-focus:      oklch(<L> <C> <H>);

  --font-display: "<face>", ...;
  --font-body:    "<face>", ...;
  --font-mono:    "<face>", ...;

  /* 4-pt spacing scale, named: --space-3xs … --space-4xl. See tokens.css.   */
  /* Type scale, 1.25 (major-third) ratio: --text-xs … --text-display.       */

  --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
  --dur-fast: 180ms;  --dur-base: 240ms;  --dur-slow: 320ms;

  --radius-card: <px>;  --radius-pill: <px>;  --radius-input: <px>;
}
```

## CTA voice
- Primary · <fill colour> · <radius> · <padding rhythm>
- Secondary · <outline / ghost> · <same radius>

## Motion stance
- <silent · 1–2 reveal primitives · motion-cut>
- Reduced-motion fallback · ≤150 ms opacity crossfade.

## Exports
`tokens.css` (in this project) is the source of truth. For Tailwind v4
`@theme`, DTCG `tokens.json`, or shadcn/ui CSS variables, ask *"extend
design.md with Tailwind exports"* (or the format you want) — Hallmark will
append them per [`export-formats.md`](export-formats.md).
````

ファイル書き込み前に選択を声に出す。*"Genre: editorial. Macrostructure: Long Document. Theme: catalog Editorial. Locking this as the project's system."*。それから書き込む。

## ファイル作成後

`design.md` が存在すれば、[`SKILL.md`](../SKILL.md) Step 0 のプリフライト検査が以降の実行で検出する。それ以降。

- 以降のすべての Hallmark 実行は最初に `design.md` を読む。続く選択（ジャンル／テーマ／タイポグラフィ／モーション／ CTA voice）はそれに従う。
- 多様化ルールが反転する。ページはシステムを *共有* する。互いに違わせるのではない。
- 将来のページが本当に別のシステムを必要とするなら、ローカルで上書きせず `design.md` に `## Variants` セクションを追加する。ファイルは進化させ、ページ単位の上書きはしない。

## オプトインの理由（自動出力にしない理由）

要件は反復される。最初のビルドが落ち着いたデザインであることはまれ。デフォルトビルドのたびに `design.md` を自動生成すると、反復のたびにファイルがブレるか、ユーザーがレビューする前に弱いシステムをロックすることになる。オプトインはデザインチームの実際の働き方を反映する。パターンが固まってから形式化する。1日目ではない。プレビューブロックの CTA がこの機能を強要せずに発見可能にする。
