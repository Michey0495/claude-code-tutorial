# ジャンル — editorial（デフォルト）

Hallmarkの正典の声。コンテンツ主導のブリーフ向けに作るページ。ポートフォリオ、マニフェスト、タイプスペシメン、エージェンシーサイト、雑誌記事、インディーポッドキャスト、ベーカリーやブランドの物語、考え抜かれたB2Cマーケティング。

他のジャンル信号が立たないときのHallmarkの姿。沈黙のデフォルト。

## いつ選ぶか

デフォルト。ブリーフが特殊な美意識を名指さないとき、たとえば「Xのランディングページを」とだけ言われ、Xがエンタープライズなのか、atmosphericなのか、playfulなのか示されないとき。ほとんどのブリーフはここに着地する。

## このジャンルに属するテーマ

`Specimen`、`Newsprint`、`Atelier`、`Garden`、`Salon`、`Linen`、`Almanac`、`Studio`、`Riso`、`Sport`、`Brutal`、`Manifesto`。12テーマ。ジャンル内で十分にバリエーションが取れる。

## 声

- **Display** — イタリックセリフ、コンデンスド・サン、もしくはディスプレイ重視。Interでもなく、Geistでもない。ウェイトは極端寄り（300または700以上）。
- **Body** — 働き者のセリフ（Newsreader、Cormorant）、もしくはプレーンで非デフォルトのサン（The Future、Söhne）。45〜75ch で可読。
- **Accent** — 単一の暖色か寒色。どのビューポートでも全体の5%未満で使う。
- **Layout** — 非対称。カード枠ではなくヘアライン罫。たっぷりの余白。
- **Motion** — 静か。オーケストラされた入場が1回だけ。バウンスなし。
- **Copy tone** — 具体的、手で組んだ感触、わずかに文学的。形容詞より動詞。

## このジャンルで許容するもの

- ヘアライン罫、フルーロン、ドロップキャップ、ダブル罫。
- 長文コンテンツでのイタリック本文。
- 散文ページの非対称カラム比（2:5、3:7）。
- 手描きSVGイラスト、純CSSアート（Tier A enrichment）。
- 番号付きディスプレイラベル、エッジに揃えた見出し。
- 単一アクセント色のハイライト（x-height位置の `<mark>` 帯）。

## このジャンルで禁じるもの

普遍のスロップテストゲートに加え、editorial固有の禁止項目:

- **ピル形ボタンにグラデーションフィル** — ピル自体は可、ピルの上のグラデは不可。
- **すべて中央寄せのヒーロー**（ゲート7普遍）。editorialのヒーローは左寄り、または非対称。
- **カード内カード**レイアウト（ゲート4普遍）。
- **3カラム等間隔のアイコンタイル機能グリッド**（ゲート3普遍）。
- **グラスモーフィズム** — 不可。媒体は紙であってガラスではない。
- **純黒・純白**を紙やインクに（ゲート8）。アンカーに向けてすべて色を寄せる。

## 声のフィクスチャ

editorial配下の各マクロ構造は以下の冒頭文パターンから選ぶ。*形*を真似て、言い回しは借りない。

- *"Type, set with care."*
- *"Print discipline, on screen."*
- *"A small skill that argues against the average."*
- *"We compose the page like a broadsheet — hairlines, columns, restraint."*
- *"Restraint, repeated, becomes a signature."*

## ナビとフッターの声

- **デフォルトnav:** N6 Newspaper masthead — フル幅、大きな中央配置のワードマーク、セリフのスモールキャップスで号数／日付の細い行、その下にダブル罫。ブロードシート的に読ませる。
- **許容範囲:** N1 Wordmark + 2 links（行き先が最小限のとき）、N9 Edge-aligned minimal（ページが手紙形やアトリエ的に静かなとき）。
- **デフォルトfooter:** Ft1 Mast-headed（ワードマークが横一文字の帯を支え、その脇にタグラインと小さなリンク）。
- **許容範囲:** Ft2 Inline single line、Ft4 Dense colophon（newsprint／almanac の声）、Ft6 Letter close（atelier／garden／personalの声）、Ft7 Newsletter-first（ブランドが正当に発刊しているとき）。
- **editorialで禁止:** N5 Floating pill（modern-minimalの語彙）、N7 Brutal slab（静けさと戦う）、Ft8 Marquee scroll（動きが多い。違うジャンル）。

完全なアーキタイプとコードは [`component-cookbook.md`](../component-cookbook.md) の § Navigation と § Footers を参照。

## スタンプ署名

出力CSSコメントヘッダーは次の形:

```css
/* Hallmark · genre: editorial · macrostructure: <name> · theme: <name> · enrichment: <tier> · nav: <N#> · footer: <Ft#> */
```
