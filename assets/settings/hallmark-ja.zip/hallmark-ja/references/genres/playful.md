# ジャンル — playful（プレイフル）

コンシューマー／フレンドリー／オンボーディング主導のページ向け。柔らかいサーフェス、控えめな色味、ホバーに応答するモーション、親しみのある声。StripeのAPIドキュメントというよりNotionのマーケやFigmaのオンボーディングに近い。

## いつ選ぶか

ブリーフが以下のいずれかに触れたとき: *fun, consumer, casual, family, kids, friendly, approachable, onboarding-heavy, community, social, tactile-but-soft, post-Linear-soft*。playfulは控えめに選ぶ。多くのコンシューマーブリーフは、ユーザーが明示的に*もっと柔らかく*て*もっとフレンドリー*と言わない限り、editorial（暖かい紙、手組み）に着地する。

## このジャンルに属するテーマ

`Plume`（正典）。playfulは過剰になりやすいので、ジャンルを意図的に小さく保つ。

## 声

- **Display** — Geist Sans 600 をやや詰めて（`-0.025em`）、もしくはブリコラージュ風ディスプレイの700。親しみがあるが幼くない。
- **Body** — Geist Sans 400、ややくすませたインク（純黒ではない）。
- **Accent** — 柔らかなインディゴ、暖かいコーラル、くすんだローズを低彩度で。常に低く——飽和したコンシューマーアプリの跳ね方はしない。
- **Layout** — わずかに丸めたサーフェス、柔らかなドロップシャドウ、親しみのあるカードのエッジ（12px半径が上限）。
- **Motion** — ホバーに応答（カードがわずかに浮く）。セクションあたり1回、跳ねない控えめなリビール。UIステートにスプリング物理は使わない。
- **Copy tone** — 暖かく、直截、具体的。奇をてらわない。 *"Made for teams who write together."* の方が *"For the squad ✨"* より良い。

## このジャンルで許容するもの

- **柔らかなドロップシャドウ**をカードに（`0 8px 24px -10px <accent at low chroma>`）。抑制的に。
- カードに**12px半径**、入力に8px、ピルに999px。
- カードの**ホバーリフト**アニメーション（`translateY(-2px)` ＋影の拡張）。
- 交互セクションの**淡い色付き背景**（paper-2と paper、色付き帯を挟む）。
- **柔らかなアクセント色** — `oklch(50% 0.13 282)`（インディゴ）や同等。彩度0.16を超えない。

## このジャンルで禁じるもの

- **飽和したコンシューマーアプリのピンク／パープル** — フレンドリーでも色は低彩度のまま。
- **装飾としての絵文字** — コピー内に絵文字が出る（"we built X 🌱"）のは可、アイコンを置き換える視覚装飾としては不可。
- **Comic Sans、Comic Neue、「私たちはおふざけです」と発信する書体** — playfulは洗練を保つ。
- **バウンス／オーバーシュート系のイージング** — ゲート13普遍ルール。playfulもスムーズなイージングを使う。
- **グラスモーフィズム** — 全ジャンルで禁止。
- **グラデーションテキスト** — ゲート5普遍ルール。禁止のまま。

## 声のフィクスチャ

- *"Made for teams who write together."*
- *"Soft, but exact."*
- *"Software can be soft and exact at once. That's the trick."*
- *"For the people who keep things tidy."*
- *"A small tool, gently opinionated."*

## ナビとフッターの声

- **デフォルトnav:** N7 Brutal slab — 重い大文字のワードマーク＋トラッキングを開けた大文字リンク＋2pxの下ボーダー。声は大きいが端正。
- **許容範囲:** N1 Wordmark + 2 links（行き先が最小限のとき）、N3 Side-rail（長いスクロールでセクション番号付きのとき、たとえばStudio）。
- **デフォルトfooter:** Ft8 Marquee scroll — タグラインを水平に繰り返し、ドットで区切る。`prefers-reduced-motion: reduce` を尊重。
- **許容範囲:** Ft5 Statement、Ft3 Index columns（ページがハブのときに限る）。
- **playfulで禁止:** N5 Floating pill（modern-minimalの語彙、声と戦う）、N6 Newspaper masthead（editorial）、Ft6 Letter close（暖かく静かな声、違うジャンル）。

完全なアーキタイプとコードは [`component-cookbook.md`](../component-cookbook.md) の § Navigation と § Footers を参照。

## スタンプ署名

```css
/* Hallmark · genre: playful · macrostructure: <name> · theme: <name> · enrichment: <tier> · nav: <N#> · footer: <Ft#> */
```

## 参照レジスタ

目指す美意識。柔らかなサーフェス、低彩度の色、親しみつつ抑制された書体、ホバー応答型のモーション。Linear以降のソフト学派。子供っぽくない、おふざけのためのおふざけもない。
