# ジャンル — atmospheric（雰囲気重視）

AIクリエイティブ系プロダクトのページ向け。暗いキャンバスに暖色のラジアルブルーム、強気のサンディスプレイ、表現的だが平易な英文コピー、単一の暖色アクセント。生成系の音楽・動画・画像・音声など、夜更けに使いたくなるツールの空気。

## いつ選ぶか

ブリーフが以下のいずれかに触れたとき: *AI tool, generative, music, video, image, voice, late-night, atmospheric, dark mode, expressive, creative tool, model playground, vibe-coded, dreamlike, nocturnal*。ユーザーが暗さを要求する*ムード*（「moody」「cinematic」「after hours」など）を名指したときも選ぶ。

## このジャンルに属するテーマ

`Bloom`（正典）、`Midnight`、`Terminal`。3つのダークペーパーテーマ。atmosphericが有効のときローテーションはこの3つを巡る。

## 声

- **Display** — Geist Sans 600や同等の太いサンセリフ、平易な英語、装飾なし。レタースペーシングはタイト（`-0.03em`以下）。
- **Body** — 同ファミリーの400。暗背景に明るいグレー（`oklch(86% 0.008 40)`）。
- **Accent** — 単一の暖色（オレンジ／琥珀／赤／ピンク）。キャンバスのラジアルグラデブルーム、フォーカスリング、小さなタグに使う。ディスプレイテキストには使わない（ゲート5の普遍ルール。グラデーションテキストは禁止のまま）。
- **Layout** — 中央寄せ／ほぼ中央寄せのヒーロー。キャンバス自体がデザイン。タイポは雰囲気のある地の上に乗る。
- **Motion** — フェードインのみ。スライドもバウンスもなし。空気感が仕事をする。
- **Copy tone** — 直截、わずかに詩的、具体的。 *"Make a house song about quitting your job."* がキャリブレーション。

## このジャンルで許容するもの

- **本文背景のラジアルグラデブルーム** — 最大2つ、各々フットプリント約20〜30%、fixed-attached、アニメーションなし。ゲート31の普遍ルールはここで緩む。
- **中央寄せヒーロー** — ゲート7の普遍ルールが緩む。キャンバスがタイポを額装する。
- **ピル状のCTA**にアクセントフィル — 強気、パステルではない。
- **グロー影**をホバー時に（カードが暖かい影とともにユーザー側へ浮く）。
- **より大きな表現的タイポ** — ディスプレイは6remまで可（`clamp(3rem, 6vw + 1rem, 6rem)`）。

## このジャンルで禁じるもの

- **ライトペーパーの美意識** — キャンバスは暗い。白セクションを忍ばせない。
- **イタリックセリフの本文** — atmosphericは上から下までサンセリフ。
- **ヘアライン** — atmosphericはヘアライン罫ではなく、`paper-2`や`paper-3`の浮上カードを使う。
- **複数のアクセント色相** — 暖色のブルーム1つ＋セカンダリ（ピンク／赤）1つが最大。ティールと琥珀を併用しない。
- **グラスモーフィズム** — 禁止。atmosphericは*雰囲気*であってガラスではない。
- **グラデーションテキスト** — ゲート5の普遍ルール。禁止のまま。

## 声のフィクスチャ

- *"Built for the dark."*
- *"The page should feel like a place you could sit in."*
- *"A canvas, then a tool."*
- *"Generate, refine, ship — between Tuesday and Wednesday."*
- *"The instrument is dark. The output is yours."*

## ナビとフッターの声

- **デフォルトnav:** N5 Floating pill — ブラー背景がatmosphericなムードを売る。ピルが暗いキャンバスの上に浮き、ブルームがブラー越しに透ける。
- **許容範囲:** N9 Edge-aligned minimal（キャンバスが強くてナビが溶け込むべきとき）、N4 ⌘K-only（読者層が技術者のとき）。
- **デフォルトfooter:** Ft5 Statement — 一文でページを閉じる。atmosphericなページは何かを主張する。フッターがそれを言い切る。
- **許容範囲:** Ft1 Mast-headed、Ft2 Inline single line。
- **atmosphericで禁止:** N6 Newspaper masthead（エディトリアルの語彙）、N7 Brutal slab（静けさと戦う）、Ft8 Marquee scroll（動きが暗いキャンバスを壊す）、Ft3 Index columns（AIフッターの指紋）。

完全なアーキタイプとコードは [`component-cookbook.md`](../component-cookbook.md) の § Navigation と § Footers を参照。

## スタンプ署名

```css
/* Hallmark · genre: atmospheric · macrostructure: <name> · theme: <name> · enrichment: <tier> · nav: <N#> · footer: <Ft#> */
```

## 参照レジスタ

目指す美意識。暗いキャンバスにコンテンツの背後で2つの暖色ブルーム、平易な英語の英雄的ディスプレイ、小サーフェスにのみ単一の暖色アクセント。手作りで、ストックAIではない。
