# ジャンル — modern-minimal（モダンミニマル）

洗練されたエンタープライズ／開発ツール／APIページ向け。Stripe／Linear／ElevenLabsの学派。Geistサン、確信に満ちた大型ディスプレイ、たっぷりの余白、ピル形CTA、モノクロ＋任意の単一アクセント。選択の不在ではなく、確信あるミニマリズム。

## いつ選ぶか

ブリーフが以下のいずれかに触れたとき: *SaaS, enterprise, API, platform, developer tool, infra, B2B, dashboard, billing, Stripe-like, Linear-like, ElevenLabs-like, dev experience, ship fast*。ユーザーがブランドカラーを名指しつつ、それ以外は抑制的なときも選ぶ。

## このジャンルに属するテーマ

`Quiet`（正典）。今後このジャンルに加わるテーマは、モノクロまたはほぼモノクロで、Geist／Interクラスのサンディスプレイとピル形CTAを使うもの。

## 声

- **Display** — Geist Sans 500〜700、Inter Tight Display 600以上、または同等。レタースペーシングはタイト（`-0.02em`〜`-0.035em`）。
- **Body** — Geist Sans 400、Inter 400。ディスプレイと同じファミリー（単一ファミリーの規律）。
- **Accent** — モノクロ（アクセント=インク）、もしくはフォーカスリングのみに使う抑制された単一色相。色面の氾濫はなし。
- **Layout** — 2カラムのヒーロー（タイトル左、リード右）、たっぷりの余白、控えめなボーダーで洗練されたカードサーフェス。
- **Motion** — 最小限。リビールはオフ。ページは構成済み。
- **Copy tone** — 宣言的、具体的、技術的。「Built for X」自体は禁止しないが、Xを具体的に名指すこと。

## このジャンルで許容するもの

- **ピル形CTA** — フィルドと輪郭の両方。黒フィルのプライマリ＋白輪郭のセカンダリが正典のペア。
- **純白の紙**（`#fff` / `oklch(100% 0 0)`） — ゲート8がここで緩む。
- **クロマゼロのニュートラル** — ゲート24がここで緩む。Stripe／ElevenLabsの学派は設計上モノクロ。
- **タイトル左＋本文右の2カラムヒーロー** — このジャンルでは明示的に正典。
- **洗練されたカードサーフェス**。ごく控えめなボーダー（`oklch(91% 0 0)`）と8px半径。
- **大きくタイトに組んだディスプレイ**（`clamp(2.5rem, 5vw + 0.5rem, 4.75rem)`）。

## このジャンルで禁じるもの

- **イタリックセリフの本文** — modern-minimalは上から下までサンセリフ。
- **すべてヘアライン** — ボーダーは細いが見える程度。editorialの0.5pxヘアラインの美意識ではない。
- **非対称な散文カラム** — modern-minimalは左揃え、規則的なグリッドにジャスティファイ。
- **ドロップキャップ、フルーロン、装飾** — どれも使わない。
- **バウンス／オーバーシュート系のイージング** — ゲート13普遍ルールが厳格に適用。
- **グラデーションテキスト** — ゲート5普遍ルール。禁止のまま。
- **グラスモーフィズム** — 禁止。

## 声のフィクスチャ

- *"Built to ship."*
- *"The platform that scales with you."*
- *"From idea to production in an afternoon."*
- *"Thirty thousand teams build with X."*
- *"One API. Every channel."*

## ナビとフッターの声

- **デフォルトnav:** N5 Floating pill — コンテンツ幅、エッジから離す、ブラー背景、柔らかな影。Vercel／Linear／Framer／Raycastの語彙。
- **許容範囲:** N1 Wordmark + 2 links（行き先が本当に最小限のとき）、N9 Edge-aligned minimal（ブランドが沈黙を許されるとき）。
- **デフォルトfooter:** Ft2 Inline single line — ワードマーク＋タグライン＋小さなクレジット、上にヘアライン罫。抑制的。
- **許容範囲:** Ft1 Mast-headed、Ft5 Statement（ページが終わりの一文を欲しがるとき）。
- **modern-minimalで禁止:** N6 Newspaper masthead（editorialの語彙）、N7 Brutal slab（抑制と戦う）、Ft8 Marquee scroll（動きが多い。違う声）、Ft3 Index columns を彩度全開で（AIフッターの指紋——ゲート52）。

完全なアーキタイプとコードは [`component-cookbook.md`](../component-cookbook.md) の § Navigation と § Footers を参照。

## スタンプ署名

```css
/* Hallmark · genre: modern-minimal · macrostructure: <name> · theme: <name> · enrichment: <tier> · nav: <N#> · footer: <Ft#> */
```

## 参照レジスタ（LLM向け、誰にもクレジットしない）

目指す美意識。確信に満ちたサンディスプレイ、清潔な白いキャンバス、2カラムのヒーロー、ピル形CTA、モノアクセント。ユーザーは見ればわかる。出力に外部サイト名は書かない。
