# 構造

AI 生成の UI のほとんどは見た目は別物だが構造的に同一。ヒーロー → フィーチャー3つ → CTA → フッター。同じ見出し位置、同じカラム数、同じコンポーネント語彙。**構造の同一性こそが AI の指紋。視覚の同一性ではない。** Hallmark の仕事はそれを破ること。

このファイルは構造的多様性の **プリミティブな軸** をカタログ化する。ほとんどのビルドでは、このファイルから軸ごとに指紋を組み立てるべきではない。代わりに [`macrostructures.md`](macrostructures.md) からマクロ構造を選ぶ方が速く、デフォルト引力による同一化を防ぐ。マクロ構造のデフォルトから1〜2軸だけ外れたいときや、既存ページを監査して見えているものを語る語彙が必要なときに使う。

下記の軸は依然としてビルディングブロック。各軸から1つ選び、*構造の指紋* を成す。2つのページが同じ指紋を共有してはならない。

## 6つの軸

### 1. セクション見出しの配置

セクションのタイトルは空間のどこに置かれるか。ページごとに1つ選ぶ。

| パターン | 説明 | 実例 |
| --- | --- | --- |
| **Left-margin** | ⚠️ **オプトインのみ — 決してデフォルトにしない。** 細い左カラムにアイブロウ／番号／ラベル、右に見出し＋本文。SaaS／開発者ツール／コンシューマ向けページに適用すると、テンプレ編集 AI の痕跡として読まれる。ユーザーが editorial／specimen レイアウトを明示的に要求し、かつアイブロウが見出しとペアにならないときのみ許可（ラベルは本文の傍に置いてよい。見出しは別行で上に置く）。アイブロウ左／見出し右のバリアントは gate 66 で完全禁止。 | The New York Times Magazine; ユーザーが明示的にそのボイスを要望したときの当方の Specimen テーマ。 |
| **Hanging** | 見出しがセクションの *上* のネガティブスペースに浮かぶ。ゆったりした息継ぎ。 | David Airey のポートフォリオ；ミニマル・モダニスト。 |
| **Centered display** | 見出しがセンターを支配、対称。フォーマルで歓迎的だが、多用すると静的に感じる。 | Apple プロダクトページ；Atelier 風ランウェイ招待状。 |
| **Bottom-aligned** | 見出しがセクションの *底* を支える。コンテンツはその上を流れる。階層を反転する。 | Swiss editorial；Newsprint のマストヘッド下置きパターン。 |
| **Overlapping image** | 見出しを写真や色ブロックの上に重ねる。強いコントラストが要る。 | Pentagram のプロジェクトページ；Manifesto ポスター。 |
| **Sticky / pinned** | 下を本文がスクロールしても見出しは留まる。方向付けの補助。 | GSAP ScrollTrigger ドキュメント；Almanac 風のリファレンス。 |
| **Numbered display** | ⚠️ **オプトインのみ — 決してデフォルトにしない。** 「01.」とルール線、その横に見出し。手順的で、順序付き。デフォルトの SaaS／コンシューマ／開発者ツール向けページでは gate 66 が禁ずる（タグを見出しの横に置くのはテンプレの痕跡）。ユーザーが番号付き／章立てを明示的に要求し、かつマクロ構造が Long Document、Manifesto、Catalogue の番号付きであるときのみ許可。それでも縦積みのバリアントを優先する。番号は見出しの上に独立行で。 | Rauno Freiberg のポートフォリオ — ユーザーがそのボイスを明示的に呼び出したとき。 |
| **Inline with body** | セクションブレイクなし。見出しが段落フローから現れる。会話的。 | Medium 記事；長文エッセイ。 |

### 2. 本文の構成

「65ch の単一カラム」以外の長文レイアウト。

| パターン | いつ | リファレンス |
| --- | --- | --- |
| **Single column** | ナラティブ重視、読み手主導。編集色のデフォルト。 | 多くのブログ。 |
| **Two-column asymmetric** | 広い本文＋メタデータ／キャプション／傍注用の細いマージン。 | Semplice；Linen 風。 |
| **Multi-column justified** | 新聞リズム。2〜3 本の細いカラム、ハイフネーション、両端揃え。 | The Guardian；FT.com；Newsprint。 |
| **Marginalia** | 広めの外側マージンの傍注が本文と並走する。 | Tufte CSS；学術出版。 |
| **Three-column equal** | 百科事典／リファレンス／データ密度。チャンク化、スキャン可能。 | Wikipedia；Whole Earth Catalog；Almanac。 |
| **Full-bleed with margin reset** | 本文は 65ch、プルクォートや画像はビューポート全幅にブリード。スケール変化での強調。 | Medium のプルクォート；Manifesto セクション。 |
| **Asymmetric spans** | カラム幅が変化。CSS Grid で意図的に 2-1-3 比率。 | Locomotive；ポートフォリオサイト。 |

### 3. ディバイダーの言語

セクションはどう区切るか。

- **Hairline rule.** 0.5–1px の線、インセットか全幅。Hallmark のデフォルト。モダニスト。
- **Ornament.** フルーロン（`❦`）、中央のドット、幾何学的マーク。サロン、編集の古典。
- **Negative space.** ルール無し。ギャップ *が* ディバイダー。Apple、Linen、モダンミニマリズム。
- **Bleed-color block.** セクション背景色がシフト。色の境界がディバイダー。Manifesto、Brutal。
- **Double rule / typographic mark.** 上下2本の線を密接させる。Newsprint のマストヘッドのサイン。

### 4. ボタンの声

CTA はどう発生するか。

- **Outlined.** 枠線、塗りなし。二次的、または静かな一次。Hallmark のデフォルト。
- **Unstyled link.** 下線の付いた単語、ボックスなし。タイポグラフィを信頼する。編集色／クラフト系。
- **Oversized solid.** アクセント色の大ブロック、十分なパディング。Manifesto、Sport、ステートメント CTA。
- **Typographic-only.** 特定のウェイト／サイズ／色の単語。ルールもボックスもなし。クリック可能なヘッドラインのよう。Atelier、Salon。
- **Form-as-CTA.** ボタンがインラインフォームの一部。アクションは「このフィールドを埋める」。ニュースレター登録。

### 5. 画像の扱い

画像はどうページに入るか。

- **Full-bleed.** エッジ・トゥ・エッジ、ビューポート幅。建築としての画像。Manifesto、Sport。
- **Tightly cropped.** 小さく、意図的、グリッドに合わせる。Almanac、Atelier の静物。
- **Inline with text.** 段落のリズムの中に画像が流れ、measure に合わせる。編集色、Newsprint。
- **Margin-aligned.** 画像が広い外側マージンに座る。本文は途切れない。Linen、Tufte。
- **None.** 画像なし。タイポグラフィですべてを担う。Specimen、Manifesto-as-text-poster、Terminal。

### 6. リビールのパターン

ページロード時とスクロール時に何が起こるか。

- **Fade-up stagger.** デフォルト。穏やかで広く安全。指数 ease-out で1回だけオーケストレーション。
- **Horizontal sweep.** 要素が片側からスライドイン。clip-path か transform。方向性のあるモメンタム。
- **Type-unmask.** clip-path がテキストの上を開く。タイプがヒーローのときに優雅。
- **Number-tick.** 0から最終値までのカウンター。スタット、価格、日付。Almanac、ダッシュボード。
- **Typewriter.** 文字単位。メディアに対して正直。Terminal のみ。**装飾グラフィックの制約:** ターミナル出力にスタンドアロンのスキャンライン、切り離された点滅カーソル、ランダムな ASCII アートを含めない。ターミナルカーソル（`▮`）は、タイプ中のコマンドの *中*（インストールコードブロック、N8 Terminal コマンドナビ）に座り、「次に入力する」アフォーダンスとして機能するときのみ許可。ヒーロー隅の浮遊カーソルは装飾。削除する。[`microinteractions.md`](microinteractions.md) の Caret blink 行を参照。
- **None.** ロード時に全部既に在る。動くべきでないサイトもある。Pentagram、ブルータリスト系。

## 指紋の選び方

指紋＝各軸から1つ選ぶ。組み合わせは 8 × 7 × 5 × 5 × 5 × 6 = **42 000** 通り。尽きることはない。

選択を律する2つのルール。

1. **整合性。** 多カラム両端揃え本文の Newsprint ページなら、CTA は大型ソリッドではなくタイポグラフィのみ。声を共有しない選択は混ぜない。同じ *世界* に属する選択をする。
2. **反復回避。** 同じセッション内で連続するページは、6軸のうち3つを超えて共有しない。直前のページが left-margin headings ＋ single column ＋ hairline divider ＋ outlined button なら、このページは少なくとも3つで違わせる。

## テーマ別の推奨指紋

各 Hallmark テーマにはデフォルトの構造的指紋がある。要件がテーマを指定するときの出発点としてのみ使う。**ほとんどのビルドでは [`macrostructures.md`](macrostructures.md) からマクロ構造を選ぶ** — テーマは *視覚表面* を、マクロ構造は *ページ形状* を語る。後者の方が多様性を駆動する。

下表はテーマのアルファベット順。最初の行＝デフォルトという引力を打ち消すため。デフォルトのテーマは存在しない。**Nav** と **Footer** 列は [`component-cookbook.md`](component-cookbook.md) のデフォルト原型を指す。ルーティング表は同ファイルにあり、許容できる代替を載せている。

| Theme | Heading | Body | Divider | Button | Image | Reveal | Nav | Footer |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Almanac | Sticky | Three-column equal | Hairline | Outlined | Inline | Number-tick | N3 Side-rail | Ft3 Index columns |
| Atelier | Centered | Single column | Negative space | Typographic-only | Tightly cropped | Type-unmask | N9 Edge-min | Ft6 Letter close |
| Aurora | Hanging | Single column | Negative space | Typographic-only | None | Fade-up | N5 Floating pill | Ft5 Statement |
| Bloom | Centered | Single column | Negative space | Typographic-only | None | Fade-up | N5 Floating pill | Ft5 Statement |
| Brutal | Overlapping image | Full-bleed reset | Bleed-colour | Oversized solid | Full-bleed | Horizontal sweep | N7 Brutal slab | Ft8 Marquee scroll |
| Coral | Centered | Single column | Negative space | Outlined | Margin-aligned | Fade-up | N5 Floating pill | Ft1 Mast-headed |
| Garden | Hanging | Marginalia | Negative space | Unstyled link | Margin-aligned | None | N9 Edge-min | Ft6 Letter close |
| Halo | Centered | Single column | Negative space | Outlined | None | Fade-up | N5 Floating pill | Ft5 Statement |
| Linen | Hanging | Two-column asymmetric | Negative space | Unstyled link | Margin-aligned | Fade-up | N6 Masthead | Ft1 Mast-headed |
| Manifesto | Overlapping image | Full-bleed reset | Bleed-colour | Oversized solid | Full-bleed | Horizontal sweep | N7 Brutal slab | Ft5 Statement |
| Midnight | Numbered display | Single column | Hairline | Typographic-only | None | Typewriter | N5 Floating pill | Ft2 Inline single line |
| Newsprint | Bottom-aligned | Multi-column justified | Double rule | Outlined | Inline | None | N6 Masthead | Ft4 Dense colophon |
| Plume | Hanging | Single column | Bleed-colour band | Outlined | Margin-aligned | Fade-up | N9 Edge-min | Ft1 Mast-headed |
| Editorial | Hanging | 2-col asym hero / single below | Hairline | Outlined | Tightly cropped or generated (Tier C) | Fade-up | N6 Masthead | Ft1 Mast-headed |
| Quiet | Centered | Single column narrow | Negative space | Outlined pill | None | None | N9 Edge-min | Ft2 Inline single line |
| Riso | Centered | Single column | Negative space | Outlined | Inline | None | N7 Brutal slab | Ft8 Marquee scroll |
| Salon | Centered | Single column narrow | Ornament (fleuron) | Outlined | Tightly cropped | None | N6 Masthead | Ft1 Mast-headed |
| Specimen | Left-margin | Asymmetric spans | Hairline | Outlined | None | Fade-up | N5 Floating pill | Ft2 Inline single line |
| Sport | Numbered display | Asymmetric spans | Bleed-colour | Oversized solid | Full-bleed | Horizontal sweep | N7 Brutal slab | Ft8 Marquee scroll |
| Studio | Centered | Asymmetric spans | Negative space | Typographic-only | Tightly cropped | Fade-up | N7 Brutal slab | Ft3 Index columns |
| Terminal | Inline (with `>` prompt) | Single column | Negative space | Typographic-only `[ go ]` | None | Typewriter | N8 Terminal command | Ft4 Dense colophon |
| Violet | Hanging | Single column | Negative space | Outlined | None | Fade-up | N5 Floating pill | Ft2 Inline single line |

## 構造的同一性のアンチパターン

下記の構造的指紋を拒否する。これらが AI テンプレの指紋。

- **SaaS のヒーロー。** 中央寄せの display 見出し、中央寄せのサブヘッド、中央寄せのピル CTA、ビューポート全高ヒーロー、フェードアップ。最も認識されている AI 構造的指紋。
- **3 フィーチャー行。** アイコン上＋見出し＋2行本文の等幅3カラム、24px ギャップ、カードパディング同一。
- **ベネフィット → CTA。** フィーチャー箇条書きリストの後に「Sign up」ボタンブロック。予測可能なリズム。
- **すべてフェードイン。** 全セクションが同じスクロール起動フェードアップを得る。ページがプレゼンに感じる。
- **コピーカーボンのフッター。** ロゴ、リンク4カラム、ソーシャル行、コピーライト。どこのサイトでも同じ。

## わからないとき

要件が指紋を示唆せずユーザーがテーマを選んでいないなら、**デフォルトに逃げない**。要件からドメイン語を読む（audio、commerce、docs、agency、restaurant、fashion、fintech、personal …）。そして *そのドメインに合う、カテゴリ的に異なるグループの* マクロ構造を **3つ** 提示する。ユーザーに選ばせる。

3つの目的はコントラスト。グリッド主導の形状、ドキュメント主導の形状、ポスター主導の形状。カテゴリ的に異なるグループから選ぶことが多様性を生む。近接した3つを提示するのは、このスキル全体が打ち負かそうとする AI の痕跡。

### ドメイン → トリオ（この3つを提示。デフォルトに逃げない）

ドメインが推定できないなら、1問だけ聞く — 「これは何をするものか」 — それから写像する。

| 要件に含まれるドメイン語 | 提示するトリオ |
| --- | --- |
| **podcast, audio, music, playlist, listening** | **Photographic** · **Quote-Led** · **Letter** |
| **shop, store, product, merch, commerce, ecom** | **Catalogue** · **Photographic** · **Bento Grid** |
| **docs, CLI, SDK, API, library, open source, developer reference** | **Workbench** · **Long Document** · **Component Playground** |
| **platform, infra, observability, dashboard SaaS, B2B tool, try-or-talk-to-sales** | **Bento Grid** · **Workbench** · **Stat-Led** |
| **agency, studio (work-led), case studies, multi-project portfolio, freelance creative** | **Portfolio Grid** · **Split Studio** · **Index-First** |
| **personal one-pager, individual, about-me, resume (no case studies)** | **Long Document** · **Letter** · **Index-First** |
| **restaurant, café, bar, food, kitchen, menu** | **Photographic** · **Long Document** · **Catalogue** |
| **fashion, apparel, beauty, lookbook** | **Photographic** · **Catalogue** · **Marquee Hero** |
| **fintech, banking, payments, invest, trading** | **Stat-Led** · **Workbench** · **Long Document** |
| **manifesto, campaign, cause, advocacy, political** | **Manifesto** · **Quote-Led** · **Stat-Led** |
| **editorial, foundry, magazine, type, specimen** | **Specimen** · **Long Document** · **Type Specimen** |
| **product launch, SaaS marketing, B2B** | **Bento Grid** · **Workbench** · **Stat-Led** |
| **conference, event, speaker, keynote** | **Marquee Hero** · **Manifesto** · **Photographic** |
| **fallback（本当に手がかりなし）** | **Bento Grid** · **Long Document** · **Manifesto** |

**分岐に関する注記。** いくつかのドメインは意図で分岐する。*Developer-tool docs* と *Developer-tool marketing* はどちらも「developer」を含むが、docs ページは Workbench のウォークスルーが要り、マーケティングページは SRE が30秒で価値提案を読めるよう Bento Grid + Stat-Led が要る。*Personal* も同様。1ページの自己紹介と複数プロジェクトのケーススタディ ポートフォリオは *別の要件*。1ページは散文（Long Doc / Letter）を欲し、ポートフォリオは Portfolio Grid / Split Studio を欲する。要件が曖昧なら、**1問聞いて** 曖昧さを解消（「docs ウォークスルー or マーケティング ランディング？」「1ページ or ケーススタディ？」）してからトリオを選ぶ。

ユーザーが肩をすくめて「あなたが選んで」と言うなら、プロジェクトの CSS から `/* Hallmark · macrostructure: ... */` スタンプを読む。スタンプされた族からカテゴリ的に最も遠いトリオの1つが正しい選択。連続する2つの出力が同じ族から来てはならない。編集系2連続なし、グリッド主導2連続なし。

ユーザーが曖昧なトーン語（「modern」「clean」「professional」）で答えるなら、それは感覚ではない。ドメイン トリオで再度尋ねる。

表末尾のフォールバック行は *最後の手段*。ドメイン語がまったく現れず、ユーザーが本当に選べないときだけ。実務上ほとんどの要件にドメイン語が含まれる。フォールバックを使うのは、ほぼ読みが甘い証拠。
