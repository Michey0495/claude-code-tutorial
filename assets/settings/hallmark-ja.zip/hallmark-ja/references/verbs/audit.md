# `hallmark audit`

ユーザーが指定したファイルを読み、各所見について以下を返す:

- **Tell** — [`anti-patterns.md`](../anti-patterns.md) で命名されたアンチパターン。
- **Where** — ファイルパスと行範囲。
- **Severity** — `critical`（スロップとして出荷）、`major`（AI生成に見える）、`minor`（軽微なテイスト問題）。
- **Fix** — 一行の具体的修正案。

重大度でグルーピングする。編集はしない。再設計はしない。最後に件数を出す: `N critical · M major · K minor`。

監査は構造的指紋も*同時に*検査する。AIテンプレート（中央寄せヒーロー、等間隔3カードの機能、CTA、フッター、非対称も驚きもなし）が使われていれば、視覚処理が綺麗でも構造上のcritical所見として報告する。

**スタンプとページの整合チェック。** 監査対象ファイルに `/* Hallmark · macrostructure: <name> · ... */` のスタンプがあれば、ページが実際にその名前に一致するか検証する。スタンプが **Bento Grid** を名乗っているのに、ページがCTA付き中央寄せ1カラムヒーローなら、構造上のcritical所見として `stamp lies` を報告する。スタンプは出荷物を反映するか、外すかのどちらか。これは過去のHallmark実行がスタンプを残したあとに編集でAIテンプレに戻ったドリフトを捕捉する。

**ジャンル対応の監査。** 監査対象のスタンプがジャンルを名乗っている場合（例: `genre: atmospheric`）、採点時に [`slop-test.md`](../slop-test.md) のジャンルスコープ上書きを適用する。ラジアルグラデ背景はeditorialならcritical、atmosphericなら許容。純白の紙はeditorialならtell、modern-minimalなら許容。監査動詞はページが宣言したジャンルを尊重する。

**`design.md` 監査。** プロジェクトルートに `design.md`（または `DESIGN.md`）がある場合、採点前に読む。その上で、監査対象の全ページをシステムと突き合わせる:

- **テーマドリフト。** `design.md` で宣言したシステムと一致しないトークン／フォント／アクセントをページが使っている → `critical: design-system drift` として報告。ページごとに個別テーマを選ぶのは、各ページが内的に綺麗でも、システム管理されたプロジェクトではスロップ。
- **マクロ構造ファミリー違反。** `design.md` がマーケティングページに Marquee Hero か Stat-Led を指定しているのに、監査対象ページが Letter 形式 → `major: outside design.md family` として報告。
- **スタンプ不一致。** ページのCSSスタンプが `designed-as-app` を名乗り `design-system: design.md` も付いているのに、実際は `design.md` からドリフトしている → `critical: stamp lies` として報告。スタンプはコードが提供しないコンプライアンスを主張している。
- **システム管理されたプロジェクトでスタンプが全くない** → `major: missing system reference` として報告。`design.md` プロジェクトの全ページはシステムへの忠誠をスタンプする義務がある。

逆に、`design.md` *を持たない*プロジェクトでは、標準の多様化ルールが適用される。前回のHallmark出力とマクロ構造／テーマを共有するページは `minor: variety drift` として報告する。
