# `hallmark redesign`

ユーザーは同じコンテンツから別のページを欲しがっている。現在の視覚構造に満足していない。理由はたいていテンプレ的、汎用的、AI形に見えるため。あなたの仕事は、ユーザーが明示的にフルリビルドを承認しない限り、既存の実装境界を尊重しつつ、ページの構造、リズム、コンポーネントの声を再設計すること。

## 非破壊実装ルール

Hallmarkは視覚層とインタラクション層を再設計する。既定では本番ファイルを削除しない。

- 既存のルートファイル、コンポーネントディレクトリ、ページツリー、旧サイトを、ユーザーが削除を明示的に依頼するか、削除を列挙したファイルレベルの計画を承認しない限り、削除しない。
- 既定では、指定されたページ／コンポーネントファイルへのインプレース編集、または既存ルートを通る加算的な新コンポーネント／トークンに留める。
- 再設計が複数コンポーネントの除去、ルートツリーの置き換え、アプリの単一新ページへの集約を要するなら、停止して先に確認する。
- PDF、READMEファイル、`.md`ブリーフ、ドキュメント、トランスクリプト、ピッチデッキは製品理解のための素材として扱う。既定ではページコピーではない。ユーザーが逐語使用を明示しない限り、要約して翻案する。
- 編集前に、修正・新規作成・削除を予定するファイルを宣言する。削除は明示的な確認を必要とする。

## Step 0 · まずスコープを判定する

何よりも先に、再設計が**単一ページ**か**複数ページ**かを決める。挙動が大きく分岐する。

**複数ページのシグナル（1つでも立てば該当）:**
- 対象がディレクトリ（例: `./app/`、`./pages/`、`./src/routes/`）。
- 対象がglob（`**/*.tsx`、`app/*/page.tsx`）。
- ユーザーがブリーフ内で複数ファイルを名指す（`./hero.tsx and ./pricing.tsx`）。
- ユーザーが「サイト全体」「全ページ」「アプリ」「すべてのページ」「マーケティングサイト」と言う。
- コードベースに複数のルートファイル（`app/page.tsx`、`app/about/page.tsx`、`app/pricing/page.tsx` など）があり、ユーザーがプロジェクトルートを指定した。

いずれかが立つ → **複数ページの再設計**。 § Multi-page flow へ進む。
どれも立たない → **単一ページの再設計**。 § Single-page flow へ進む。

---

## § Multi-page flow — まず design.md、それから再設計

Webアプリは*デザインシステム*を必要とする。17の無関係なテーマ選びではない。Hallmarkの多様化ルールはここでは間違っている。同一プロダクトのページ間では、**多様性ではなく一貫性が目標**。全ページを別々のマクロ構造／テーマ／アクセントで再設計したら、各ページ単体が綺麗でもスロップな多重人格アプリを出荷したことになる。

流れは次のとおり:

### 1. プロジェクトを読み、いったん止まる

1ファイルでも再設計を始める前に:

- 対象ディレクトリを巡回し、ページレベルのファイルをすべて1行説明付きで列挙する（ヒーロー／プライシング／ドキュメント／ダッシュボードなど）。
- 既存のデザイン資産を確認する。`tokens.css`、ブランド値を持つtailwind config、ロゴ、`README` に書かれたブランドカラー、マーケティングのスクリーンショット。
- 既存の `.hallmark/log.json` を確認する。過去の実行があれば最新のスタンプを読む。すべてのエントリが別々のマクロ構造／テーマなら、ユーザーの不満を裏付ける。

### 2. プロジェクトルートに `design.md` を作成する

プロジェクトルートに1ファイル作る: `design.md`（プロジェクトの大文字小文字の慣習に合わせて `DESIGN.md` でも可）。このファイルが、以後のページ再設計が読む**唯一の真実の源**になる。フォーマット:

````markdown
# Design — <Project name>

A locked design system for this app. Every page redesign reads this file before
emitting code. Do not regenerate per page — extend or amend this file when the
system needs to grow.

## Genre
<editorial · modern-minimal · atmospheric · playful>

## Macrostructure family
Pick one base macrostructure for marketing pages, one for app pages, one for
content pages (if applicable). Pages within a family share the family's shape;
they vary only in component archetypes.

- Marketing pages: <macrostructure name + the 1–2 archetypes that vary>
- App pages:       <macrostructure name + variation knobs>
- Content pages:   <macrostructure name + variation knobs>

## Theme
- `--color-paper`   oklch(<L> <C> <H>)
- `--color-paper-2` oklch(<L> <C> <H>)
- `--color-ink`     oklch(<L> <C> <H>)
- `--color-ink-2`   oklch(<L> <C> <H>)
- `--color-rule`    oklch(<L> <C> <H>)
- `--color-accent`  oklch(<L> <C> <H>)
- `--color-focus`   oklch(<L> <C> <H>)

## Typography
- Display: <face>, weight <N>, style <normal/italic>
- Body:    <face>, weight <N>
- Mono:    <face>, weight <N>
- Display tracking: <em>
- Type scale anchor: <text-display> = clamp(...)

## Spacing
4-point named scale. The values are in `tokens.css`. Pages must use named
tokens (`var(--space-md)`), never raw values.

## Motion
- Easings: cubic-bezier(<x>, <y>, <z>, <w>) named `--ease-out`, etc.
- Reveal pattern: <fade only / fade + slide / none>
- Reduced-motion fallback: opacity-only, ≤ 150 ms.

## Microinteractions stance
- <silent success / celebratory toasts: never>
- <hover delay 800 ms · focus delay 0 ms>
- <other named choices>

## CTA voice
- Primary CTA: <fill style, shape, copy pattern>
- Secondary CTA: <outline style, shape, copy pattern>

## Per-page allowances
- Marketing pages MAY use enrichment (Tier-A CSS art, Tier-B SVG, etc.).
- App pages MUST NOT use enrichment — function carries the page.
- Content pages: typography only.

## What pages MUST share
- The wordmark / logotype.
- The accent colour and its placement (≤ 5 % per viewport).
- The display + body fonts.
- The CTA voice (button shape, border-radius, padding rhythm).
- Section heading rhythm (numeral + label + display heading pattern).

## What pages MAY differ on
- Macrostructure within the page-type family (a marketing page can be Marquee
  Hero on one route and Long Document on another — both still use the system's
  type, colour, and CTA voice).
- Hero archetype (within the family's allowance).
- Enrichment — only on marketing pages, only Tier-A or Tier-B.

## Exports

Drop-in formats for re-using this design system in other projects.
See [`export-formats.md`](../export-formats.md) for the canonical mapping.

### tokens.css
```css
:root {
  --color-paper:      oklch(<L> <C> <H>);
  --color-paper-2:    oklch(<L> <C> <H>);
  --color-ink:        oklch(<L> <C> <H>);
  --color-ink-2:      oklch(<L> <C> <H>);
  --color-rule:       oklch(<L> <C> <H>);
  --color-accent:     oklch(<L> <C> <H>);
  --color-accent-ink: oklch(<L> <C> <H>);
  --color-focus:      oklch(<L> <C> <H>);

  --font-display: "<face>", ...;
  --font-body:    "<face>", ...;
  --font-outlier: "<face>", ...;

  --space-3xs: 0.25rem;  --space-2xs: 0.5rem;  --space-xs: 0.75rem;
  --space-sm:  1rem;     --space-md:  1.5rem;  --space-lg: 2rem;
  --space-xl:  3rem;     --space-2xl: 4.5rem;  --space-3xl: 7rem;

  --text-xs: 0.75rem;  --text-sm: 0.875rem; --text-md: 1.125rem;
  --text-lg: 1.375rem; --text-xl: 1.75rem;  --text-2xl: 2.25rem;

  --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
  --dur-short: 220ms;
  --radius-card: <px>; --radius-pill: <px>; --radius-input: <px>;
}
```

### Tailwind v4 `@theme`
```css
@theme {
  --color-paper:   oklch(<L> <C> <H>);
  --color-ink:     oklch(<L> <C> <H>);
  --color-accent:  oklch(<L> <C> <H>);
  --font-display:  "<face>", sans-serif;
  --font-body:     "<face>", sans-serif;
  --spacing-md:    1.5rem;
  --text-md:       1.125rem;
  --ease-out:      cubic-bezier(0.16, 1, 0.3, 1);
  /* mirror the rest of tokens.css with `--spacing-*` for Tailwind's spacing utilities */
}
```

### DTCG `tokens.json`
```json
{
  "color": {
    "paper":  { "$value": "oklch(<L> <C> <H>)", "$type": "color" },
    "ink":    { "$value": "oklch(<L> <C> <H>)", "$type": "color" },
    "accent": { "$value": "oklch(<L> <C> <H>)", "$type": "color" }
  },
  "font": {
    "display": { "$value": "<face>", "$type": "fontFamily" },
    "body":    { "$value": "<face>", "$type": "fontFamily" }
  },
  "space": {
    "md": { "$value": "1.5rem", "$type": "dimension" }
  }
}
```

### shadcn/ui CSS variables
```css
:root {
  --background:        <L>  <C>  <H>;   /* paper */
  --foreground:        <L>  <C>  <H>;   /* ink */
  --primary:           <L>  <C>  <H>;   /* accent */
  --primary-foreground: <L> <C>  <H>;   /* accent-ink */
  --muted:             <L>  <C>  <H>;   /* rule */
  --muted-foreground:  <L>  <C>  <H>;   /* muted */
  --border:            <L>  <C>  <H>;   /* rule */
  --input:             <L>  <C>  <H>;   /* rule */
  --ring:              <L>  <C>  <H>;   /* focus */
  --radius:            <px>;
}
```
````

ファイルを書く前に、選択肢を平文で声に出す。 *"Genre: modern-minimal. Theme: a custom OKLCH palette anchored on your brand teal. Display: Geist 600. Body: Geist 400. Three macrostructure families: Marquee Hero (marketing), Workbench (app), Long Document (content)."* その上で問う: *"Want me to proceed with this system across every page, or amend any of it first?"*

確認を待つ。ユーザーが承認する（または「go ahead」と言う）まで、`design.md` を書かないし、ページの再設計も始めない。

### 3. 各ページを `design.md` から読みながら再設計する

各対象ページについて:

- **まず `design.md` を読む。** これがプロジェクトのルール。[`references/`](../) 配下のビルドごとの参照はこのファイルに従属する。`design.md` と参照が食い違うとき、`design.md` が勝つ。
- ページタイプ（marketing / app / content）に対して `design.md` が宣言したファミリーからマクロ構造を選ぶ。ファミリー内ではアーキタイプを変えてよいが、`design.md` が許す範囲のみ。
- ロックされたテーマを適用する。「多様性を出すため」にテーマを差し替えてはいけない。多様性はマクロ構造／アーキタイプの選択に宿る。テーマには宿らない。
- ロックされたタイポグラフィ、スペーシング、モーション、マイクロインタラクションのスタンスを適用する。
- 各ページのCSSに次をスタンプする: `/* Hallmark · genre: <genre> · macrostructure: <name> · design-system: design.md · designed-as-app */`。`designed-as-app` フラグが将来のHallmark実行に、新システムを発明せず `design.md` を読めと伝える。
- 複数ページ再設計用に `.hallmark/log.json` のエントリを1件にまとめ、ページごとではなく `"scope": "app"` で書く。

### 4. 多様化ルール — 複数ページでは反転する

同一アプリのページ間では、多様化ルールは*反転*する。連続するページはテーマ、アクセント、タイプペアリングを共有する**べき**。マクロ構造はファミリー内で変えてよい。「前回のHallmark実行と差を付ける」をチェックする55のスロップテストゲートは、`designed-as-app` 出力ではスキップする。システムがカタログのローテーションを上書きする。

`design.md` からドリフトしたページはスロップ。監査動詞は `design.md` ドリフトを構造上のcritical所見として報告する（`stamp-vs-design.md disagreement`）。

### 5. ローカル上書きではなく `design.md` を改訂すべきとき

ページが本当に `design.md` の許さない何か（例: 新サブプロダクトのマーケランディングに別テーマを使いたい）を必要とするなら、ルールは**まず `design.md` を改訂する**、ローカルで上書きしない。明示的なページ別許容、または `## Variants` セクションを追加する。ファイルは進化させる。ページ別の上書きは進化させない。

---

## § Single-page flow

（古典的な再設計の挙動。変更なし。）

**保つべきもの:**
- コピーの意図、事実の主張、製品名、主たるメッセージ。逐語の保持は、対象UIに既にその文言が存在するか、ユーザーが逐語コピーを明示的に求めたときだけ。
- 情報アーキテクチャ（どのセクションが、おおむねどの順序で存在するか）
- ブランド（ユーザーが名指したカラーとフォント。あれば）
- 主たるアクション
- 既存のルート／コンポーネントの所有境界。フルリビルドが承認されていない限り。

**置き換えるもの:**
- 構造的指紋。 [`structure.md`](../structure.md) からソースとは**別の**組み合わせを選ぶ。
- コンポーネントの声。別のボタンスタイル、別のディバイダー語彙、別の画像処理。
- リビールパターン。元がスクロールでフェードしていたなら、新しい方はリビールゼロでよい。
- 視覚的リズム。セクションごとに異なるパディング、異なるアライメント、意図的な断絶。

**確認なしに置き換えないもの:**
- ルートツリー、本番のコンポーネントディレクトリ、旧サイトのファイル構造。
- 機能しているアプリのロジック、データフェッチ、認証、フォーム、アナリティクス、連携コード。
- PDF、ドキュメント、マークダウンファイルから貼り付けたテキストを使う既存コピー（ユーザーが逐語を要求していない限り）。

**任意の `--mood <name>` 引数:**

ユーザーがムードを指定した場合（`hallmark redesign ./hero.tsx --mood luxury`）、そのムードに沿うトーンを選び、それに構造的指紋を駆動させる。ムード名は [`typography.md`](../typography.md) と [`structure.md`](../structure.md) のトーンに対応する。ムードが与えられなければ、どんな*感じ*にしたいかを一語でユーザーに尋ねて進める。

**ジャンル切替の脱出口。** 現在のジャンルに合わない*種類*のデザインをユーザーが明示的に求めた場合（例: 「このeditorialページを現代SaaSのヒーローとして再設計してほしい」）、ジャンルも切り替える。[`genres/<new-genre>.md`](../genres/) を読み込み、そのルール上書きを適用する。新ジャンルを出力にスタンプして、将来の実行が尊重できるようにする。

**プロジェクトレベルのチェック。** これを真の単一ページ再設計として扱う前に、プロジェクトルートで `design.md` を探す。存在すれば、プロジェクトはアプリとして設計されているため、**単一ページのルールは適用されない**。`design.md` を読み、それに従う。多様化ルールは反転する（一貫性が勝つ）。ロックされたシステムから本当に離脱したいなら、*先に `design.md` を更新してから*再設計する。

**出力:**

再設計したコードに加えて、以下を説明する短いメモを返す:

- 採用した構造的指紋を軸ごとに。
- なぜこの組み合わせが元案よりブリーフに合うか。
- 取り除いた1つの要素と、その理由。
- （ジャンルが変わったなら）新しいジャンルがユーザーの希望する種類のデザインに合う理由。
