# モーション

AI 生成のモーションのほとんどは散漫。カードごとのホバーリフト、スクロールごとのフェードイン、跳ねるアイコン。鎮める。1つの統制されたモーメントは10個の小さなものに勝る。

> インタラクション別のレシピ（ボタンプレス、フォーカス、モーダル、トースト、楽観的更新、コマンドパレット、ドラッグハンドル等）は [`microinteractions.md`](microinteractions.md) を参照。本ファイルはモーションの *言語*、あちらは *語彙*。

## 原則

- **`transform` と `opacity` のみアニメーションする。** これらは GPU でコンポジットされ、レイアウトを発火しない。他は性能バグの予備軍。
- **Duration は3バケット。** マイクロ（100–150ms）、マイナー（200–300ms）、メジャー（300–500ms）。退場はエンターの約75%。
- **イージングは指数 ease-out。** 入る要素は所定位置で減速する。去る要素は加速して離れる。
- **モーションは知覚に資する。** トランジションが何を伝えるか説明できないなら、削る。
- **Reduced motion は任意ではない。** `@media (prefers-reduced-motion: reduce)` で空間モーションを不透明度のクロスフェードに落とす。

## イージング

この3つを使う。トークンとして名付ける。

```css
:root {
  --ease-out: cubic-bezier(0.16, 1, 0.3, 1);        /* 入る要素 */
  --ease-in:  cubic-bezier(0.7,  0, 0.84, 0);       /* 去る要素 */
  --ease-in-out: cubic-bezier(0.65, 0, 0.35, 1);    /* 状態トグル */
}
```

`ease`、`ease-in-out`（デフォルト）、`cubic-bezier(0.25, 0.1, 0.25, 1)` — これらはブラウザのデフォルトで、未加工に読める。

## Duration

```css
:root {
  --dur-micro: 120ms;   /* ボタンプレス、トグル、色変化 */
  --dur-short: 220ms;   /* ホバーリフト、ツールチップ、メニュー開閉 */
  --dur-long:  420ms;   /* モーダル、ドロワー、アコーディオン、ページリビール */
}
```

退場はエンターの約75%を使う。

```css
.menu.is-open  { transition: transform var(--dur-short) var(--ease-out); }
.menu.is-close { transition: transform calc(var(--dur-short) * 0.75) var(--ease-in); }
```

## ページロード時のオーケストレーション

ページロードで1つのシーケンス。JS ではなく CSS カスタムプロパティで DOM インデックスごとにスタガーする。

```html
<section style="--i: 0">…</section>
<section style="--i: 1">…</section>
<section style="--i: 2">…</section>
```

```css
.reveal {
  opacity: 0;
  transform: translateY(8px);
  animation: reveal var(--dur-long) var(--ease-out) forwards;
  animation-delay: calc(var(--i, 0) * 60ms);
}
@keyframes reveal {
  to { opacity: 1; transform: none; }
}
```

総スタガーは約500msで打ち切る。それを超えるとページが落ち着くのが遅く感じる。

## スクロール連動モーション

- IntersectionObserver を使う。**絶対に** `scroll` イベントリスナーは使わない。
- *1度きりリビール* の効果にだけ使う。パララックスなし。特別な理由がない限りスクロールスクラブのアニメーションもなし。
- スクロール起動のモーションには必ず reduced-motion フォールバックを。

## 状態トランジション

- ボタンのホバー／アクティブ: マイクロ duration、`--ease-out`、ホバーで `transform: translateY(-1px)`、アクティブで `translateY(0)`。暗背景のホバーで `box-shadow` をトランジションしない（グロー効果）。
- メニュー／ツールチップ／ドロップダウン: ショート duration、開で `--ease-out`、閉で `--ease-in`。フォーカス管理は popover API か `inert` を使う。
- モーダル: ロング duration、スケールイン（0.96 → 1）＋不透明度クロスフェード。バックドロップは同 duration でフェードイン。
- アコーディオン: `grid-template-rows: 0fr` → `grid-template-rows: 1fr` をアニメーション（`height` ではない）。`--ease-in-out` で。

## Reduced motion

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 150ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 150ms !important;
  }
  .reveal { animation: reveal-reduced 150ms linear forwards; }
  @keyframes reveal-reduced { to { opacity: 1; transform: none; } }
}
```

機能的モーション（プログレスバー、ローディングスピナー、スケルトン）は走らせ続ける。ただし遅めに。

## 禁止

- `ease`（ブラウザデフォルト、凡庸）。
- プログレスバーと刻むローダー以外での `linear`。
- UI 要素でのバウンス／エラスティック／オーバーシュート。古臭く、「テンプレート」のサイン。
- `width`、`height`、`top`、`left`、`margin`、`padding` のアニメーション。
- クラス全体に予防的な `will-change`。要素単位、かつアニメーション中だけ。
- パララックス。
- カスタムカーソル。
- reduced-motion フォールバックのないスクロール駆動アニメーション。
- 無限ループ（機能的ローダーを除く）。視線を引きつけて離さない。
