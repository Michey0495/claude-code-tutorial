# 文言

言葉はデザインの一部。優れたレイアウトでもストックの文言だと汎用に見える。並のレイアウトでもタイトな文言なら考え抜かれて読める。

## 原則

- **具体的な動詞コマンド。** "Save changes" は "OK" より、"Submit" よりよい。
- **ラベルは記述する。** "Email address" は "Email" よりよい。
- **リンクテキストは単独で意味を持つ。** "View pricing plans" は "Click here" よりよい。
- **エラーは指示。** 何が壊れたか、なぜ、どう直すか — その順で。
- **能動態。** "We couldn't find your account" は "Your account could not be found" よりよい。
- **一貫性。** "Delete" か "Remove" のどちらかを選ぶ。"Sign in" か "Log in" のどちらかを選ぶ。全所で使う。

## ボタン

ボタンが実行するアクションの動詞コマンドを使う。

良い: `Save changes`、`Create account`、`Send invitation`、`Copy link`、`Open file`。
悪い: `OK`、`Submit`、`Click here`、`Continue`（多段フローの二次ボタンとしてのみ）。

## エラーメッセージ

3つの部分。

1. **何が起こったか。** 過去形、事実。"That card was declined."
2. **理由（わかれば）。** "Your bank flagged the charge."
3. **何をするか。** 命令形。"Try another card, or contact your bank."

*ユーザー* の入力に対して謝らない。バリデーションエラーで "Oops!" と言わない。値を受け付けないフォームは値を説明する。狼狽を演じない。

## 空状態

3拍。

1. 何が空か1行で命名。"No projects yet."
2. なぜ重要か／projects とは何か1行。"Projects group your tasks and team."
3. ボタン1つ。次の単一アクション。"Create a project"。

## ローディング

- 短い待ち: テキストなしのスピナー。
- 中程度の待ち（>2s）: スピナー＋ "Loading…"。
- 長い待ち（>10s）: スピナー＋進捗表示＋正直なラベル — "Compiling (this can take a minute)."

## マイクロコピー禁止

- "Click here." リンクテキストは単独で意味を持つこと。
- "Oops!"、"Uh oh!"、"Something went wrong." 壊れたものを命名する。
- "Enter your email below." 入力欄が下にあるなら言う必要はない。
- エラー状態の感嘆符。
- フラストレーション経路（パスワード忘れ、決済失敗、アカウントロック）でのユーモア。
- ストックのプレースホルダ名: Jane Doe、John Smith、Lorem Ipsum（ページがロレム生成ツールでない限り）。
- プロダクト文言のスタートアップ常套句: Acme、Nexus、Unleash、Seamless、Supercharge、Transform、Elevate、Empower、Delight、Magical。
- 機能を命名せずに感覚を約束するマーケコピー。"Experience the power of ___" は空虚。

## 正しいタイポグラフィ

- 引用符は丸: `"Hello"`、`'word'`。
- 中断のエムダッシュ: `—`（U+2014）。範囲のエンダッシュ: `10–20`（U+2013）。`--` ではない。
- 省略記号: `…`（U+2026）。`...` ではない。
- アポストロフィ: `’`。プライム `'` ではない。
- 単位前の改行不可スペース: `10 kg`、`5 min`（`&nbsp;` または U+00A0）。

テキストが CMS からロードされるなら、CMS で Smart Quotes を設定する。ハードコードなら正しく書く。

---

## トーン別の声のサンプル

スキルは、別の声を真似させない限り、流通デフォルトの文言（"Built for the modern team"、"Unleash your X"、"Where A meets B"）に偏る。下記のサンプルは、その流通から外れたサイトの *本物の opening line*。動詞コマンドではなく、**具体性の種類** を真似る — 名指しの場所、名指しの日付、名指しのバーティカル、動詞コマンドの拒絶、メタファーの拒絶。トーン列は design-context ゲート（[`SKILL.md`](../SKILL.md) Step 1 参照）でユーザーがコミットする7つのトーンに写像する。

### Editorial

3つの声のパターン: *日付アンカー*、*動詞コマンドの拒絶*、*列挙的*。

- *"Creative direction, design and type for culture since 2003."* — apracticeforeverydaylife.com — 日付＋名指しのバーティカル
- *"A monthly art publication featuring contributions by some of the most engaged thinkers working today."* — e-flux.com/journal — リズム（*monthly*）と具体的な動詞コマンド（*featuring*）
- *"A thing well made."* — klim.co.nz — 動詞コマンドの拒絶、デザインを素材として扱う
- *"Frieze elevates the provocative and brilliant leading voices who shape and challenge today's art world."* — frieze.com — *empower* ではなく *challenge*
- *"We design everything for everyone."* — pentagram.com — マーケ動詞コマンドの拒絶、民主的な主張
- *"Writer + Photographer."* — craigmod.com — 3語、2役、余分なし
- *"Type, set with care."* — Hallmark Specimen — 3語、コンマがデザイン
- *"I'm a French design technologist based in London. I make websites and fonts, amongst other physical and digital artefacts."* — mathieutriay.com — 名指しの場所、名指しの成果物、"artefacts" が craft を示す

### Brutalist

3つの声のパターン: *平叙の宣言*、*メタファーの拒絶*、*帰結を伴う直接呼びかけ*。

- *"The product development system for teams and agents."* — linear.app — 平叙の宣言、装飾なし、"powered by AI" なし
- *"Resend is the email API for developers. Send transactional and marketing emails at scale with a simple, modern API."* — resend.com — フォームファクタ、オーディエンス、機能を命名
- *"Purpose-built for planning and building products. Designed for the AI era."* — linear.app — 時代を平叙で命名、婉曲なし
- *"WE ARE A STUDIO. WE ARE NOT A PLATFORM."* — Hallmark Meridian (test 04) — 拒絶で定義、全大文字
- *"We design products that last twelve years. We do not design products that need replacing every two."* — 具体的な数字、対の宣言
- *"A toolkit for assembling new worlds from the scraps of the old."* — are.na — テンプレを破る2番目のコピー
- *"NO COMPROMISE."* — Hallmark Brutal — 2語、ピリオドがデザイン
- *"We will not put our work behind a chatbot. We will answer the email ourselves."* — 拒絶の宣言、短い2文

### Soft

3つの声のパターン: *詩的抑制*、*列挙による情熱*、*証拠を伴う脆さ*。

- *"It's about time."* — cron.com — ウィンクなしのダブルミーニング、抑制
- *"Time is our most precious resource."* — Notion Calendar — 哲学的前提から始まり、具体へ
- *"Designer for the Web (v. XIX)."* — lynnandtonic.com — バージョン番号が craft-in-progress を示す
- *"Design engineer creating software that makes people feel something."* — rauno.me — 機能リストではなく情緒的アウトカム、"feel something" がジャンルの常套句を避ける
- *"All I want to do is build websites. Typography, motion design, copywriting, performance — the web is an endless medium of opportunity."* — paco.me — 列挙による情熱、脆さ（"scratched the surface"）
- *"I craft UI demos that explore the power of the web and help others sharpen their skills."* — jhey.dev — 動詞コマンド（*craft*）を命名、オーディエンス（*others*）を命名
- *"Soft, but exact."* — Hallmark Plume — 短い形容詞2つ、コンマ1つ、ピリオド
- *"This page is soft because the surface should be soft. The rules underneath are not."* — 主張と拒絶を組み合わせる

### Technical

3つの声のパターン: *スペック埋め込みの散文*、*測定された言語*、*データ先頭の opening*。

- *"The 14-inch MacBook Pro with M5 brings serious speed and advanced on-device AI to the personal, professional, and creative work you do every day."* — apple.com — スペックを散文に埋め込み、"serious speed" は測定された言語
- *"434 total posts. New CSS you feel like you could use today."* — nerdy.dev (Adam Argyle) — データ先頭、"feel like" が genuine な有用性を示唆
- *"$ streampipe parse access.log --filter status=5xx | jq"* — Streampipe (test 02) — マーケ主張ではなく実コマンドで始める
- *"Open the trace, find the span, fix the regression. No glossary required."* — Tracejam (test 05) — 具体的な動詞コマンド3つ、それから拒絶
- *"From stdin, through the pipe, into your dashboard."* — データ経路を命名、抽象を拒絶
- *"23 spans · 4 services · 482 ms."* — Tracejam モックアップ — データが見出し
- *"Read anything that emits lines. Files, pipes, sockets, kubectl logs."* — 入力を命名、汎用性を拒絶
- *"Drop-in OTLP. No agent, no sidecar."* — 主張と一般的な代替の拒絶を組み合わせる

### Luxury

3つの声のパターン: *具体を伴う heritage*、*洗練としての拒絶*、*名指しのスケール*。

- *"The world's most acclaimed creative collective, where 23 partners work independently and collaboratively to shape the future of design."* — pentagram.com — heritage（暗黙の長命）、名指しのスケール（23 partners）
- *"By appointment."* — atelier 風 — 拒絶としてのゲートキーピング
- *"A salon for the senses."* — Hallmark Salon — 単一の名詞句、コンマなし
- *"A page should arrive like a person — composed, deliberate, in good clothes."* — Hallmark Salon — ページを社会的存在として扱う類比
- *"With pleasure, you are most welcome."* — Hallmark Salon の挨拶 — フォーマルな呼びかけ
- *"Restraint, repeated, becomes a signature."* — Hallmark Atelier — コンマ3つ、4語、哲学的
- *"A studied hand."* — 3語、限定詞が機能する
- *"A small, opinionated craftsmanship engine that argues with your AI assistant on your behalf — and wins."* — Hallmark Atelier — 役割を精密に命名、対立を抱きしめる

### Playful

3つの声のパターン: *ポップカルチャー類比*、*食／感覚メタファー*、*予期された反応*。

- *"Playlists, but for ideas."* — are.na — 有用でもある類比
- *"Internet memory palace."* — are.na — 3語の名詞句、構造的メタファー
- *"Devouring details. Nourishing novelty. Deploying excellence."* — rauno.me — 頭韻、食＋テック メタファー
- *"The kind that make you say, 'Wait, how did you do that?'"* — jhey.dev — 直接呼びかけ、読者の反応を予期する
- *"Built to ship."* — Hallmark Sport — 3語、宣言、動詞コマンドが動詞コマンド
- *"Ready? You are two minutes from shipping."* — Hallmark Sport — 質問、それから数字
- *"design like print: warm, off-register, intentional."* — Hallmark Riso — 小文字＋コロン＋修飾語3つ
- *"this is not a page that pretends to be paper. it is a page that remembers paper."* — Riso — 模倣のフレーミングを拒絶

### Austere

3つの声のパターン: *極端な簡素化*、*原則を opening に*、*マーケ言語の拒絶*。

- *"Hello."* — Hallmark Quiet の挨拶 — 1語、ピリオドがデザイン
- *"This is a page that doesn't try."* — Quiet — 立場を公然と宣言
- *"Things Become Other Things."* — craigmod.com — 3語、ブランドをエッセイ題として扱う
- *"Lightness above weightiness, elevate everyone you encounter."* — craigmod.com — 原則先頭の位置取り
- *"A quiet skill."* — Hallmark Quiet — 3語、冠詞が機能する
- *"Software can be soft and exact at once. That's the trick."* — Hallmark Plume — 矛盾を命名、解消を命名
- *"One HTML file."* — Anya (test 06) フッター — 3語、カウントが自慢
- *"This page doesn't move."* — デザイン決定を公然と命名

---

## 禁止の opening line（アンチパターン）

下記のフレーズは流通デフォルトの LLM コピーに頻出し、上記の具体性のどれにも届かない。**完全禁止**。これらに手が伸びたら、上記トーンのパターンに置き換える。

| フレーズ | なぜダメか |
| --- | --- |
| *"Built for the modern team"* | 曖昧、具体性を仮定しない、時間的マーケ |
| *"Unleash your [X]"* | 誇張、ソフトウェアは何も解き放てない |
| *"Where X meets Y"* | 偽の合成、創作の怠惰 |
| *"Empower your..."* | 宣教的言語、具体的便益を避ける |
| *"Reimagine the way you..."* | ニーズの説明前に不満を仮定する |
| *"Supercharge your workflow"* | メカニズムなきエネルギー メタファー |
| *"Innovative solutions"* | 無意味、どのプロダクトもイノベーションを謳う |
| *"Seamless integration"* | "Seamless" に反対語がない、非具体性のサイン |
| *"In today's digital landscape"* | 時間的な手振り、読者がオリエンテーションを要すると仮定 |
| *"Next-generation"* | 前世代の不全を暗示、差別化を示さない |

要件が opening line に使える素材を渡さないなら、*その旨をユーザーに伝え*、具体的な名詞、動詞コマンド、場所を引き出す1問を聞く。ユーザーはプロダクトを知っている。モデルが具体性を発明することは許されない。
