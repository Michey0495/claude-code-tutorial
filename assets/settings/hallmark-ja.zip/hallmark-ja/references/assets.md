# アセット — アイコン、ロゴ、イラスト、写真、動画のソース正典

このファイルは、エンリッチメントアーキタイプが実際に外部アセットを必要とするときだけ（オンデマンド）読み込む。カテゴリごとに*正典の 3〜5 ソース*、ライセンス条項、インポートパターン、使用ルール、避けるべきソースをカタログ化する。

**反射。** ここに到達する前に、次の 2 つを順に問う: (1) 要件は本当にビジュアル素材を必要とするか？ [`hero-enrichment.md` § Image-need detection](hero-enrichment.md) 参照。(2) 必要なら手組みできるか？ [`custom-craft.md`](custom-craft.md) 参照。このファイルのアセットは、両方の答えがここに送ってきたときのもの。

---

## プレースホルダ戦略

ビジュアル素材が必要*かつ*ユーザーが実アセットを提供していないとき、この正典から順に選ぶ。ティア飛ばしはスロップ。

| # | ソース | いつ |
| --- | --- | --- |
| 1 | **Hallmark imagery kit**（[`imagery-kit.md`](imagery-kit.md)） | 要件が非写真ビジュアルを許容: SaaS ランディング、マニフェスト、エージェンシー / スタジオスプラッシュ、タイプ主導ポートフォリオ、editorial 主導マーケティング。キットのレジスタが合うときは**常に優先**。 |
| 2 | **手組み SVG コンポジション**（custom-craft.md の Tier B） | editorial-タイポグラフィ要件で「ビジュアル素材」がスタンプ / ワードマーク / カラーブロック構成でよい場合。キットがレジスタを運べないときに使う。 |
| 3 | **Picsum** — `https://picsum.photos/seed/<seed>/<w>/<h>` | 汎用写真スロット、キーワードアンカーが重要でないとき。同じレンダリングが同じ画像を生むよう決定論的 seed（ブランド名 + スロット名）を使う。 |
| 4 | **Unsplash Source** — `https://source.unsplash.com/<w>x<h>/?<keywords>` | キーワードアンカー付き写真スロット — 食、旅、ポートレート、実プロダクト。1〜2 個の具体キーワードを必ず渡す、ゼロは不可。 |
| 5 | **ローカル `public/placeholder-<type>.{jpg,svg}`** | 第三者依存を持たない自己完結プロジェクト。リポジトリにチェックインされた単一のニュートラルグレーブロック SVG。 |

**スワップ可能性 — 妥協なし:**

- すべてのプレースホルダ画像は直上に HTML コメントを持つ: `<!-- TODO: Replace with real <thing>, target size: <WxH> -->`。
- すべてのプレースホルダ URL は単一の定数を参照する — `--placeholder-base` CSS 変数か `PLACEHOLDER_BASE` 設定定数。ユーザーは 1 か所編集すればサイト全体を入れ替えられる。
- alt テキストは**意図した**被写体を描写（「Hand-thrown ceramic mug, top-down on linen」）、プレースホルダではない（「Picsum image」）。ユーザーが実写真をスワップインしたとき、alt は既に正しい。

**リモートアセットの安全性:**

- 第三者の画像、ロゴ、動画、アイコン、フォント URL はプロダクションデフォルトではなくプロトタイプデフォルトとして扱う。プロダクションコードを出す前に、ユーザーが明示的に第三者ホスティングを望む場合を除き、ベンダー版またはセルフホスト版を優先する。
- 第三者スクリプト、トラッキングピクセル、ウィジェット、API 依存をアセットショートカットとして追加しない。アセットソースはファイルを提供するもので、ページでコードを実行する権利を得るものではない。
- 第三者アセットがプロダクションに残るときは、引き渡し時にプライバシーと可用性のトレードオフを述べる: 訪問者がそれらの第三者ホストにリクエストし、ページはそのアップタイムと完全性に依存する。
- ユーザー提供のブランドや顧客ロゴは、公式アセットページかチェックインファイルを優先。無関係なサイトからロゴをホットリンクしない。

**アンチパターン:**

- base64 プレースホルダ画像をインライン化しない（CSS が肥大する）。
- キーワードなしでランダムに Unsplash を呼ばない（未キュレーションのストック写真っぽい結果を返す）。
- 子猫 / lorempixel / 「tiger.jpg」 / かわいいデフォルトサービスは使わない。プレースホルダは明らかなスロットに読まれるべきで、コンテンツに読まれてはいけない。
- 要件が実プロダクト写真を求めているのにキット画像を出荷しない（例: 実コーヒーショップのヒーローに抽象ボトル）。キットは雰囲気用、写真は被写体用。

---

## アイコン

### 正典

| ライブラリ | URL | 数 | 適する用途 |
| --- | --- | --- | --- |
| **[Lucide](https://lucide.dev)** | `lucide.dev` | 1,600+ | モダン SaaS / 開発者ツールデフォルト。2026 ベースライン。活発にメンテされる。 |
| **[Phosphor Icons](https://phosphoricons.com)** | `phosphoricons.com` | 9,000+、6 ウェイト（thin / light / regular / bold / fill / duotone） | セット混在なしでトーンバリアントが欲しいとき。強調のため同アイコンを違う*ウェイト*で使うのが正解。 |
| **[Heroicons](https://heroicons.com)** | `heroicons.com` | 約 300 | Tailwind / shadcn プロジェクト。タイトにキュレートされて意見強め。 |
| **[Tabler Icons](https://tabler-icons.io)** | `tabler-icons.io` | 24×24 グリッド上 5,900+ | 幅 — Lucide も Heroicons も必要なシンボルをカバーしないとき。 |
| **[Iconoir](https://iconoir.com)** | `iconoir.com` | 約 1,500 | 手描き感がある、寛大な無償ティア。 |

### ルール

1. **プロジェクトに 1 ライブラリ。** 同一ページで Material + Heroicons + Lucide の混在はアイコンセットシグナル。スキルの audit 動詞コマンドが捕まえる。
2. **サイズは 16 / 20 / 24 / 32 のみ。** グリッドにスナップ。18 px アイコンはこの正典に存在しない。
3. **ストロークデフォルト 2 px**（多くのライブラリの regular ウェイト）。20 px 未満のアイコンや強調目的のときだけ bold（2.5 px）へ。
4. **`currentColor` でモノクローム。** アイコンはテキスト色を継承。ブランド色のアイコンは唯一のプライマリ CTA のみ — 装飾としては不可。
5. **絵文字をアイコンに使わない。** 絵文字はアラインメント、アクセシビリティ、ブランド一貫性を壊す。実アイコンライブラリを使う。

### インポートパターン

```jsx
// Lucide — React (most common)
import { ArrowRight, Check, X } from "lucide-react";
<ArrowRight size={20} strokeWidth={2} />

// Phosphor — React, with weight prop
import { ArrowRight } from "@phosphor-icons/react";
<ArrowRight size={20} weight="regular" />

// Heroicons — React or static HTML
import { ArrowRightIcon } from "@heroicons/react/24/outline";

// Tabler — vanilla HTML via CDN
<svg width="20" height="20"><use href="https://cdn.jsdelivr.net/npm/@tabler/icons@latest/icons/arrow-right.svg" /></svg>
```

### 避ける

- **Font Awesome free** — 肥大、古い。2018 SaaS ルック、600+ の汎用グリフは全部「ページデザイン前にアイコンを選んだ」に読まれる。
- **非 Material プロジェクトでの Material Icons** — 他と合わない Google ルックを出す。
- **ストローク幅が不揃いのアイコンパック** — ウェイトを共有するライブラリを選ぶ。雑多な混在はランダムに読まれる。
- **セマンティックアイコンとしての絵文字** — 色、サイズ、ウェイト、アラインメントすべて制御不能。

---

## ブランド / 企業ロゴ

### 正典

| ソース | URL | 数 | 適する用途 |
| --- | --- | --- | --- |
| **[Simple Icons](https://simpleicons.org)** | `simpleicons.org` | 3,400+ | 業界標準。モノクローム SVG + ブランドごとの公式 hex。MIT ライセンス。ロゴウォールのデフォルト。 |
| **[SVGL](https://svgl.app)** | `svgl.app` | 600+ | キュレート済み、手選別、スパムなし。Simple Icons より品質バーが高い。 |
| **[theSVG](https://thesvg.org)** | `thesvg.org` | dark/light/mono/wordmark バリアント付き 4,000+ | npm + AI 用 MCP サーバー。スタックがサポートするなら Simple Icons の上位互換。 |
| **[Brandfetch](https://brandfetch.com)** | `brandfetch.com` | 2,200 万ブランド+ | 有料 API。ロゴ + 色 + フォント + ガードレール。CMS / フォームで「ドメインは？」と聞いてブランドをバックフィルしたいとき有用。 |
| **公式ブランドアセットページ** | 企業ごと | — | 正確性が必要なら必ず最初にチェック。多くのブランドはメディアキットページ（例 `vercel.com/design`）を持つ。 |

### ルール

1. **ロゴウォール: モノクロームのみ。** Simple Icons のデフォルト色か公式モノクロームバリアントを使う。フルカラーロゴ混在は 2018 SaaS に読まれる。
2. **幅揃えではなく高さ揃え。** ベースライン（典型的に 32〜48 px の高さ）を選び、幅は流れるに任せる。ブランドプロポーションは重要、引き伸ばしはシグナル。
3. **高さの 2〜3 倍を gutter に。** ロゴは呼吸スペースが要る。32 px ロゴのウォールは 64〜96 px の gutter が欲しい。
4. **ヘアラインボーダーなし、グローハローなし。** 紙の上にマークだけ。

### インポートパターン

```html
<!-- Simple Icons via CDN — easiest -->
<img src="https://cdn.simpleicons.org/github" alt="GitHub" height="32">
<img src="https://cdn.simpleicons.org/figma/aaaaaa" alt="Figma" height="32"> <!-- monochrome override -->

<!-- npm -->
<!-- npm install simple-icons -->
import { siGithub } from 'simple-icons/icons';
<svg viewBox="0 0 24 24"><path d={siGithub.path} fill="currentColor" /></svg>

<!-- SVGL via API -->
<img src="https://api.svgl.app/?slug=vercel" alt="Vercel">
```

### 避ける

- **フルカラーロゴグリッド。** 視覚的混沌、2018 に読まれる。
- **引き伸ばし / 押し潰しマーク。** 常にアスペクト比保持。
- **テンプレートキットからのプレースホルダ顧客ロゴ**（「ACME」「Initech」「Hooli」）。実顧客ロゴを使うか、ウォールを完全に外す — 偽のソーシャルプルーフはソーシャルプルーフなしより悪い。
- **ワードマークとマークの混在。** どの単一ウォールでも処理（all-monogram または all-wordmark）を選ぶ。

---

## 生成イラスト（エンリッチメント階層の Tier C）

キャラクターや特定シーンが経済的に手組みできないとき。**常にポストプロセス。** 完全な規律は [`custom-craft.md`](custom-craft.md) の Tier E 参照。

### 正典

| モデル | URL | コスト | 適する用途 | 出力 |
| --- | --- | --- | --- | --- |
| **[Nanobanana 2 / Gemini 2.5 Flash Image](https://ai.google.dev/gemini-api/docs/image-generation)** | Google AI | $0.039 / 枚 | パネル横断のキャラクター一貫性、高速イテレーション、リファレンス画像によるブランドスタイル準拠、テキスト付きインフォグラフィック | PNG（透過対応） |
| **[Recraft V4](https://www.recraft.ai/)** | recraft.ai | 約 $0.04 / 枚 | **本番投入可能 SVG 出力を持つ唯一のモデル。** スケールが必要なロゴ、アイコン、イラスト。 | SVG + PNG |
| **[Midjourney v8](https://www.midjourney.com)** | midjourney.com | 約 $0.14 / 枚 | 美的な美しさ、雰囲気のある静止画、アートディレクション | PNG |
| **[Flux 2](https://blackforestlabs.ai/)** | blackforestlabs.ai | 約 $0.03 / 枚 | フォトリアリズム — 肌、布地、プロダクトディテール、手 | PNG |

### ルール

1. **常にポストプロセス。** グレイン、非対称クロップ、手描き風オーバーレイ、カラーグレーディングを足す。生のモデル出力は 100 % AI に読まれる。
2. **ブランド一貫性のためにリファレンス画像を使う。** Nanobanana 2 のキャラクター一貫性機能が Midjourney との差別化点。ブランドアセットを与えて生成物をスタイルから外さない。
3. **マクロ構造コメントにモデルを刻印**（`generated: nanobanana-2 · post-processed`）。出自は重要。
4. **Google 生成画像で SynthID ウォーターマークを確認**。
5. **アニメーションなし。** これらのモデルはマルチフレームを出力しない。モーションが必要なら custom-craft で組む。

### 避ける

- **対称構図** — アルゴリズム的、AI シグナル。常に非対称クロップ。
- **滑らかメッシュブロブの顔** — 2024 年の汎用 AI キャラクタールック。
- **デフォルト照明 + 青みがかった背景** — 汎用 AI 美学。プロンプトでブランドアンカー色と変わった照明を指定。
- **指 6 本 / 家具の重複 / ありえない部屋** — 2026 年では減少したがまだ潜む。検品。
- **未改変出力の出荷** — ルール 1 参照。

### プロンプティングレシピ（Nanobanana 2）

```
Subject: <one specific concrete subject> in <one specific concrete pose>.
Style: <named style — "risograph print", "1960s editorial illustration",
        "ink-on-paper line drawing", NOT "modern flat" or "clean illustration">.
Composition: asymmetric, <off-centre subject>, <unusual crop>.
Lighting: <named lighting — "side-lit, late afternoon", "overcast diffuse">.
Reference: <attach brand asset / mood board for character consistency>.
Constraints: no smooth mesh-gradient, no aurora background, no symmetric layout,
             no smiling people-on-laptops poses.
```

具体的プロンプトは具体的画像を生む。汎用プロンプトは AI シグナルを生む。

---

## ライブラリイラスト（Tier D — 第一選択ではない）

予算とタイムラインがショートカットを強い、Tier C でもオーバーキルなとき。

### 正典

| ソース | URL | ライセンス | 適する用途 |
| --- | --- | --- | --- |
| **[Storyset](https://storyset.com)** | storyset.com（Freepik） | クレジット表示付き無料、有料で除去 | トグル可能な要素アニメーションとサイト上カラーカスタマイズを持つアニメ SVG。オンボーディングフロー、機能説明。 |
| **[Humaaans](https://www.humaaans.com)** | humaaans.com（Pablo Stanley） | CC0 | 多様なポーズ / 服装 / 肌色のミックスマッチキャラクター。ストック写真領域に行かずに人物が要るヒーローセクション。 |
| **[unDraw](https://undraw.co)** | undraw.co | MIT | エクスポート時カラースワップ可能なオープン SVG イラスト。カスタマイズすれば今も尊重される、しなければ飽和して即認識される。 |
| **[IRA Design](https://www.iradesign.io)** | iradesign.io（Creative Tim） | 無料 / 有料 | B2B / エンタープライズ向けのムーディーで洗練されたアイソメトリックシーン。 |
| **[Open Peeps](https://www.openpeeps.com)** | openpeeps.com | CC0 | 手描きキャラクターライブラリ、ナイーブスタイル。写真とイラストの間。 |

### ルール

1. **必ずブランドアンカー色相に色をカスタマイズ。** ライブラリのデフォルト色はライブラリルック。スワップする。
2. **可能ならクロップか再構成。** 未改変イラストは 100 の競合サイトに載っている。クロップ変更でも差別化になる。
3. **プロジェクトに 1 ライブラリ。** Storyset + Humaaans + unDraw 混在 = 視覚的混沌。1 つ選んで貫く。
4. **おなじみのポーズを避ける** — ノートパソコンの男 + フローティング吹き出し、ヘッドセットの女が雲の上、巨大電話を持つキャラクター。2021 年に Dribbble で見たものは観客も見ている。
5. **3 用途超ならカスタム発注。** イラストがヒーロー、機能ブロック、販促物に出るなら、1 枚あたりの発注コスト（フリーランサー $200〜$600、無制限の月額 $399〜$999）がブランド一貫性でライブラリに勝つ。

### 避ける

- **Open Doodles** — 古い。2019 年の手描き美学は 2026 年の触覚的反逆に置き換わった。
- **「モダンフラット」汎用ポーズ** — その美学全体が AI 訓練分布のデフォルト。
- **ライブラリフィルタを通した AI 生成イラスト** — 両方の悪いとこ取り。
- **キャラクター切り抜きを貼ったストック写真** — 物理と戦って、取り憑かれて見える。

---

## アプリモックアップ / デバイスフレーム

### 正典

| ソース | URL | 適する用途 |
| --- | --- | --- |
| **[Browserframe](https://browserframe.com)** | browserframe.com | アノテーション付きブラウザ + モバイルデバイスフレーム。SaaS デモスクリーンショット向けに作られている。 |
| **[Ray.so](https://ray.so)** | ray.so | macOS ウィンドウフレーム内のコードスニペット。開発者ツールランディングに最適。 |
| **[Cleanmock](https://cleanmock.com)** | cleanmock.com | モバイルデバイスフレーム、ミニマリスト、アプリストアリスト風ヒーローに良い。 |
| **[Mockup.style](https://mockup.style)** | mockup.style | 多目的デバイス + ブラウザビルダー、Figma フレンドリーなエクスポート。 |
| **[Device Shots](https://deviceshots.com)** | deviceshots.com | 複数フレームスタイルを持つ無料デバイスジェネレータ、回転速い。 |

### ルール

1. **SaaS / Web アプリにはブラウザフレーム。** 「これはウェブ上の実物」を伝える。Browserframe を使うか、手組み（1 px ヘアライン + macOS 3 ドットで十分）。
2. **クリーンなスプリットにはフレームなしフローティング。** スクリーンショットが裸で立てるほど美しいとき。高品質スクリーンショットが必要。
3. **デバイスフレーム（iPhone / iPad）は控えめに。** ヒーローモック 1 つまで — それ以上は汎用テンプレ作業に読まれる。
4. **傾き 1〜3°。** 生命感を加える。0° は平らに、5°+ は酔って読まれる。
5. **番号付きピンアノテーションのみ。** 番号付き円（1、2、3）と下の対応する callout legend。矢印 + ラベルの callout は不可（2018 UX）。新規性のある機能だけラベル、自明なものは外す。

### 避ける

- **光沢プラスチックのデバイスベゼル** — 2015 に見える。ミニマリストフレームかフレームなしで。
- **アノテーションの混乱** — ピクセルよりピンが多い。番号付きピン 3 つで十分、5 つは多すぎ。
- **ストレッチされたアスペクト比** — モックアップを自然比から外して縮尺しない。
- **スクリーンショット内の可視 Figma プロトタイピング遺物**（ゴーストアウトフレーム、「hover」インジケータ）。エクスポートをクリーンに。

---

## ヒーロー / デモ動画

### 正典（自前映像がないとき）

| ソース | URL | ライセンス | 適する用途 |
| --- | --- | --- | --- |
| **[Mixkit](https://mixkit.co)** | mixkit.co（Envato） | 登録不要、クレジット表示不要、1080p+ HD | 品質と労力のスイートスポット。 |
| **[Coverr](https://coverr.co)** | coverr.co | 商用利用無料 | ヒーローセクション背景と環境ループに最適化。 |
| **[Pexels Videos](https://www.pexels.com/videos/)** | pexels.com/videos | CC0 | 最大の無料ライブラリ、4K あり。物量勝負。 |
| **[Videvo](https://www.videvo.net)** | videvo.net | 段階制（無料 + pro） | コミュニティ映像 + モーショングラフィック。 |

### ルール

1. **`<source>` 順のコーデックチェーン: AV1 → WebM VP9 → MP4 H.264。** ブラウザは対応する最初を選ぶ。AV1 は同等品質で H.264 より 30〜50 % 小さい、H.264 は普遍的フォールバック。
2. **常に autoplay-muted-loop-playsinline。**
   ```html
   <video autoplay muted loop playsinline preload="metadata"
          poster="/hero-poster.webp" fetchpriority="high">
     <source src="/hero.av1.mp4"  type='video/mp4; codecs="av01.0.05M.08"'>
     <source src="/hero.vp9.webm" type="video/webm">
     <source src="/hero.h264.mp4" type="video/mp4">
   </video>
   ```
3. **常に `poster=""` を含める** — レイアウトシフトを防ぎ、reduced-motion ユーザーに静的フォールバックを与える。
4. **LCP 要素に `fetchpriority="high"`。** ヒーローに**`loading="lazy"` は不可** — LCP が死ぬ。
5. **アクセシビリティ用 VTT キャプション。** ミュートデモループでも — ユーザーがミュート解除する可能性がある。
6. **自動再生時の音なし。** ブラウザはどうせブロックするが、原則は厳格。

### 圧縮

- **[ffmpeg](https://ffmpeg.org)** で制御:
  - VP9: `ffmpeg -i input.mp4 -c:v libvpx-vp9 -b:v 0 -crf 30 -c:a libopus -b:a 128k output.webm`
  - AV1: `ffmpeg -i input.mp4 -c:v libaom-av1 -crf 30 -c:a aac output.mp4`
  - H.264: `ffmpeg -i input.mp4 -c:v libx264 -preset slow -crf 23 -c:a aac output.mp4`
- **[HandBrake](https://handbrake.fr)** で GUI / バッチ: 「Vimeo YouTube HQ 1080p」プリセットから始め、ウェブ用に 3〜4 Mbps へビットレートを下げる。

### 避ける

- **ウォーターマーク付きストック** — 隅に見える「Pexels.com」スタンプ。
- **60 fps と表示された 30 fps** — モダンディスプレイで露呈する。
- **ミュートトグルなしの音楽強めデモ** — アクセシビリティユーザーや騒がしい環境のユーザーを疎外する。
- **ヒーロー動画の `loading="lazy"`** — LCP が死ぬ、Core Web Vitals が落ちる。

---

## 写真

### 正典

| ソース | URL | ライセンス | 適する用途 |
| --- | --- | --- | --- |
| **[Unsplash](https://unsplash.com)** | unsplash.com | CC0 | 最大の無料コレクション、ムーディー / シネマティック、毎週コミュニティアップロード。出発点。 |
| **[Pexels](https://www.pexels.com)** | pexels.com | CC0 | 350 万+ 無料写真、多様な写真家。 |
| **[Nappy.co](https://www.nappy.co)** | nappy.co | 無料 + 有料 | 多様性と代表性のためにキュレート。プレミアムなビジュアルディレクション。 |
| **[Shotstash](https://www.shotstash.com)** | shotstash.com | 無料 | ライフスタイル / ミニマル美学。小さいが慎重にキュレート。 |
| **[Open Peeps](https://www.openpeeps.com)** | openpeeps.com | CC0 | 写真ストックルックなしで多様性が欲しいときのイラストキャラクターライブラリ。 |

### ルール

1. **常にソースに手を入れる。** グラデーションオーバーレイ、クロップ、彩度落とし、ぼかし、ブランド色ウォッシュ。未改変 Unsplash 写真は 100 の競合サイトに載っている、クロップ変更でも差別化。
2. **トーンを要件に合わせる。** エンタープライズ / B2B: ニュートラルパレット、自然光、実ワークスペース。コンシューマ / ライフスタイル: 暖光、人間の感情。テック / スタートアップ: ミニマル背景、ハンズオンインタラクション。
3. **多様な代表性。** Nappy.co は意図的キュレーションの無料ソース最良、Unsplash と Pexels は多様性を持つが検索努力が要る。
4. **合うアスペクト比。** ヒーロー写真は典型的にデスクトップ 16/9、モバイル 4/3 か 9/16。

### 避ける

- **可視のロゴ / 商標が写った写真** — 著作権リスク。
- **過処理 HDR** — 古く非現実的に見える。
- **演出された「チーム写真」ショット** — 汎用、ストックに読まれる。
- **未改変 Unsplash** — 今週、100 の競合サイトが同じ写真を使った。

---

## 抽象背景

### 正典

| ソース | URL | 出力 | 適する用途 |
| --- | --- | --- | --- |
| **CSS グラデーション（ネイティブ）** | n/a — 書く | 0 バイト、GPU 合成 | デフォルト。線形か放射状、カラーストップ 2〜3 個まで。 |
| **[Mesh Gradient Generator](https://www.learnui.design/tools/mesh-gradient-generator.html)** | learnui.design tools | Figma / SVG エクスポート | Apple スタイルのメッシュグラデ、エクスポートが有機ノイズを運ぶ。 |
| **[fffuel.co](https://www.fffuel.co/)** | fffuel.co | SVG | グレインノイズの `gggrain`、流体グラデの `ffflux`、波状メッシュの `uuunion`。組み合わせ可能。 |
| **[CSS Gradient](https://cssgradient.io)** | cssgradient.io | CSS 文字列 | クイックグラデーションピッカー、コピペ即可。 |

### ルール

1. **CSS グラデーション優先。** 0 バイト、無限にスケール、`@property` で滑らかにアニメ。CSS グラデが仕事をするなら SVG や画像に手を伸ばさない。
2. **カラーストップ 2〜3 個。** 3 個超は生成的に読まれる。色相を共有して明度でステップするストップを選ぶ。
3. **SVG `<feTurbulence>` でグレイン** を 0.1 未満不透明度、`mix-blend-mode: multiply`。安価、アセットなし、紙のように見える。
4. **ヒーローかアクセントカードのみ — 全ページには不可。** 100 vh のグラデーションはシグナル、40 vh ヒーローグラデ + 残りはベタ紙は意図的。
5. **全ページグラデーションにアニメなし。** ヒーローアクセントへの控えめな 30 秒ドリフトは許容、全ページをゆっくり回るメッシュグラデは新オーロラブロブアンチパターン。

### レシピ（CSS グラデーション + SVG グレイン）

```css
.hero {
  background:
    linear-gradient(135deg,
      color-mix(in oklch, var(--color-paper) 100%, var(--color-accent) 4%),
      color-mix(in oklch, var(--color-paper) 100%, var(--color-paper-2) 50%));
  position: relative;
}

.hero::after {
  content: "";
  position: absolute; inset: 0;
  background: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg'><filter id='n'><feTurbulence baseFrequency='0.9' numOctaves='2'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>");
  opacity: 0.06;
  mix-blend-mode: multiply;
  pointer-events: none;
}
```

### 避ける

- **オーロラブロブ** — 2022 Dribbble ルック。Critical アンチパターン。
- **紫からシアンのメッシュ** — 2023 デフォルト。Critical アンチパターン。
- **浮遊オーブ / 球体** — 汎用 3D 環境装飾。Critical アンチパターン。
- **パーティクル / 星空** — 2010 年代ノスタルジア、注意散漫。
- **全ページのアニメーションメッシュグラデ** — 回転グラデバナーの現代版。

---

## Lottie / Rive（Tier F — 最終手段）

### 正典

| ソース | URL | 適する用途 |
| --- | --- | --- |
| **[LottieFiles](https://lottiefiles.com)** | lottiefiles.com | Lottie エコシステム。無料 + pro ティア、npm + CDN、Figma プラグイン、AI クリエータ。 |
| **[Rive](https://rive.app)** | rive.app | ステートマシン付きインタラクティブリアルタイムアニメ。ネイティブランタイム、アプリ UI マイクロインタラクションには Lottie より良い。 |

### ルール

1. **Lottie は最終手段。** 複雑なキャラクターモーションが手組みできないときだけ手を伸ばす。[`custom-craft.md`](custom-craft.md) Tier F 参照。
2. **ライブラリ拾いよりカスタム発注。** ブランドに合う LottieFiles コミュニティアニメは存在するが、合う*かつ*他の LottieFiles コミュニティアニメと違って見えるものは稀。ヒーロー作品には発注（Upwork で $100〜$300、スタジオで $1,000+）する。
3. **< 2 MB ファイルサイズ。** これ以上重いものは自身のロード状態に負ける。
4. **一時停止 / 再開のサポート。** アクセシビリティに必須（モーション過敏ユーザーは制御が要る）。
5. **`prefers-reduced-motion` フォールバック** を静止キーフレームに。必須。
6. **CSS でできることに Lottie を使わない。** 回転ロゴ、チェックマーク描画、ロードスピナー、ホバーマイクロインタラクション — 全部 CSS 領域。スキルはスロップテストで「Lottie ショートカット」アンチパターンを捕まえる。

### 避ける

- **2019 年代の滑らかすぎるアニメ。** 古く、性格がない。
- **ページ自身より重いアニメ** — 200 KB ページに 5 MB の Lottie。
- **一時停止 / 再開なしのアニメ** — アクセシビリティ失格。
- **無改変の LottieFiles コミュニティ拾い** — 「ライブラリから拾った」に読まれる。

---

## クイックリファレンス: どの用途にどのソース

| 必要 | 第一選択 | 第二選択 |
| --- | --- | --- |
| UI アイコン（シェブロン、チェック、X） | Lucide | Phosphor / Heroicons |
| ロゴウォール用のブランドロゴ | Simple Icons | SVGL / theSVG |
| ブランドが所有するヒーローイラスト | 手組み（Tier A か B） | カスタム発注 |
| キャラクター主体のヒーローイラスト | Nanobanana 2（Tier C） | 発注、その後ライブラリ |
| スケールが必要な SVG 形式イラスト | Recraft V4 | Figma で手組み → SVG |
| 多様性のある写真 | Nappy.co | 手動トーン調整付き Unsplash |
| プロダクトのデモ動画 | カスタム画面録画 | （スキップ、合うストックなし） |
| テクスチャ背景 | CSS グラデ + SVG グレイン | Mesh Gradient Generator |
| キャラクターアニメ | カスタム Lottie 発注 | LottieFiles コミュニティ + カスタマイズ |
| ロードスピナー | CSS conic-gradient | （Lottie に手を伸ばさない） |
| 確認時のチェックマーク描画 | SVG `stroke-dasharray` | （Lottie に手を伸ばさない） |

迷ったら組む。2026 年において、最短路と最も AI シグナルが出ない路は同じ路。
