# タイポグラフィ

タイプがデザインを担う。タイプが間違っていれば、他が正しくても意味がない。

## 原則

- ページはペアであり、単一フォントではない。display 書体 ＋ body 書体、最低限。*単一フォント ページが許されるのは、その単一フォント自体がデザイン上の選択であるとき* — 真のターミナル美学は意図的にモノスペース全面、Manifesto ポスターは意図的に1つの display 書体。デフォルトはペア。
- 極端にコミットする。weight 200 と weight 800 を隣り合わせると意図的に読まれる。weight 400 と weight 600 はデフォルト設定として読まれる。
- サイズのステップは比率であり、加算ではない。Major third (1.25)、perfect fourth (1.333)、perfect fifth (1.5)、golden (1.618)。1つ選んで使い続ける。
- 行送りはサイズで変える。display にはタイト（1.05–1.2）、body には快適（1.5–1.65）。
- Measure — 行長 — は 45〜75 文字。デフォルトは `max-width: 65ch`。

## 2+1 ルール — 3書体が上限

**1ページで使える `font-family` は最大3つ。** 1つの **display**、1つの **body**、そして1つの **outlier**（任意）。outlier はワードマーク、ヒーロー スタット、プルクォート、マストヘッドなど、ページに残りと響きの異なる1つの音だけを置きたい場面用。4書体はスロップ。2書体が正規。3書体は上限、控えめに使う。

パターン。

```css
:root {
  --font-display:  "Fraunces", ui-serif, Georgia, serif;       /* 見出し、ヒーロー */
  --font-body:     "Geist", ui-sans-serif, system-ui, sans;    /* 散文、UI */
  --font-outlier:  "Geist Mono", ui-monospace, monospace;      /* ワードマーク＋ヒーロー スタットのみ */
}
```

outlier は *レジスター* であって、3つ目のサーフェスではない。ルール。

- **outlier はページ全体で ≤ 2 箇所** に出る。ワードマーク＋ヒーロー スタット。または プルクォート＋マストヘッド。2スロット、5ではない。3回目に手が伸びるなら、それは outlier ではなく3つ目の body フォント。スロップ。
- **outlier は1つの役割を担う。** 特定種類のコンテンツ（ブランド、見出しの数字、マニフェスト ライン）にタグ付けする。タグ対象が決まったら、その役割の全インスタンスでそれを使う。あるボタン ラベルに当て別では当てない、はしない。
- **mono は書体に数える。** Fraunces display ＋ Geist body ＋ Geist Mono in code blocks のページは3ファミリーを使っている。問題ない — code が outlier の役割。そこに4つ目を忍ばせない。
- **同じファミリーの異なるウェイトは1ファミリー**、2ではない。Geist 400 ＋ Geist 700 は1フォント。Fraunces を加えると2。Geist Mono を加えると3。

2書体はほとんどのページで正しい答え。3書体は SaaS／ブランド重視／編集色重視で、ワードマークが body と異なるレジスターを必要とするページ向け。

## 禁止のデフォルト

下記のフォントはどの LLM でも distribution-on の選択。意図的な理由なく手を伸ばさない。

- **Sans-serif:** Inter、Roboto、Open Sans、Lato、Poppins、Source Sans、Nunito、Montserrat、Raleway、Work Sans、DM Sans、system-ui、Arial、Helvetica。
- **Serif:** Merriweather、Playfair Display（body として禁止 — 多用された body セリフ。display としては節度を持って可）、Lora、Source Serif、Georgia-as-default。
- **Mono:** Courier New、Consolas-as-default、system mono。

ユーザーが固執するなら従う。それ以外は下記の許可リストから選ぶ。

## フォント カタログ

3つのソース、優先順。

- **Google Fonts** — 無料、CDN 経由、どこでも動く。デフォルトのソース。
- **Fontshare**（Indian Type Foundry） — 商用無料、foundry グレード。「これが無料だったとは」枠。`<link href="https://api.fontshare.com/v2/css?f=...">` でドロップイン。
- **Foundry-licensed** — Klim、Pangram Pangram、Production Type、Lineto、Colophon。ユーザーがライセンス済みを確認したときのみ。

### 無料の display 書体

| Family | Source | Voice | Best for |
| --- | --- | --- | --- |
| **Fraunces** | Google | バリアブル セリフ、深く表現的なイタリック、optical-size 軸 | Editorial、Salon、Atelier、ブランド重視 |
| **Newsreader** | Google | optical-size ＋ italic 付きローマン セリフ | Editorial、雑誌、長文 |
| **Instrument Serif** | Google | タイトなコントラスト、italic あり、短い見出しに賢い | ブランド、atelier、親密な編集色 |
| **Cormorant Garamond** | Google | 古典的、高コントラスト、ラグジュアリー レジスター | Luxury、ファッション、ファイン アート |
| **EB Garamond** | Google | 誠実な古典 Garamond、body 級 | Editorial 本文、長文の読み |
| **Cardo** | Google | 学術的セリフ、寛大な x-height | リファレンス、学術、ゆっくり読む |
| **Source Serif 4** | Google | モダンなトランジショナル、大きい OT ファミリー | セリフ調の SaaS マーケティング |
| **DM Serif Display** | Google | ブラケット付きセリフ、高コントラスト display | 印刷っぽさを欲しがる見出し |
| **Bodoni Moda** | Google | モダン Bodoni リバイバル、ドラマチック | ファッション、編集色、ラグジュアリー display |
| **Playfair Display** | Google | display としてのみ使用、body は禁止 | マーケティング display モーメント — 控えめに |
| **Geist** | Google | モダン グロテスク、ジオメトリック、7ウェイト | モダンミニマル、SaaS、開発者ツール |
| **Inter Tight** | Google | タイトな Inter — technical テーマの body フォールバックとして *のみ* 許可。display には使わない | 抑制テーマの UI body |
| **Bricolage Grotesque** | Google | バリアブル display サンス、ボールド、コンデンス可 | Brutal、playful、riso-bold |
| **Space Grotesk** | Google | ジオメトリック グロテスク、わずかにクセ | ブルータリスト、technical |
| **Anton** | Google | ヘビーなコンデンス グロテスク | ポスター、マニフェスト |
| **Big Shoulders Display** | Google | インダストリアル コンデンス | スポーツ、マニフェスト、宣言的 |
| **Tomorrow** | Google | バリアブル optical コンデンス | テック、atmospheric、近未来 |
| **Outfit** | Google | モダン ジオメトリック（デフォルト禁止、意図的に *picked* されたときのみ） | 抑制テック — 控えめに |
| **General Sans** | Fontshare | モダン グロテスク、Geist 隣接 | Geist のモダンミニマル代替 |
| **Switzer** | Fontshare | 中立サンス、広いウェイト範囲 | SaaS body、抑制 |
| **Cabinet Grotesk** | Fontshare | display グロテスク、9ウェイト | 編集色 display、雑誌 |
| **Clash Display** | Fontshare | 超コンデンス display | ポスター、ブランド モーメント |
| **Satoshi** | Fontshare | プレイフルなジオメトリック サンス | プレイフル、コンシューマ |
| **Sentient** | Fontshare | バリアブル セリフ、ソフト コントラスト | ソフト編集色、atmospheric |
| **Erode** | Fontshare | ディストレス セリフ、手組みの感触 | Riso、触覚的反骨、ブランド寄り |
| **Tanker** | Fontshare | ヘビーなコンデンス グロテスク、純 display | 1語ポスター、マストヘッド |

### 無料の body 書体

| Family | Source | Voice | Best for |
| --- | --- | --- | --- |
| **Geist** | Google | デフォルトのモダン body サンス | モダンミニマル、SaaS、atmospheric |
| **The Future** | （リポ内） | Hallmark 自前の body 仕事馬 | デフォルトの Hallmark トーン |
| **Newsreader** | Google | 読むためのセリフ、optical-size aware | 編集色 body、長文 |
| **Source Serif 4** | Google | body 級セリフ | 編集色の中庸ウェイト |
| **EB Garamond** | Google | 古典 body | ゆっくり読む編集色 |
| **Spectral** | Google | スラブ寄りセリフ、画面チューン | 画面上の長文 |
| **Lora** | Google | カリグラフィック セリフ、body 級 | body — 控えめに（多用された） |
| **Crimson Pro** | Google | オールドスタイル body、寛大 | 編集色の slow body |
| **IBM Plex Sans** | Google | エンジニアリング サンス、広いファミリー | 技術 body |
| **Switzer** | Fontshare | 中立サンス body | SaaS body、抑制 |
| **General Sans** | Fontshare | Geist 隣接 body | モダンミニマル body |

### 無料の mono / outlier 書体

| Family | Source | Voice | Best for |
| --- | --- | --- | --- |
| **Geist Mono** | Google | Geist の mono 相棒 | デフォルトの Hallmark mono、コード、キャプション |
| **JetBrains Mono** | Google | エンジニアリング mono、リガチャ | コード、ターミナル、技術 |
| **IBM Plex Mono** | Google | エンジニアリング mono、広いファミリー | 技術の body 級 |
| **Commit Mono** | Google | タイトな mono、モダン | コード、モダン ターミナル |
| **Space Mono** | Google | クセあり、わずかにレトロ | プレイフル テック、riso |

### トーン別ペアリング パターン

各トーンに2行: **free baseline**（Google Fonts / Fontshare、すぐ使える）と **paid upgrade**（foundry ライセンス必要、ユーザーが予算とライセンスを確認したときのみ）。free 行がデフォルト。**ユーザーがライセンス済みと確認しないまま paid フォントをコードに書かない** — デモはシステム デフォルトにフォールバックし、ユーザーに壊れて見える。

| Tone | Tier | Display | Body | Outlier |
| --- | --- | --- | --- | --- |
| **Editorial** | Free | Fraunces · Newsreader · EB Garamond · Instrument Serif · Cabinet Grotesk | IBM Plex Sans · Switzer · Source Serif 4 | JetBrains Mono · Geist Mono · Erode (display moment) |
| | *Paid* | *Tiempos Headline · Söhne Breit · Reckless Display · Migra · Tobias* | *Söhne · Haffer · Untitled Sans* | *Söhne Mono · GT America Mono* |
| **Technical** | Free | JetBrains Mono · Geist Mono · Geist (700) · Commit Mono | Geist · IBM Plex Sans · Switzer | Tomorrow · Cabinet Grotesk (wordmark) |
| | *Paid* | *Berkeley Mono · Söhne Mono · GT Pressura · ABC Diatype Mono* | *Söhne · Untitled Sans · ABC Diatype* | *Berkeley Mono · GT Pressura Mono* |
| **Brutalist** | Free | Bricolage Grotesque (800) · Anton · Tanker · Big Shoulders Display | Geist · Switzer | Space Grotesk (numerals) · Geist Mono |
| | *Paid* | *Druk · Monument Extended · NaN Jaune · Migra · ABC Pressura* | *Söhne Breit · GT America* | *GT America Mono* |
| **Soft** | Free | Geist · Bricolage Grotesque (500) · Sentient · Newsreader | Geist · Crimson Pro · Switzer | Geist Mono · Satoshi (label) |
| | *Paid* | *Söhne · GT Pressura · Pangaia · Tobias* | *Söhne · Halyard Text · Satoshi* | *Söhne Mono · GT Maru Mono* |
| **Luxury** | Free | Cormorant Garamond · Fraunces · Cardo · DM Serif Display · Bodoni Moda | EB Garamond · Crimson Pro · Source Serif 4 | (まれ、display ファミリーのスモール キャップ) |
| | *Paid* | *Canela · Tiempos Headline · GT Super · Domaine Display · Migra* | *Tiempos Text · Suisse Int'l · Domaine Text* | *(この階層では稀に使う)* |
| **Playful** | Free | Bricolage Grotesque · Fraunces (italic) · Satoshi · Newsreader (italic) · Sentient | Geist · Newsreader · Satoshi | Geist Mono · Space Mono |
| | *Paid* | *Clash Display · Cabinet Grotesk · Migra · Tobias · Pangaia* | *Satoshi · Plus Jakarta Sans · GT Maru* | *Space Mono · GT Maru Mono* |
| **Austere** | Free | system-ui · Inter Tight (regular) · Geist (400) · Switzer (regular) | system-ui · Geist · Switzer | system-ui mono · Geist Mono |
| | *Paid* | *ABC Diatype · ABC Monument Grotesk · Söhne (regular) · ABC Pressura* | *ABC Diatype · Söhne* | *ABC Diatype Mono · Söhne Mono* |
| **Atmospheric** | Free | Geist (600) · Sentient · Tomorrow · Bricolage Grotesque | Geist (400) · Switzer | Geist Mono · JetBrains Mono |
| | *Paid* | *Söhne · GT Pressura · ABC Diatype* | *Söhne · ABC Diatype* | *Berkeley Mono · Söhne Mono* |
| **Workshop** *(Hallmark 自前のテーマ)* | Free | The Future · Geist · Cabinet Grotesk | The Future · Switzer | The Future Mono · Geist Mono |
| | *Paid* | *Avenir Next · GT Walsheim* | *Söhne · GT Walsheim* | *Berkeley Mono* |

**規律。** デフォルトは無料ペアリング。これらは慰めの選択肢ではない。Fraunces、Geist、Bricolage Grotesque、Cabinet Grotesk、Sentient、JetBrains Mono は 2026 年の一流書体。paid アップグレードは2つのケースのため: (a) ユーザーがライセンス済みと明示的に確認した、または (b) ユーザーが特定の名指し foundry ボイスを欲している（例: "make it look like Klim"、"I want Söhne"）。それ以外で Tier 2 に手を伸ばさない。それ以外は free 行が正解。free 行を正典として扱い、paid 行を *引用* された代替として扱う。

## ワードマーク／ロゴのタイポグラフィ

ナビとフッターのワードマークは **body と異なる display 書体を使ってよい**。トーンが豊かなテーマ（Editorial、Salon、Atelier、Linen、Quiet）では **使うべき** — ワードマークを body ファミリーに畳むと視覚階層が平板になり、ページがブランド感を欠いて読まれる。

```css
:root {
  --display:       "Geist", system-ui, sans-serif;     /* body ＋ display */
  --font-wordmark: "Fraunces", Georgia, serif;         /* ロゴのみ */
}
.wordmark {
  font-family: var(--font-wordmark);
  font-weight: 600;
  letter-spacing: -0.015em;
}
```

推奨ペアリング（無料ベースライン先）。

- **Geist body → Fraunces wordmark、IBM Plex Mono wordmark、Bricolage Grotesque（ヘビー）wordmark**
- **Fraunces body → Geist Mono wordmark、Inter Tight wordmark**
- **System-ui body → JetBrains Mono wordmark、Newsreader wordmark**
- **Inter Tight body → Fraunces wordmark、EB Garamond wordmark**

両方に同じファミリーを使うとき。

- **Editorial · Letter · Manifesto · Long Document** は body ボイスがブランドを担うので、単一ファミリーに畳んでよい。これらの文脈のワードマークは小さく、地に足が付き、装飾ではなく組まれることでウェイトを稼ぐ。

対比的なファミリーを使うとき。

- **Bento Grid · Stat-Led · Workbench · Marquee Hero** — これらは視覚的に汎用化しやすい原型（ジオメトリック グリッド、大きい数字、ブラウザ フレーム モックアップ）で、ワードマークが body にできないタイポグラフィ的差別化を担う必要がある。

**SaaS ページで同ファミリー畳みを避ける。** ワードマークも Geist 600 の Geist-only ページは未設計に読まれる。Geist body 上の Fraunces SemiBold のワードマークはコストなしで *this is a brand* と語る1つのタイポグラフィ レジスターを加える。

## スケール

比率を選ぶ。Hallmark 仕事のデフォルトは **1.25**（major third）。16px body から構築し、レスポンシブでは display を clamp。

```css
:root {
  --text-xs:   0.64rem;   /* 10.24px */
  --text-sm:   0.8rem;    /* 12.8px  */
  --text-base: 1rem;      /* 16px    */
  --text-md:   1.25rem;   /* 20px    */
  --text-lg:   1.5625rem; /* 25px    */
  --text-xl:   1.9531rem; /* 31.25px */
  --text-2xl:  2.4414rem;
  --text-3xl:  3.0518rem;
  --text-4xl:  3.8147rem;
  --text-display: clamp(2.75rem, 5vw + 1rem, 5.25rem);
}
```

**Display の上限 — ≤ 5.5rem (88 px) を保つ。** これを超えると、ヒーローの見出しが 1280–1440 px のビューポートで自分を窮屈にし、複数行折り返しが必要となり、ほぼ常にドラマであって重みではなく読まれる。Manifesto / Brutal の display 重視テーマでも 6rem (96 px) を上限。例外は単一行・単一語の display（例: スタット）が ≤ 12 ch を占めるとき。7rem まで伸びてよい。**デフォルトの emit フォーマットは `clamp(2.75rem, 5vw + 1rem, 5.25rem)`。**

### ヒーロー見出しのサイジング — 文言長にサイズを合わせる

描画されるヒーロー `h1` の文字数を数える。バケットで上限を選ぶ。テーマ別の `--text-display` clamp の上にこのルールが乗る。

| 見出し長 | サイズ上限 | 注記 |
| --- | --- | --- |
| **≤ 20 文字**（例 *"Limitless"*、*"Made not generated"*） | フル `--text-display`、単一語なら 7rem まで可 | Display 重視テーマのみ |
| **21–50 文字**（デフォルトのスイート スポット） | `--text-display` | 414 px で2行を超えるなら、`--text-display-s` に1段下げる |
| **51–90 文字** | `--text-display-s` で上限 | eyebrow ＋見出しに分割を強く検討 |
| **> 90 文字** | 短く書き直す、または `--text-4xl` でタイトなリーディングで上限 | display サイズで 100 文字の見出しは最も信頼できる AI 痕跡 |

**Display 重視のテーマは見出しが 50 文字を超えたら1段下げる。** Brutal、Riso、Manifesto は `--text-display` を 6.5–9rem で上限。その天井は ≤ 50 文字のステートメントのため。50 文字を超えたら `--text-display-s` に自動ルート。**自分で見出しを書くとき（ユーザー提供のコピーなし）、最初から ≤ 7 語かつ ≤ 50 文字を目標に** — 命令形か名詞句、動名詞先頭にしない。

1ページで5サイズを超えないこと。さらなる階層が要るなら、別サイズではなくウェイトと色を使う。

## ウェイト

- Body: 1ウェイト（通常 400 または 350）。強調にのみボールド。
- 見出し: body より少なくとも 300 ユニット コントラストするウェイト。body が 400 なら見出しは 700 か 200。500 や 600 ではない。
- 合成しない。必要なウェイトをロードする。単一ウェイト ファイルに対する `font-weight: bold` に頼らない。

## 必須機能

- すべての web フォントに `font-display: swap`。
- フォールバック メトリクスを `size-adjust`、`ascent-override`、`descent-override`、`line-gap-override` で合わせて CLS を防ぐ。
- データ表示には Tabular numbers: `font-variant-numeric: tabular-nums;`。
- body コピーで対応書体なら Oldstyle 数字: `font-variant-numeric: oldstyle-nums;`。
- 正しいタイポグラフィ句読点: `" " — … ‘ ’`。ストレート引用符、`--`、`...` を使わない。

## 本文テキストのルール

- 最低 16px。14px 未満はアクセシビリティ敵対的。
- body コピーの行送りは 1.5–1.65、display はタイト（1.1–1.3）。**全大文字 display 見出し（`.hero__display` / `.section__title` / `h1` / `h2` の `text-transform: uppercase`）の床は `1.0`、推奨 `1.02–1.08`。** 1.0 未満では N+1 行のキャップトップが N 行のベースラインと衝突する（ディセンダーがギャップを和らげない）。"PROMPT, / DIFFERENT" で折り返した2行のコンマ＋大文字 D が単一グリフ ブロブに融合する。コンデンスド display 書体（Anton、Inter Tight 900、Bebas Neue）は悪化させる。Gate 67 がこのパターンを auto-fail する。
- Measure 45–75 文字（`max-width: 65ch`）。
- 全大文字の本文コピーは絶対なし。ハイフネーションなしの両端揃えは絶対なし。本文に 0.05em を超える letter-spacing は絶対なし。

## 見出しのルール

- display サイズはタイトなトラッキング（書体により `letter-spacing: -0.02em` から `-0.04em`）。
- スモール キャップ／ラベルはルーズなトラッキング（`letter-spacing: 0.08em` から `0.14em`、`text-transform: uppercase`、書体にスモール キャップがあれば `font-variant-caps: all-small-caps;`）。
- レベルを飛ばさない。`h1` → `h2` → `h3`。視覚的には好きにスタイリングしてよい。意味的順序は保つ。

## 禁止

- Inter なし、Roboto なし、Open Sans なし。system stack *のみ* もなし。
- 見出しのグラデーション テキスト（グラデーション塗りの `background-clip: text`）。
- 単一フォント ページ。
- 全大文字の段落。
- body コピーで 14px 未満、どこでも 10px 未満のフォント サイズ。
- ハード合成のボールドやイタリック。
- **1ページで3ファミリーを超えない。** display ＋ body ＋ outlier 1つが上限。4ファミリーはスロップ。監査ゲート。
- outlier 書体を2スロット超で使う。ワードマーク＋ヒーロー スタットが正規ペア。3スロット目に手が伸びたら、body 書体に畳む。
