# コンポーネントクックブック

任意のマクロ構造に組み込める36のコンポーネント原型。各エントリは、形状、1行の「Use when」、1行の「Don't confuse with」、短い構造スケッチ（DOM ＋最小 CSS）を持つ。セクションを作るときにどの形状を選ぶか迷ったら、このファイルから選ぶ。

同じマクロ構造（例 Bento Grid）も、これらの原型の異なる組み合わせで構築できる。マクロ構造は *ページの形* を、このファイルは *その中のコンポーネント* を選ぶ。

**多様化ルール:** 1ページ内で2セクションが同じ原型を使わない。Bento Grid は *Bento feature block* と *Inline form CTA* と *Logo wall (hairline)* を組み合わせるかもしれない。Hallmark が次に作るページでは同じカテゴリから別の原型を選ぶ。

---


---

## 原型インデックス — 必要なものだけ読み込む

**ここで原型名を選び、`references/components/` から *その個別ファイルだけ* を読む。** クックブック全体を読み込まない。典型ビルドは 5〜7 ファイル: ヒーロー1＋セクション見出し1＋フィーチャー1〜2＋ CTA 1＋フッター1＋ナビ1。

### ヒーロー

- **H1 · Marquee** — 単一のステートメントがファーストビューを埋める。サブヘッドなし、ファーストビュー内に CTA なし。[`components/h1-marquee.md`](components/h1-marquee.md)
- **H2 · Split diptych** — 片側に見出し＋リード、もう片側に画像かプロダクト キャプチャ。6/6 または 7/5 カラム。[`components/h2-split-diptych.md`](components/h2-split-diptych.md)
- **H3 · Quote led** — 出典付きのプルクォートがヒーロー。見出しは借りた信頼性。[`components/h3-quote-led.md`](components/h3-quote-led.md)
- **H4 · Stat led** — 巨大な数字またはメトリックがヒーロー。下に小さい修飾行。[`components/h4-stat-led.md`](components/h4-stat-led.md)
- **H5 · Letter hero** — 一人称の opening — "Dear reader,"。ファーストビューにボタンなし。個人的な通信のように読める。[`components/h5-letter-hero.md`](components/h5-letter-hero.md)
- **H6 · Photographic fold** — 全幅の画像1枚がビューポートを埋める。キャプションは隅に座る。[`components/h6-photographic-fold.md`](components/h6-photographic-fold.md)
- **H7 · Demo video clipped by viewport edge** — display 見出し左、デモ動画右、右端の約 10–20% を意図的にビューポート外に切り出す。クリップ *が* デザイン — 「プロダクトには続きがある」を含意。[`components/h7-demo-video-clipped-by-viewport-edge.md`](components/h7-demo-video-clipped-by-viewport-edge.md)
- **H8 · Mockup split browser framed** — 見出し左、ブラウザ フレーム モックアップ右、モックアップを 1–3° 傾けて生気を与える。フレームはブラウザ クローム、macOS ツールバー、最小ヘアライン、フレームなしフローティング のいずれか。[`components/h8-mockup-split-browser-framed.md`](components/h8-mockup-split-browser-framed.md)
- **H9 · Custom illustration centerpiece** — 1つの手組み SVG（エンリッチメント階層の Tier B、より単純な形状なら Tier A の純 CSS）をヒーロー上の1つのイラスト要素として置く。ベーカリーのパン、スタジオの[`components/h9-custom-illustration-centerpiece.md`](components/h9-custom-illustration-centerpiece.md)

### セクション見出し

- **S1 · Left margin numbered** — 細い左カラムに `01 — LABEL.`、広い右カラムに見出しとコンテンツ。[`components/s1-left-margin-numbered.md`](components/s1-left-margin-numbered.md)
- **S2 · Hanging** — 見出しがセクション上方のネガティブ スペースに浮かぶ。ボーダーなし、ルールなし。[`components/s2-hanging.md`](components/s2-hanging.md)
- **S3 · Sticky pinned** — 下を本文がスクロールしても見出しはビューポートに留まる。方向付けの補助。[`components/s3-sticky-pinned.md`](components/s3-sticky-pinned.md)
- **S4 · Inline no break** — 見出しは本文フローの *中* から現れるスモール キャップのフレーズ。空間的ブレイクなし。[`components/s4-inline-no-break.md`](components/s4-inline-no-break.md)
- **S5 · Bottom anchored** — ラベルまたは見出しがセクション コンテンツの *下* に座る。階層を反転する。[`components/s5-bottom-anchored.md`](components/s5-bottom-anchored.md)

### フィーチャー ブロック

- **F1 · Bento grid** — 異なるスパン（1×1、2×1、1×2、2×2）の 8〜15 タイルの非対称グリッド。視覚リズムはサイズから。[`components/f1-bento-grid.md`](components/f1-bento-grid.md)
- **F2 · Sticky scroll stack** — 固定の左ペイン、スクロールする右ペインが関連スクリーンショットを循環。[`components/f2-sticky-scroll-stack.md`](components/f2-sticky-scroll-stack.md)
- **F3 · Tabular spec sheet** — 各行がフィーチャー、カラムが name、value、footnote を保持。行間にヘアライン ルール。Tabular 数字。[`components/f3-tabular-spec-sheet.md`](components/f3-tabular-spec-sheet.md)
- **F4 · Step sequence** — 番号付きステージ（`1.0 → 2.0 → 3.0`）が縦に流れる。各ステージに見出し、段落、小さな視覚要素を時々。[`components/f4-step-sequence.md`](components/f4-step-sequence.md)
- **F5 · Annotated screenshot** — プロダクト キャプチャがセンター ステージに座り、矢印か短いラベルが UI 詳細を指す。[`components/f5-annotated-screenshot.md`](components/f5-annotated-screenshot.md)
- **F6 · Product card grid** — 各カードはプロダクト（フィーチャーではない）。画像 · 名前 · 価格 · 1つのマイクロ アクション。マーケティング サイトではなく店舗フロアのように読める。[`components/f6-product-card-grid.md`](components/f6-product-card-grid.md)

### CTA / サインアップ

- **C1 · Outlined chip** — タイポグラフィ動詞コマンド（"Save changes"）の透過ボーダー ボタン。[`components/c1-outlined-chip.md`](components/c1-outlined-chip.md)
- **C2 · Inline form as cta** — CTA *が* フォーム — 1つのメール入力＋隣の "Submit →"。サインアップ用の別ランディングなし。[`components/c2-inline-form-as-cta.md`](components/c2-inline-form-as-cta.md)
- **C3 · Typographic link** — 単語、矢印、1px の下線だけ。ボックスなし、塗りなし。[`components/c3-typographic-link.md`](components/c3-typographic-link.md)
- **C4 · Sticky bottom bar** — ビューポート底に固定された水平バー、CTA ＋短い安心ラインを保持。[`components/c4-sticky-bottom-bar.md`](components/c4-sticky-bottom-bar.md)

### テスティモニアル／証拠

- **T1 · Pull quote with marginalia** — クォートが広いカラムに座り、出典とソース リンクが細いマージン カラムに浮かぶ。[`components/t1-pull-quote-with-marginalia.md`](components/t1-pull-quote-with-marginalia.md)
- **T2 · Logo wall hairline** — 顧客ロゴの行、モノクロ、ヘアライン ルールで区切る。カード ボックスなし、シャドウなし。[`components/t2-logo-wall-hairline.md`](components/t2-logo-wall-hairline.md)
- **T3 · Single huge quote** — 1つのクォート、大きく組み、中央寄せ、セクション全体を占有。サポート テキストなし、出典ボックスなし — 出典は下のスモール キャップ行。[`components/t3-single-huge-quote.md`](components/t3-single-huge-quote.md)
- **T4 · Numbered stat strip** — 1行を横切る 3〜5 つのスタット（カウント＋修飾語）の水平帯。Tabular 数字。[`components/t4-numbered-stat-strip.md`](components/t4-numbered-stat-strip.md)

### フッター

- **Ft1 · Mast headed** — ワードマークとタグラインが単一の水平帯を支える。横に2〜3個の小さなリンク、下に住所かライセンス。[`components/ft1-mast-headed.md`](components/ft1-mast-headed.md)
- **Ft2 · Inline rule single line** — クレジット、住所、コピーライトの単一水平行。上にヘアライン ルール。カラムなし。[`components/ft2-inline-rule-single-line.md`](components/ft2-inline-rule-single-line.md)
- **Ft3 · Index style category list** — 3〜4 の短いカラム、各カラムはスモール キャップのカテゴリ見出し、4〜6 リンクずつ。[`components/ft3-index-style-category-list.md`](components/ft3-index-style-category-list.md)
- **Ft4 · Dense typographic** — クレジット、参照、ライセンス、住所の大きなテキスト ブロック1つ、小さいモノスペース フォント、両端揃えかラグドライト。編集色のコロフォン エネルギー。[`components/ft4-dense-typographic.md`](components/ft4-dense-typographic.md)
- **Ft5 · Statement** — 1つの大きい display 文がフッターを支配する — クロージング ライン、サイトマップではない。ワードマーク、最小限のリンク、コピーライトは下のミュートな小型タイプ。Stripe（旧）、Mailchimp 旧期[`components/ft5-statement.md`](components/ft5-statement.md)
- **Ft6 · Letter close** — 手紙のようにページを閉じる — `Yours, the team. 2026.`。下に任意のポストスクリプト行。ページをプロダクトではなく文章として位置付ける。[`components/ft6-letter-close.md`](components/ft6-letter-close.md)
- **Ft7 · Newsletter first** — フォーム（ラベル＋入力＋送信）がフッターの *主* 要素。他（ワードマーク、リンク、コピーライト）は下に 12 px のミュート タイプ。Stratechery、Substack 系[`components/ft7-newsletter-first.md`](components/ft7-newsletter-first.md)
- **Ft8 · Marquee scroll** — 反復するタグライン＋ドット区切りの水平無限スクロール: `STUDIO · 2026 · STUDIO · 2026 · STUDIO · 2026 ·`。スポーツ ジャンル、ファッション ルックブック、ブランド前面のエージェンシー[`components/ft8-marquee-scroll.md`](components/ft8-marquee-scroll.md)

### ナビゲーション

- **N1 · Wordmark 2 links** — ページ最上部のバー: 左にワードマーク、右に2本のテキスト リンク（"Pricing" / "Sign in"）。ロゴ画像なし、メニュー アイコンなし。[`components/n1-wordmark-2-links.md`](components/n1-wordmark-2-links.md)
- **N2 · Floating chip** — 隅の小さい固定チップ — ワードマーク＋単一アクション（"Try it"）。ドキュメント フローに入らない。[`components/n2-floating-chip.md`](components/n2-floating-chip.md)
- **N3 · Side rail** — 左端の細い縦の帯 — 縦書きのワードマーク、加えてセクション用の 2〜3 ドット インジケータ。編集色／ポートフォリオ エネルギー。[`components/n3-side-rail.md`](components/n3-side-rail.md)
- **N4 · Hidden behind k** — 可視のナビなし。ユーザーは `⌘K` でコマンド パレットを開いてどこにでも行ける。キーボード ファーストのオーディエンス向け。[`components/n4-hidden-behind-k.md`](components/n4-hidden-behind-k.md)
- **N5 · Floating pill** — 角丸フルピルのナビ、ページ端から *visibly detached*、上から約 `var(--space-md)` 離れ、ソフト ブラー バックドロップ、ソフト シャドウ。現代のモダンミニマルとして読まれる — Ve[`components/n5-floating-pill.md`](components/n5-floating-pill.md)
- **N6 · Newspaper masthead** — 全幅ヘッダー、上段に大きな中央寄せワードマーク、その上下にセリフ スモール キャップの細い issue/date 行、下に任意のインライン リンク行、全体の下にダブル ルール[`components/n6-newspaper-masthead.md`](components/n6-newspaper-masthead.md)
- **N7 · Brutal slab** — ヘビーな全幅ナビ、2 px のソリッド border-bottom、全大文字ワードマークとトラックされた大文字リンク行、密なリズム、シャドウなし、角丸なし。Pentagram プロジェクト ページとして読まれる[`components/n7-brutal-slab.md`](components/n7-brutal-slab.md)
- **N8 · Terminal command** — CLI プロンプトとしてフォーマットされたナビ: `> studio --catalog --voice --get▮`。「リンク」はコマンド フラグ。点滅カーソル（`▮`）は *ここだけ* 許可（目的がある — 「次に入力する」を示す）。[`components/n8-terminal-command.md`](components/n8-terminal-command.md)
- **N9 · Edge aligned minimal** — ワードマーク硬左、単一 CTA 硬右、間は広大な空白、リンク行なし。*不在* がデザイン — Apple プロダクト ページ、Carl Hauser、ラグジュアリー サイト。[`components/n9-edge-aligned-minimal.md`](components/n9-edge-aligned-minimal.md)
- **N10 · Floating on scroll morph** — トップの sticky バーが、ユーザーが閾値を超えてスクロールすると **浮遊ピルにモーフ** する。2つの視覚モードが1つの DOM を共有 — `.nav`（外側）がバーの見た目、`.nav__inner`[`components/n10-floating-on-scroll-morph.md`](components/n10-floating-on-scroll-morph.md)

---

## 原型内のバリエーション ノブ

原型を選ぶことが多様性の第1軸。第2軸は *どう作るか*。同じ原型で構築された2ページが同一であってはならない。下記の各原型は 2〜3 個の *バリエーション ノブ* を持つ。出力ごとに各ノブから1値を選ぶ。これが「自分が作る Bento はどれも同じ Bento に見える」を防ぐ。

原型を選んだら、**選んだノブ値を** マクロ構造スタンプ コメントに記す。例。

```css
/* Hallmark · macrostructure: Bento Grid · F1 Bento knobs: tiles=6, spans=irregular, accent=corner-only · ... */
```

| 原型 | Knob A | Knob B | Knob C |
| --- | --- | --- | --- |
| **H1 Marquee** | Display size: `xxl` (clamp 4–12rem) · `xl` (clamp 3–8rem) | Alignment: left-bias · centred · right-bias | Underlay: none · single rule above · single rule below |
| **H2 Split Diptych** | Ratio: 7/5 · 6/6 · 5/7 | Right side: photo · proof column · pull-quote | Divider: hairline · negative space · vertical rule |
| **H3 Quote-Led** | Quote weight: italic display · roman display · roman body large | Attribution position: under quote · margin-aligned · right-flush | Length: ≤80 chars · 80–160 chars |
| **H4 Stat-Led** | Number style: tabular display · italic display · monospace | Qualifier position: below · inline-right · stacked-above | Secondary stats: none · two below · row of four |
| **H5 Letter** | Salutation: greeting · "Dear X," · time-stamp | Body length: 1 paragraph · 2 paragraphs · 3 paragraphs | Signoff: typed name · drawn signature SVG · initials |
| **H6 Photographic** | Image area: full-bleed · 16/7 · 4/3 · 1/1 square | Caption position: lower-left · upper-right · margin | Text below or overlaid |
| **H7 Demo Video Clipped-Edge** | Clip side: right · left · both | Aspect ratio: 16/10 · 16/9 · 4/3 | Frame: hairline · browser chrome · none |
| **H8 Mockup Split** | Frame style: browser chrome · macOS toolbar · minimal hairline · floating no-frame | Tilt: 0° · 1.5° · 3° | Screenshot count: 1 · stack-of-3 · orbit-of-3 |
| **H9 Custom Illustration** | Build method: Tier-A pure-CSS · Tier-B hand-SVG · Tier-C generated · Tier-D library | Animation: none · loop · scroll-linked | Scale: small accent · dominant |
| **F1 Bento (feature)** | Tiles: 4 · 6 · 7 · 9 | Spans: regular · irregular · mosaic | Border: hairline all · accent corners · none |
| **F2 Sticky-scroll stack** | Pinned side: left · right | Right pane content: code · screenshot · diagram | Pin steps: 3 · 4 · 5 |
| **F3 Tabular spec sheet** | Columns: 2 (key/val) · 3 (key/val/unit) · 4 (with footnote) | Rule density: every row · groups of 3 · headers only | Numbers: tabular · proportional |
| **F4 Step sequence** | Numbering: I/II/III · 01/02/03 · 1.0/2.0/3.0 | Layout: vertical stack · horizontal flow · diagonal | Connector: line · arrow · none |
| **F5 Annotated screenshot** | Callouts: numbered pins · margin labels · inline arrows | Frame: device · plain · floating | Anchor: image-led or text-led |
| **F6 Product card grid** | Card ratio: 3/4 portrait · 1/1 square · 4/3 landscape | Density: 3-up · 4-up · 5-up | Micro-action: Add · Save · View → · none |
| **C1 Outlined chip** | Shape: rectangular · pill (only allowed for tactile/playful tones) · slab | Density: spacious · compact | Adornment: arrow · plus · none |
| **C2 Inline form-as-CTA** | Field count: 1 · 2 · 3 | Submit position: end-of-row · separate line · embedded button | Helper: above · below · none |
| **C3 Typographic link CTA** | Underline: solid · dashed · double · none | Hover behaviour: thicken · slide · colour shift | Arrow: → · ↗ · none |
| **C4 Sticky bottom bar** | Reveal: always · scroll-up · after fold | Anchored: viewport bottom · viewport top · inline at bottom | Shadow: hairline · none · subtle |
| **T1 Pull quote w/ marginalia** | Quote treatment: italic display · roman large · serif italic | Attribution: signed · stamped · timestamped | Marginalia: none · timeline · 1 footnote |
| **T2 Logo wall (hairline)** | Layout: single row · 2 rows · grid 3×N | Logo treatment: monochrome ink · brand colour · ghosted | Divider: hairline cells · none |
| **T3 Single huge quote** | Quote face: serif italic · roman display · italic mono | Width: full-bleed · 60ch · 40ch | Attribution position: same line · separate band |
| **T4 Numbered stat strip** | Layout: 3-up · 4-up · 5-up · 6-up | Number weight: display · body large | Qualifier position: under · inline · above |
| **Ft1 Mast-headed** | Wordmark size: display 3xl · display 2xl · xl | Tagline: italic serif · roman body · none | Links row: inline · 2-line stack |
| **Ft2 Inline single line** | Order: wordmark/links/credit · credit/wordmark/links | Separator: middot · pipe · em-dash · vertical rule | Density: dense · spaced |
| **Ft3 Index columns** | Columns: 3 · 4 · 5 | Heading style: small caps · italic · monospace | Bullet: hairline · none |
| **Ft4 Dense colophon** | Family: monospace · serif · sans | Layout: single block · paragraphs · log-style | Includes: build hash · date · attribution |
| **N1 Wordmark + 2 links** | Position: left/right split · centred · right-flush | Links: text · text+icon · pill | Sticky: yes · no |
| **N2 Floating chip** | Anchor: top · bottom · top-right · bottom-left | Content: theme picker · search · navigation | Backdrop: blur · solid · none |
| **N3 Side-rail** | Side: left · right | Width: 12ch · 16ch · 20ch | Indicator: filled bar · text-only · numbered |
| **N4 Hidden behind ⌘K** | Trigger: button · keyboard only · both | Surface: modal · sheet · spotlight | Recents: shown · hidden |
| **N5 Floating pill** | Width: content-sized · max ~720 px · max ~560 px | Backdrop: blur+saturate · solid · subtle gradient | Anchor: top-centred · top-right · top-left |
| **N6 Newspaper masthead** | Issue line: above wordmark · below wordmark · none | Wordmark size: 3xl · 2xl · xl | Rule: double · single · none |
| **N7 Brutal slab** | Border weight: 2 px · 3 px · 4 px | Letter-spacing: tracked uppercase · normal | CTA: filled slab · outline block · text-only |
| **N8 Terminal command** | Prompt: `>` · `$` · `~/$` | Cursor: in-line at end · after final flag · none | Width: full bleed · content · ~80 ch |
| **N9 Edge-aligned minimal** | CTA shape: outlined · filled pill · text+arrow | Wordmark: serif italic · sans · monospace | Padding-block: tight · default · spacious |
| **Ft5 Statement** | Sentence width: 28 ch · 38 ch · 50 ch | Wordmark position: under sentence · top-right · none | Rule above meta: hairline · double · none |
| **Ft6 Letter close** | Signoff: italic · roman · monogram | Postscript: yes · no | Width: 40 ch · 60 ch · 80 ch |
| **Ft7 Newsletter-first** | Layout: stacked · inline · split (form left · meta right) | Submit style: filled · outline · arrow link | Privacy line: yes · no |
| **Ft8 Marquee scroll** | Speed: 24 s · 32 s · 48 s | Direction: left · right · alternate (rare) | Glyph: middot · em-dash · slash |

**アンチパターン:** 2つの異なる出力で同じノブ値を選ぶのは、同じ原型を選ぶのと同じ種類のテンプレ化。直前の Bento が `tiles=6, spans=irregular, accent=corner-only` だったら、次は少なくとも1つのノブを変える。

---


## ルーティング — どのフッターがどのジャンルに合うか

| ジャンル | デフォルト | 許容代替 |
| --- | --- | --- |
| editorial | **Ft1 Mast-headed** | Ft2, Ft4, Ft6, Ft7 |
| modern-minimal | **Ft2 Inline single line** | Ft1, Ft5 |
| atmospheric | **Ft5 Statement** | Ft1, Ft2 |
| playful | **Ft8 Marquee scroll** | Ft5, Ft3 |
| terminal | **Ft4 Dense colophon** | Ft2 |
| docs / reference | **Ft3 Index columns** | Ft1 |

**多様化。** ナビと同じルール — 同セッションで連続する Hallmark 実行で、2つの出力が同じフッター原型を共有しない。

**Ft3 をデフォルトにしない。** 反射的に使うと AI 指紋になる 4 カラムのインデックス フッター（Product · Company · Resources · Legal ＋ソーシャル行＋小さなコピーライト）。Ft3 はページがハブか docs ルートで genuine なサイトマップがあるときのみ。デフォルトは Ft1、Ft2、Ft4、Ft5、Ft6、Ft7、Ft8 のいずれか。

---


## ルーティング — どのナビがどのジャンル／テーマに合うか

| ジャンル／クラスタ | デフォルト ナビ | 許容代替 |
| --- | --- | --- |
| editorial（Newsprint · Salon · Garden · Linen · Atelier） | **N6 Masthead** | N1, N9 |
| modern-minimal（Specimen · Quiet · Coral · Violet · Plume） | **N5 Floating pill** | N1, N9 |
| atmospheric（Bloom · Aurora · Halo · Midnight） | **N5 Floating pill**（ブラー バックドロップがムードを売る） | N9, N4 |
| playful（Brutal · Manifesto · Sport · Riso · Studio） | **N7 Brutal slab** | N1, N3 |
| terminal / CLI（Terminal） | **N8 Terminal command** | N4 ⌘K のみ |
| docs / reference（Almanac） | **N3 Side-rail** | N1, N4 |

**多様化。** 同プロジェクト セッション内で連続する Hallmark 実行で、ジャンルが同じでも2つの出力が同じナビ原型を共有しない。直前が modern-minimal で N5 を使ったなら、次の modern-minimal ページはルーティング表の「代替」列から N1 か N9 を選ぶ。

**N1 をデフォルトにしない。** 反射的に使うと最も認識される AI 指紋になる N1（ワードマーク＋インライン リンク行＋右ボタン）。先に N5–N9 を考える。N1 はページが genuine に2宛先しか持たず *かつ* ジャンルのルーティング表が許可するときのみ。

---


## このファイルからの選び方

セクションを作るとき。

1. セクションの役割を特定する（ヒーロー／セクション見出し／フィーチャー／ CTA ／テスティモニアル／フッター／ナビゲーション）。
2. そのカテゴリの原型を一瞥する。
3. 「Use when」が要件に合う1つを選ぶ。
4. 同ページの2セクションが同じ原型を使っていないことを確かめる。
5. マクロ構造がデフォルトを示唆するなら（例 Bento Grid → F1 Bento）それを使う。示唆しないなら意図的に変化させる。

目的は構成された多様性。ページ内ではセクション同士が異なって感じ、ページを跨いでは前回と異なって感じる。

---


## モバイル畳み — 原型ごと

各原型に狭ビューポートでの畳み挙動が定義されている。知っておくべき2つのブレイクポイント。

- **60 rem（〜960 px）** — *レイアウト* ブレイクポイント。多カラム グリッドは単一カラムに畳まれる。傾きやクリップは落とす。固定ペインは固定を解く。
- **40 rem（〜640 px）** — *タイポグラフィ* ブレイクポイント。display サイズは1段縮める。サイド マージンのラベルはインラインへ。注釈は統合する。

60 rem 未満で原型はまだ自分自身であること — 同じ階層、同じトーン、同じリズム — ただし積み上げの単一カラム形で。40 rem 未満ではページは電話。スペースを贅沢品として扱う。

| 原型 | 60 rem 未満 | 40 rem 未満 |
| --- | --- | --- |
| **H1 Marquee** | 変化なし（タイポグラフィのみ、自然に中央寄せ／左寄せ） | display サイズを1段下げる（`xl` → `lg`）、サイド パディングを減らす |
| **H2 Split Diptych** | グリッド `1fr`（テキスト上、proof カラム下）、ディバイダーはヘアライン ルール | proof カラムは項目用の 2 カラム コンパクト グリッドに畳む |
| **H3 Quote-Led** | クォートは全幅、出典は別行に折り返す | クォート サイズを1段下げる、出典フォント サイズを1段下げる |
| **H4 Stat-Led** | 数字は全幅、テキストを下に積む、二次スタットは 2-up グリッドに | 数字サイズを1段下げる（`clamp` 床を持ち上げ）、修飾語テキストを折り返す |
| **H5 Letter** | 変化なし、単一カラム、aside があれば本文下へ、ディバイダーは上ボーダー | salutation サイズを1段下げる、signoff をタイトに |
| **H6 Photographic** | 画像は全幅のまま、キャプションは絶対位置の隅から画像の下のインラインへ | キャプション フォント サイズを1段下げる、電話で隅のキャプションをテキストに重ねない |
| **H7 Demo Video Clipped-Edge** | **クリップを落とす**、`1fr` 積み上げ、全幅メディア、傾きを外す（375 px でのクリッピングは壊れて読まれる） | メディアは 16/9 に縮小、poster 画像を使う（セルラーでの自動再生は敵対的） |
| **H8 Mockup Split** | 傾きを落とす、グリッド `1fr`、モックアップはテキスト下で全幅 | 注釈ピンを統合、番号付き凡例はモックアップの下へ |
| **H9 Custom Illustration** | グリッド `1fr`、イラストはテキストの下（またはトーン次第で上） | イラストはビューポート幅の ≤ 40 % にスケール、支配しない |
| **F1 Bento** | グリッドを 6/4-col から 2-col に、大タイルは 2 スパン、小タイルは 1 スパン | 1-col に落とす、タイル順は情報優先度を尊重 |
| **F2 Sticky-scroll stack** | 固定ペインの固定を解く、コンテンツはペアのテキスト＋ビジュアル ブロックの線形シーケンスに | ビジュアルはインラインの 16/9 に縮小、sticky 挙動はなくす |
| **F3 Tabular spec sheet** | カラムを減らす: 4-col → 2（key + value）、unit + footnote を落とす | スペック リストを縦に、各行は `dt` の上に `dd` |
| **F4 Step sequence** | 番号付けは左マージンからステップのインラインへ | ステップ コンテナをタイトに、コネクタ線を落とす |
| **F5 Annotated screenshot** | スクリーンショットは全幅、注釈は番号付きリストとして下に再積み上げ | スクリーンショット 16/9、注釈は凡例に統合 |
| **F6 Product card grid** | 3-up → 2-up | 2-up → 1-up、カード高は柔軟に |
| **C1 Outlined chip** | 変化なし（必要ならチップは複数行に折り返す） | 全幅単一チップ、min-height 44 px のヒット ターゲット |
| **C2 Inline form-as-CTA** | input + button を縦に積む、全幅 | ラベルを入力の上へ、ボタンは下で全幅 |
| **C3 Typographic link** | 変化なし（リンクは自然に折り返す） | 変化なし |
| **C4 Sticky bottom bar** | 変化なし（既に狭ビューポート向け設計）、44 px の min-height を確保 | 必要ならラベルを切る、CTA は右寄せのまま |
| **T1 Pull quote w/ marginalia** | marginalia をクォートの下へ、ディバイダーはヘアラインに | marginalia を1行に統合 |
| **T2 Logo wall** | 6-up → 3-up | 3-up → 2-up、ロゴ高を1段下げる（32 px → 24 px） |
| **T3 Single huge quote** | クォートは全幅のまま、出典は下に折り返す | クォート サイズを 1.4 倍で1段下げる |
| **T4 Numbered stat strip** | 4-up → 2-up | 縦になる、1スタット／行 |
| **Ft1 Mast-headed** | リンクが2行に折り返す、タグラインはワードマークの下 | ワードマーク サイズを1段下げる、タグラインを未だならイタリック化 |
| **Ft2 Inline single line** | リンクは複数行に折り返す、区切りはソフト リターンに | 縦リストになる |
| **Ft3 Index columns** | 4-col → 2-col | 2-col → 1-col、カラム見出しは残す |
| **Ft4 Dense colophon** | 変化なし（mono は自然に折り返す）、パディングを減らす | フォント サイズを1段下げる |
| **Ft5 Statement** | 文は全幅のまま、メタ行は積む | 文サイズを1段下げる（clamp 床を持ち上げ）、メタを折り返す |
| **Ft6 Letter close** | 変化なし、単一カラム、postscript は折り返す | signoff サイズを1段下げる、postscript を未だならイタリック化 |
| **Ft7 Newsletter-first** | input + button を縦に積む、全幅 | ラベルを入力の上へ、ボタンは下で全幅 |
| **Ft8 Marquee scroll** | 変化なし（既に狭ビューポート向け設計）、速度を約 25 % 下げる | 速度をさらに下げる、トラック高を1段下げる |
| **N1 Wordmark + 2 links** | 変化なし | 長ければリンクは2行目に折り返す、ワードマークはそのまま |
| **N2 Floating chip** | チップは浮遊のまま、パディングを減らす | 44 px のヒット ターゲットのためチップを広げる、280 px を下回らない |
| **N3 Side-rail** | レールの固定を解いてハンバーガー トリガーに上へ | ハンバーガーが唯一のナビ |
| **N4 ⌘K-only** | ⌘K を知らないユーザー用にハンバーガーが現れる | 変化なし（⌘K 相当は画面タップ） |
| **N5 Floating pill** | ピルはリンク リストを落とす、ワードマーク＋ CTA を残す、detached のまま | トップ アンカーのコーナー チップに — 左ワードマーク、右ハンバーガー |
| **N6 Newspaper masthead** | issue 行はワードマークの上に積む、ナビ リンクは2列目に折り返す | ワードマーク サイズを1段下げる、ナビ行は「menu」ディスクロージャーの後ろに畳む |
| **N7 Brutal slab** | リンクは2列目に折り返す、CTA は右寄せのまま | リンクはハンバーガーに畳む、ワードマーク＋ハンバーガーのみ |
| **N8 Terminal command** | 必要ならフラグは2つ目の `>` 行に折り返す、カーソルは末尾に | `> menu` というラベルの単一ハンバーガーになる、行末にカーソル可視 |
| **N9 Edge-aligned minimal** | 変化なし（既に余裕ある設計） | ワードマーク＋ CTA は端揃えのまま、CTA を 44 px ヒット ターゲットに pad |

**横断ルール:**

- 40 rem 未満では全ヒット ターゲット ≥ 44 × 44 px（WCAG AA）。下回らない。
- ページ コンテナの `padding-inline` ≥ `clamp(1rem, 4vw, 1.5rem)`、コンテンツが画面端にキスしないように。
- 40 rem 未満ではスクロール連動アニメーションを無効化する（モバイル スクロールは独自の物理を持つ。重ねたアニメーションはそれと戦う）。
- ファーストビュー以下の画像は常に `loading="lazy"`。**ただし LCP 要素にはビューポートを問わず使わない。**
- 自動再生動画は `data-saver`（`navigator.connection.saveData`）を尊重する。設定時は poster に置き換える。


