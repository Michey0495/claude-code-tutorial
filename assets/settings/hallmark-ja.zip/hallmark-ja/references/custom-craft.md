# カスタム制作 — ヒーローのアートワークを手で組み上げる

このファイルは、エンリッチメントのアーキタイプが構築を要求するときだけ読み込む（[`hero-enrichment.md`](hero-enrichment.md) の Tier A または B）。どの複雑度ティアでどの技法を選ぶか、そしてそれが上手に仕上がるとどう見えるかを示す。

**原則。** カスタムで組み上げたアートワークそのものがデザイン。ライブラリから拾ったアートワークはショートカットであり、目の利く観客は一発でそう読む。スキルの役目は、カスタム構築を最短路にすること。CSS だけで足りる場面、SVG が正解の場面、JS 駆動アニメーションがバンドルコストに見合う場面、そして（まれに）Three.js が正当化される場面を見極める。

2026 年の規範を作っているのは Lynn Fisher（*A Single Div*）、Diana Smith（*Pure CSS Francine* / *Lace*）、Rauno Freiberg、Paco Coursey、Jhey Tompkins、Adam Argyle。共通項は、制約駆動、手作り、パフォーマンスへの敬意、アクセシビリティを織り込む姿勢。プラットフォームを使え、戦うな。

---

## Tier A · ピュア CSS アート

**いつ使うか。** 幾何学的フォルム、グラデーション構成、グリフ風の装飾。バー、ドット、バッジ、アイコン、シンプルなパン、輪切りの球体、抽象ロゴ。形と色の組み合わせで成立するもの全般。

**労力:** 高い（`clip-path` と `conic-gradient` を使いこなすには訓練が要る）。
**見返り:** きわめて高い（0 バイト、ブラウザネイティブ、無限にスケール）。
**バンドルコスト:** ゼロ。

### CSS アートのツールキット（2026）

| 機能 | 用途 | ブラウザサポート |
| --- | --- | --- |
| `clip-path: polygon(…)` | 多角形（シェブロン、六角形、カスタムブロブ） | 96 %+ |
| `clip-path: path("M …")` | SVG パスを使った手描き風の曲線アウトライン | 88 %+（フォールバックは feature query で） |
| `conic-gradient()` | 円グラフのセグメント、放射状の区切り、マンダラ、回転するカラーホイール | 96 %+ |
| `radial-gradient()` | 球体、光点、サンバーストの中心 | 100 % |
| `linear-gradient()`（マルチストップ） | 重ねたストップによる複合形状 | 100 % |
| `mask-image: url(…)` | レイヤード透過、モーフィング、テキストクリップ | 95 %+ |
| `mix-blend-mode` | 構成上の奥行き（multiply、overlay、screen） | 95 %+ |
| `filter`（drop-shadow、blur、hue-rotate） | 不規則形状へのソフトシャドウ（アルファチャネル参照） | 100 % |
| `@property` | 滑らかに補間されるカスタムプロパティ（色、長さ、角度） | 88 %+ |
| `animation-timeline: scroll() / view()` | 宣言的なスクロール連動モーション、ハードウェアコンポジット | Baseline 2025（88 %） |

### 実例 — single div でパン一個

```html
<div class="loaf" aria-label="A loaf of bread"></div>
```

```css
@property --rise {
  syntax: "<length>";
  initial-value: 0px;
  inherits: false;
}

.loaf {
  width: 12rem;
  height: 7rem;
  background:
    /* crust ridges */
    radial-gradient(ellipse at 30% 70%, transparent 1.2rem, var(--color-ink-2) 1.21rem 1.3rem, transparent 1.31rem),
    radial-gradient(ellipse at 50% 70%, transparent 1.2rem, var(--color-ink-2) 1.21rem 1.3rem, transparent 1.31rem),
    radial-gradient(ellipse at 70% 70%, transparent 1.2rem, var(--color-ink-2) 1.21rem 1.3rem, transparent 1.31rem),
    /* loaf body */
    linear-gradient(180deg, oklch(78% 0.12 60), oklch(64% 0.16 50));
  border-radius: 50% 50% 14% 14% / 70% 70% 30% 30%;
  transform: translateY(var(--rise));
  animation: rise 6s ease-in-out infinite alternate;
  box-shadow: 0 1.2rem 1.5rem -0.8rem oklch(20% 0.02 60 / 0.18);
}

@keyframes rise {
  to { --rise: -4px; }   /* the breath: 4px over 6s, the loaf is alive */
}

@media (prefers-reduced-motion: reduce) {
  .loaf { animation: none; --rise: 0px; }
}
```

これでベーカリーのセンターピースが約 25 行、アセットなし、アニメーション付き、アクセシブル。次にハンドリングするベーカリー案件では、変動ノブ（リフト距離、パンの曲率、クラストの溝間隔、カラーストップ）が変わるので、別のパンになる。

### CSS アートのアンチパターン

- **スクロールのたびに `clip-path` を再計算する。** フレームレートが死ぬ。代わりに `transform` をアニメーションするか、`animation-timeline`（オフスレッドで合成）を使う。
- **過剰にネストしたラッパー div。** ピュア CSS のイラストは 1〜3 要素に収めるべき。8 重のラッパーは「構造化を放棄した」と読まれる。
- **reduced-motion 対応の欠落。** すべてのアニメーションに `@media (prefers-reduced-motion: reduce)` ブロックが必要。
- **乱れたグラデーションノイズ。** デザインではなく自動生成に見えるなら作り直す。単一グラデーションレイヤーで使うストップは最大 3 個まで。

---

## Tier B · 手組みの SVG イラスト

**いつ使うか。** CSS では綺麗に表現できない複雑なイラスト。キャラクター、関節のある人物、有機的なカーブ、複数要素のシーン。ベーカリーの店構え全景、スタジオのマスコット、7 本のラベル付きパスを持つワークフロー図など。

**労力:** 中程度（Figma で設計してエクスポートを整える）。
**見返り:** きわめて高い（無限にスケール、< 10 KB に圧縮、アニメーション可能）。
**バンドルコスト:** SVG のファイルサイズ — インラインで通常 4〜15 KB。

### パイプライン

1. **Figma で設計する。** コンポーネントシステム（制約、バリアント）を使う。パスはパスのまま — ラスタライズしない。レイヤーに名前をつける。エクスポートが尊重してくれる。
2. **SVG としてエクスポート。** Figma のエクスポートは悪くない。「Outline strokes」はストロークを fill としてアニメーションしたいときだけにする。それ以外はストロークのまま残す。
3. **[SVGOMG](https://jakearchibald.github.io/svgomg/) に通す** — Figma のメタデータ、不要な `<defs>`、冗長な transform を削除。30〜60 % のサイズ削減が普通。
4. **アニメーションさせるなら HTML にインライン化**、キャッシュさせたいなら `static.svg` として保存して `<img>` か CSS の `background-image` で参照。
5. **宣言的にアニメーション** — `<path d="">` 上の CSS キーフレーム（Chrome、Edge、Safari は `d` プロパティをサポート）、`@property` 駆動の属性補間、または [Motion](https://motion.dev) でオーケストレーションされたシーケンス。

### 手組み SVG と宣言的アニメーション

```html
<svg viewBox="0 0 200 100" class="loaf-svg" aria-label="A loaf of bread">
  <path class="loaf-body" d="M 20 70 Q 100 10 180 70 L 180 90 L 20 90 Z" />
  <path class="loaf-score" d="M 60 50 L 90 30 M 100 45 L 130 25 M 140 50 L 165 35" />
</svg>
```

```css
@property --bake {
  syntax: "<percentage>";
  initial-value: 0%;
  inherits: false;
}

.loaf-body {
  fill: oklch(72% 0.14 50);
  filter: drop-shadow(0 4px 8px oklch(20% 0.02 60 / 0.16));
  transform-origin: 100px 90px;
  animation: bake 6s ease-in-out infinite alternate;
}

.loaf-score {
  stroke: oklch(38% 0.1 35);
  stroke-width: 2;
  stroke-linecap: round;
  fill: none;
  stroke-dasharray: 0 200;
  animation: score 1.6s 0.8s var(--ease-out) forwards;
}

@keyframes bake  { to { transform: scaleY(calc(1 + var(--bake) * 0.005)); --bake: 1%; } }
@keyframes score { to { stroke-dasharray: 200 200; } }

@media (prefers-reduced-motion: reduce) {
  .loaf-body, .loaf-score { animation: none; }
  .loaf-score { stroke-dasharray: 200 200; }
}
```

呼吸は `@property --bake` がパーセンテージを補間して生み出す。スコアマークはロード時に一度、`stroke-dasharray` で自分自身を描く。JS なし、CSS 18 行、reduced-motion セーフ。

### 2026 における SVG アニメーション選択肢

| 手法 | 適する場面 | 評価 |
| --- | --- | --- |
| **`<path d>` への CSS キーフレーム** | アンカー数が一致する形状同士のパスモーフィング | これを使う。CSS の他要素と組み合わせ可能、GPU フレンドリー。 |
| **`@property` + アニメーション付き CSS 変数** | 色、長さ、角度、パーセンテージの滑らかな補間 | これを使う。宣言的で予測可能。 |
| **`transform` / `opacity` への CSS キーフレーム** | 位置、回転、フェード | 常に。ハードウェアアクセラレーション、レイアウトスラッシング無し。 |
| **`stroke-dasharray` ドローオン** | 自ら描かれていく手描き風ライン | あり。安価で効果的。 |
| **SMIL `<animate>`** | レガシーな SVG 専用属性アニメーション | 2026 でも受け入れ可能だが優先度を下げる — CSS は組み合わせ可能、SMIL はそうでない。CSS で表現できないときのみ。 |
| **Motion / GSAP 経由の JS** | マルチ要素のオーケストレーション入場、スクロールスクラブ、複雑なタイムライン | CSS で足りないとき。下の Tier C を参照。 |

### 手組み SVG のアンチパターン

- **Figma の生エクスポートをそのまま出荷。** 必ず SVGOMG を通す。手付かずのエクスポートには数百バイトのメタデータ、未使用 `<defs>`、二重の transform が乗っている。
- **300 KB の SVG。** 30 KB を超えたら怪しい。よく組まれたイラストは 4〜15 KB に収まる。100 KB+ ならラスター画像が隠れているか、何千もの不要なパスコマンドがある。
- **`viewBox` のゴミ。** アイコンに `viewBox="0 0 24 24"`、ヒーローイラストに `viewBox="0 0 1920 1080"`。ボックスはデザインの境界に揃える。パディングや余分なスペースは入れない。
- **何でも linear イージング。** ease-out を足す（小数点 2 桁の cubic-bezier 指定）。「動いている」と「生きている」の差はそこで生まれる。
- **アンカー数が違う形状間のパスモーフィング。** ブラウザは補間するが、結果はガタつく。アンカー数を合わせるか、`clip-path` を使う。

---

## Tier C · 宣言的アニメーション（CSS ファースト、JS は必要なときだけ）

2026 年の宣言的アニメーションの規範。プラットフォームを先に使え。JS に手を伸ばすのは、プラットフォームではオーケストレーションを表現できないときだけ。

### CSS キーフレーム + `@property`

`@property`（Baseline 2024、2026 年時点でおよそ 88 % サポート）は型付きカスタムプロパティ — `<color>`、`<length>`、`<angle>`、`<number>`、`<percentage>` — を定義でき、ブラウザはそれを滑らかに補間できる。`@property` なしでカスタムプロパティをアニメーションすると、中間値なしで開始値から終了値へステップする。

```css
@property --hue {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: false;
}

@keyframes spin-hue { to { --hue: 360deg; } }

.gradient-loop {
  background: conic-gradient(from var(--hue),
    oklch(70% 0.2 var(--hue)),
    oklch(70% 0.2 calc(var(--hue) + 120deg)),
    oklch(70% 0.2 calc(var(--hue) + 240deg)));
  animation: spin-hue 8s linear infinite;
}
```

これで滑らかに色相回転する conic グラデーション。JS なし、ライブラリなし、GPU コンポジット。

### スクロール駆動アニメーション

`animation-timeline: scroll()` と `view()` は **2025 年 10 月に Baseline** 到達。Chromium、Edge、Safari Tech Preview で本番投入可能、Firefox はフラグ越し。ルールはプログレッシブエンハンスメント。

```css
@supports (animation-timeline: view()) {
  .reveal {
    animation: fade-up linear both;
    animation-timeline: view();
    animation-range: entry 0% cover 30%;
  }
}

@keyframes fade-up {
  from { opacity: 0; transform: translateY(24px); }
  to   { opacity: 1; transform: translateY(0); }
}
```

ブラウザが対応していれば、ビューポートに入る瞬間に要素がアニメーションする。対応していなければ、要素はそこにあるだけ — JavaScript なし、ライブラリなし、IntersectionObserver なし。CSS Scroll-Driven Animations コミュニティが正典: [scroll-driven-animations.style](https://scroll-driven-animations.style/)。

### View Transitions API

2026 年時点で本番投入可能（同一ドキュメントは 2025 年 10 月 Baseline、クロスドキュメントは Chromium 126+、Safari 18.2+）。Hallmark のランディングページはテーマ切り替えで既に使用中:

```js
function applyTheme(theme) {
  const apply = () => { /* mutate the DOM */ };
  if (!reduced && document.startViewTransition) {
    document.startViewTransition(apply);
  } else {
    apply();
  }
}
```

ブラウザがクロスフェードを担う。状態変更にアニメーションライブラリは要らない。

### Motion / GSAP など — それぞれがバンドルコストに見合うとき

| ライブラリ | 適する場面 | バンドル | 評価 |
| --- | --- | --- | --- |
| **[Motion](https://motion.dev)**（`motion/react`、`motion`） | React でオーケストレーションされたマルチ要素の入場（variants、`AnimatePresence`、viewport hooks）。2026 年における React ヒーローのデフォルト。 | 4 KB ベース + 2 KB React = 6 KB。Web Animations API ベース。 | React で最初に手を伸ばす先。 |
| **[GSAP](https://gsap.com)**（Webflow との提携以降は無償） | 野心的なタイムライン、スクロールスクラブ、不一致なアンカーをまたぐ SVG パスモーフィング。20+ 要素のヒーローシーケンス、多段のナラティブ。 | コア約 50 KB、プラグイン入りで 100 KB+（ScrollTrigger、Draggable）。 | タイムラインが核なら価値がある。フェードインだけならオーバーキル。 |
| **AutoAnimate** | React の些細なレイアウト遷移（リストの並び替え、要素の出現）。 | 2 KB。 | 役割相応。 |
| **Anime.js v4** | 軽量なスタッガー、シンプルなアニメーション、vanilla JS。 | 約 15 KB。 | 許容可能。2026 では Motion ほど一般的ではない。 |
| **Theatre.js** | オーケストレーション向けのビジュアルエディタ + コード API。ニッチだが強力。 | 重い（80 KB+）。 | シングルページのインタラクティブアートのみ。 |

**判断ルール:**

```
単一要素、シンプルなモーション           → CSS キーフレーム / @property
複数要素、オーケストレーション入場         → Motion (React) または GSAP (vanilla / 複雑)
スクロール進捗連動                     → animation-timeline (CSS) — 複雑なら GSAP ScrollTrigger
2 つのレイアウト間の状態変更             → View Transitions API
React のリスト並び替え                 → AutoAnimate
スクラブ付きの複雑なヒーロー演出         → GSAP timeline + ScrollTrigger
```

単発のフェードインに Motion（4 KB を無のために）はバンドル肥大化のシグナル。リスト並び替えに GSAP（50 KB を無のために）は同じシグナルがさらに大きく出ている。

### 宣言的アニメーションのアンチパターン

- **`width`、`height`、`top`、`left`、`margin`、`padding` をアニメーション**（レイアウトスラッシングを起こす）。アニメーションは `transform` と `opacity` だけ — GPU 上で合成される。
- **UI に linear イージング**（繊細さがない、「チュートリアルのデモ」と読まれる）。
- **ヒーロー入場の弾むエラスティック**（`cubic-bezier(0.34, 1.56, …)` 系） — ドラッグリリースのような物理的インタラクションのために取っておく。
- **フェードイン 1 個のために Motion や GSAP を import。** `transition: opacity 400ms var(--ease-out)` が 0 バイトでやってくれることに 50 KB。
- **スクロールフェード全部のせ。** 全セクションがスクロールでフェードイン。ページが落ち着かない。ファーストロード時に 1 つだけオーケストレーションされた入場を選び、他はそこに「ある」状態にする。
- **`prefers-reduced-motion` フォールバックなしのリビールアニメーション。** すべての transform / animation をガードする。

---

## Tier D · Three.js / WebGL / シェーダー

**正当化される場面。** 3D がヒーローの価値そのものであるとき — ユーザーが触れる回転プロダクト、インタラクティブな 3D プレイグラウンド、ジェネラティブアート。Apple のプロダクトページのインタラクティブなボトル / iPhone、Bruno Simon のポートフォリオ、Vercel の WebGL ヒーローギャラリーなど。

**正当化されない場面。** ユーザーが触れない静的に回るだけのもの。「高級感」を狙った blooming 過剰なシェーダー背景。マーケティングページで eager に読み込まれる 5 MB モデル。

**パフォーマンス予算。**
- < 100 ドローコール
- JS + アセット合計 < 2 MB
- ロード時間 < 6 秒
- ミドルレンジモバイルで 60 fps を目標

**スタック。**
- React Three Fiber（R3F）— React 案件用、エルゴノミック、Three.js に約 30 KB 追加
- それ以外は Vanilla [Three.js](https://threejs.org)（機能次第で約 100〜300 KB）
- モデル: Draco 圧縮付き glTF 2.0（20〜50 % のサイズ削減）
- テクスチャ: KTX2 / Basis（PNG/JPEG よりはるかに小さい）

**必ず WebGL なしのフォールバックを用意する。** canvas が初期化に失敗（WebGL2 なし、GPU ブラックリスト、低電力モード）してもページが描画されるよう、静的ポスター画像を表示する。

### Three.js / WebGL のアンチパターン

- **静止プロダクトに Three.js。** インタラクションなし = 正当化なし。SVG か写真静止画を使う。
- **Bloom + glow 過剰摂取。** 3〜4 段のポストプロセス処理ですべてをぼやけさせるだけ。1 つだけ選び、「ギリギリ見える」まで弱める。
- **5 MB モデルの eager ロード。** ジオメトリは必ず遅延読み込み。ストリーミング中はポスターを表示。
- **フォールバック無し。** WebGL は約 5 % のデバイスで失敗する。そこで使えないならアクセシビリティ失格。
- **汎用の手続き的ノイズシェーダー。** ネット上の他の Three.js デモと同じに見える。カスタムシェーダーは居場所を勝ち取れるが、既製の Perlin ノイズはまず無理。

---

## Tier E · 生成された静止画（Nanobanana / Recraft V4 / Midjourney）

キャラクターや特定のシーンが必要で、手組みが経済的に見合わないとき（5 ポーズの小さなマスコットを要する要件、雰囲気のある静止画を要するエージェンシー案件など）。

| モデル | コスト | 適する用途 | 出力 |
| --- | --- | --- | --- |
| **[Nanobanana 2 / Gemini 2.5 Flash Image](https://ai.google.dev/gemini-api/docs/image-generation)** | $0.039 / 枚 | 複数パネルでのキャラクター一貫性、高速イテレーション、リファレンス画像によるブランドスタイル準拠、テキスト付きインフォグラフィック | PNG（透過対応）。SVG なし、アニメーションなし |
| **[Recraft V4](https://www.recraft.ai/)** | 約 $0.04 / 枚 | **本番投入可能な SVG 出力を持つ唯一のメインストリームモデル。** コードで生きてスケールが必要なロゴ、アイコン、イラスト。 | SVG + PNG |
| **[Midjourney v8](https://www.midjourney.com)** | 約 $0.14 / 枚 | 美的な美しさ、アートディレクション、雰囲気のある静止画 | PNG |
| **[Flux 2](https://blackforestlabs.ai/)** | 約 $0.03 / 枚 | フォトリアリズム、肌 / 布地 / プロダクトのディテール | PNG |

### 生成時の規律

- **必ずポストプロセスする。** グレイン、非対称クロップ、手描き風オーバーレイ、カラーグレーディング。モデルの生出力は 100 % AI と読まれる。ポストプロセスこそが自分のものにする工程。
- **ブランド一貫性のためにリファレンス画像を使う。** Nanobanana のキャラクター一貫性機能が Midjourney との差別化ポイント。既存のブランドアセットを与えて、生成物をスタイルから外さない。
- **マクロ構造コメントにモデルを刻印**（`generated: nanobanana-2 · post-processed`）。将来の監査で出自を辿る必要がある。
- **SynthID ウォーターマークの存在を確認**（Google の不可視 AI 由来マーカー）。
- **マルチフレームアニメーションはどのモデルもサポートしていない。** キーフレームを Lottie ループに組み立てようとしない — それは Tier F の領域で、単一の静止画より悪い結果になることがほとんど。

### 生成静止画のアンチパターン

- **対称構図。** アルゴリズム的で、AI と読まれる。非対称にクロップする。
- **滑らかなメッシュブロブの顔。** 2024 年の「汎用 AI キャラクター」ルック。ここを越えられないならキャラクター主体の静止画は避ける。または Nanobanana のキャラクター一貫性機能をリファレンス画像とともに使い、非対称性と不完全さを強くプロンプトに指定。
- **デフォルト照明 + 青みがかった背景。** AI 的サイン。プロンプトでブランド由来の色と変わった照明を指定する。
- **指 6 本、家具の重複、ありえない部屋。** 2023 年より減ったがまだ潜む。常に検品。

---

## Tier F · ライブラリイラスト + Lottie（最終手段）

予算とタイムラインでショートカットが避けられないとき。カタログは [`assets.md`](assets.md) — Storyset、Humaaans、unDraw、IRA Design、LottieFiles。このティアでも:

- **カスタマイズする。** ブランドアンカー色にカラースワップ。クロップや再構成。改変なしのライブラリ然としたものは出さない。
- **おなじみのポーズを避ける。** 「ノートパソコンの男性とフローティング吹き出し」はどのチームも 100 回見た。「ストックイラストっぽさ」が出るものは負け。

### Lottie 単体について — 最終手段

**Lottie を使うのは:**
- モーションがキャラクターの関節を伴う（5 フレームのマスコットの手を振る、多関節の歩行サイクル）かつ CSS / SVG では現実的に表現できない
- ブランドに合わせてカスタム発注した Lottie がある
- ファイルが < 2 MB
- 一時停止 / 再開のサポートを実装済み
- `prefers-reduced-motion` のフォールバックが静止キーフレーム

**Lottie を使ってはいけないのは:**
- 回転するロゴループ — CSS の `@keyframes rotate` を使う
- チェックマークが描かれていく確認 — SVG の `stroke-dasharray` を使う
- ロードスピナー — CSS の conic-gradient + rotate を使う
- ホバーマイクロインタラクション — CSS トランジションを使う
- 手組み可能なヒーローセンターピース — Tier A か B を使う

2026 年版 Lottie Tell は、ピュア CSS の方が強くて軽く作れるところで LottieFiles から拾ってきたもの。監査動詞コマンドが検出する。

---

## ベーカリー実例の通し

**要件:** 「リスボンの小さなパン屋のランディングページを作って」

**ステップ 2（マクロ構造）:** Long Document — ベーカリーはストーリー主導のブランドで、SaaS プロダクトではない。
**ステップ 3（テーマ）:** Linen — 温かい紙、散文主導、親密。
**ステップ 4（エンリッチメント）:** E5 カスタムイラストセンターピース。Tier B（手組み SVG）。

**出力:**

60 行の SVG で 1 個のパン、3 つのパス（クラスト + クラム + スコアマーク）、見出しの右側 40 % のカラム幅に配置。アニメーション: `@property --rise` が 6 秒で 4 px の垂直リフトを補間、ease-in-out、alternate。スコアマークは初回ペイント時に `stroke-dasharray` で自ら描かれる。reduced-motion: 静止したパン、アニメーションなし。

```css
/* Hallmark · macrostructure: Long Document
 * H5 hero: Letter (intimate salutation + 2-paragraph body)
 * enrichment: E5 Custom Illustration · craft: tier-B SVG (60 lines)
 * animation: @property --rise (6s, alternate) + stroke-dasharray draw-on
 * theme: Linen · accent: warm-amber ~3% · studied: no
 */
```

次にハンドリングするベーカリー案件では別のパンが出る — 違う曲率、違うリフト距離、違うスコアパターン、もしかしたら違うイラスト自体（サワードゥブール対バゲット対フラットブレッド）。[`hero-enrichment.md`](hero-enrichment.md) の変動ノブがそれを保証する。

---

## レシピライブラリ

上のベーカリーのパンが実例の一つ。ここではあと 4 つカタログ化する。各レシピは Tier A か Tier B で完結する、コピペ可能な小さなレシピ。要件が当該被写体を指す場合に使うか、そうでなければ*技法リファレンス*として扱う（ワークフロー図の `stroke-dashoffset` フローは再利用可、マスコットの瞬きループも再利用可、など）。

各レシピには次がついている: 1 行説明、フルコード、「使う場面 / 避ける場面」のメモ、`prefers-reduced-motion` フォールバックブロック、現実世界のインスピレーション源。

### レシピ 1 · ワークフロー / プロセス図

3 つのラベル付きボックスを曲線矢印でつなぐ。手描き感のためボックス 1 に -1°、ボックス 3 に +0.5° の非対称回転。1 本の矢印にデータの流れを示唆する `stroke-dashoffset` アニメーション。用途: データフロー、デシジョンツリー、ユーザージャーニーのステップを示す機能ページ。

```html
<svg class="flow" viewBox="0 0 720 200" role="img" aria-label="Data flow: input, process, output">
  <defs>
    <marker id="flow-arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto">
      <path d="M0,0 L8,3 L0,6" fill="currentColor" />
    </marker>
  </defs>

  <g class="flow__step flow__step--a">
    <rect class="flow__box" x="20"  y="55" width="160" height="90" rx="0" />
    <text class="flow__label" x="100" y="105" text-anchor="middle">Input</text>
  </g>

  <path class="flow__arrow flow__arrow--live" d="M 180 100 Q 220 80 260 100" marker-end="url(#flow-arrow)" />

  <g class="flow__step">
    <rect class="flow__box" x="260" y="55" width="200" height="90" rx="0" />
    <text class="flow__label" x="360" y="100" text-anchor="middle">Parse + Filter</text>
    <text class="flow__sub"   x="360" y="118" text-anchor="middle">small predicate language</text>
  </g>

  <path class="flow__arrow" d="M 460 100 Q 500 120 540 100" marker-end="url(#flow-arrow)" />

  <g class="flow__step flow__step--c">
    <rect class="flow__box" x="540" y="55" width="160" height="90" rx="0" />
    <text class="flow__label" x="620" y="105" text-anchor="middle">Output</text>
  </g>
</svg>
```

```css
@property --flow-dash {
  syntax: "<length>";
  initial-value: 0px;
  inherits: false;
}

.flow { width: 100%; max-width: 48rem; height: auto; display: block; margin: 0 auto; color: var(--color-ink); }
.flow__box   { fill: none; stroke: currentColor; stroke-width: 1.5; }
.flow__label { font-family: var(--font-display); font-size: 16px; fill: var(--color-ink); }
.flow__sub   { font-family: var(--font-mono); font-size: 11px; fill: var(--color-muted); }
.flow__step--a { transform: rotate(-1deg); transform-origin: 100px 100px; }
.flow__step--c { transform: rotate(0.5deg); transform-origin: 620px 100px; }
.flow__arrow { fill: none; stroke: var(--color-muted); stroke-width: 1.5; stroke-linecap: round; }
.flow__arrow--live {
  stroke: var(--color-accent);
  stroke-dasharray: 6 6;
  animation: flow 2.4s linear infinite;
}
@keyframes flow { to { stroke-dashoffset: -24; } }

@media (prefers-reduced-motion: reduce) {
  .flow__arrow--live { animation: none; stroke-dasharray: 0; }
}
```

**使う場面**: 要件が「ユーザーにデータの流れを見せる」 — 機能ページ、docs ランディング、技術ナラティブのセクション。**避ける場面**: ノードが 5 個を超える（Mermaid か実グラフレイアウトを使う）、関係が非線形（このレシピは左→右の流れを想定）。

*インスピレーション:* Lynn Fisher の `lynnandtonic.com` の `<rect>` 回転実験、Rauno Freiberg の `stroke-dashoffset` フロー（rauno.me）。

### レシピ 2 · ミニマルライン・マスコット

小さな SVG キャラクター — 顔のみ、約 120 × 120 px — 不気味の谷リスクなく個性を出す。楕円の目 2 個（`@keyframes blink` の 3 秒ループ）、2 次曲線の口 1 本、ステムアクセント 2 本（髪 / 帽子 / 角 / 触覚）。テキストの脇に並べる。

```html
<figure class="mascot" aria-label="The Hallmark mascot — a face with two eyes and a small smile">
  <svg viewBox="0 0 120 130" class="mascot__svg">
    <circle class="mascot__head" cx="60" cy="60" r="42" />

    <ellipse class="mascot__eye mascot__eye--l" cx="46" cy="56" rx="4" ry="6" />
    <ellipse class="mascot__eye mascot__eye--r" cx="74" cy="56" rx="4" ry="6" />

    <path class="mascot__mouth" d="M 50 76 Q 60 84 70 76" />

    <path class="mascot__accent" d="M 32 22 Q 40 12 52 18" />
    <path class="mascot__accent" d="M 88 22 Q 80 12 68 18" />
  </svg>
</figure>
```

```css
.mascot { display: inline-block; width: 80px; height: 86px; margin: 0; vertical-align: -8px; }
.mascot__svg { width: 100%; height: 100%; color: var(--color-ink); }
.mascot__head { fill: color-mix(in oklch, var(--color-paper-2) 100%, var(--color-accent) 6%); stroke: var(--color-ink); stroke-width: 2; }
.mascot__eye  { fill: var(--color-ink); animation: blink 5s ease-in-out infinite; }
.mascot__eye--r { animation-delay: 80ms; }   /* one eye lags slightly — feels organic */
@keyframes blink {
  0%, 8%, 92%, 100% { ry: 6px; }
  12%, 14%          { ry: 0.8px; }
}
.mascot__mouth { fill: none; stroke: var(--color-ink); stroke-width: 1.6; stroke-linecap: round; }
.mascot__accent { fill: none; stroke: var(--color-accent); stroke-width: 1.2; opacity: 0.6; stroke-linecap: round; }

@media (hover: hover) and (pointer: fine) {
  .mascot:hover .mascot__head { fill: color-mix(in oklch, var(--color-paper-2) 100%, var(--color-accent) 12%); transition: fill 240ms cubic-bezier(0.16, 1, 0.3, 1); }
}

@media (prefers-reduced-motion: reduce) {
  .mascot__eye { animation: none; }
}
```

**使う場面**: 小さなプロダクト / スタジオ / インディーブランドが、生成キャラクターの不気味の谷リスクなしに個性を欲しているとき。**避ける場面**: 多くの状態にわたる表情豊かなマスコットが必要なとき（その場合は Rive を使う — @property ルートはシンプルなループ用で、関節のある感情表現には不向き）。

*インスピレーション:* Are.na の還元的なサイトマーク、Mailchimp の Freddie ファミリー（単色の自信）、Diana Smith の CSS アート肖像の制約。

### レシピ 3 · 3 ティアのアーキテクチャ図

Browser → API → Database、約 16/9 で 3 つのラベル付きボックスを描き、`@property --flow-offset` を使った `stroke-dasharray` フローライン。データフローラインがパルスしてライブトラフィックを示唆。用途: スタック内での自プロダクトの位置を示す開発者ツールのランディング。

```html
<svg class="arch" viewBox="0 0 320 180" role="img" aria-label="Three-tier architecture: browser, API, database">
  <g class="arch__tier">
    <rect x="14"  y="50" width="76" height="80" />
    <text x="52"  y="86" text-anchor="middle" class="arch__name">Browser</text>
    <text x="52"  y="104" text-anchor="middle" class="arch__sub">React / Next</text>
  </g>

  <line class="arch__flow" x1="90"  y1="90" x2="120" y2="90" />
  <text class="arch__hop"  x="105"  y="80" text-anchor="middle">HTTPS · OTLP</text>

  <g class="arch__tier arch__tier--mid">
    <rect x="120" y="50" width="80" height="80" />
    <text x="160" y="86" text-anchor="middle" class="arch__name">API</text>
    <text x="160" y="104" text-anchor="middle" class="arch__sub">Edge runtime</text>
  </g>

  <line class="arch__flow arch__flow--reverse" x1="200" y1="90" x2="230" y2="90" />
  <text class="arch__hop"  x="215"  y="80" text-anchor="middle">SQL · gRPC</text>

  <g class="arch__tier">
    <rect x="230" y="50" width="76" height="80" />
    <text x="268" y="86" text-anchor="middle" class="arch__name">Database</text>
    <text x="268" y="104" text-anchor="middle" class="arch__sub">Postgres + vec</text>
  </g>
</svg>
```

```css
@property --flow-offset {
  syntax: "<number>";
  initial-value: 0;
  inherits: false;
}

.arch { width: 100%; max-width: 48rem; height: auto; color: var(--color-ink); display: block; margin: 0 auto; }

.arch__tier rect {
  fill: var(--color-paper-2);
  stroke: var(--color-ink);
  stroke-width: 1.5;
}
.arch__tier--mid rect {
  fill: color-mix(in oklch, var(--color-paper-2) 100%, var(--color-accent) 8%);
  stroke: color-mix(in oklch, var(--color-accent) 60%, var(--color-ink));
}

.arch__name { font-family: var(--font-display); font-size: 11px; font-weight: 500; fill: var(--color-ink); }
.arch__sub  { font-family: var(--font-mono);    font-size: 8px;  fill: var(--color-muted); }
.arch__hop  { font-family: var(--font-mono);    font-size: 7px;  fill: var(--color-muted); letter-spacing: 0.04em; }

.arch__flow {
  stroke: var(--color-accent);
  stroke-width: 1.4;
  stroke-linecap: round;
  stroke-dasharray: 4 4;
  animation: arch-flow 1.6s linear infinite;
}
.arch__flow--reverse { animation-direction: reverse; }
@keyframes arch-flow { to { stroke-dashoffset: -8; } }

@media (prefers-reduced-motion: reduce) {
  .arch__flow { animation: none; stroke-dasharray: 0; }
}
```

**使う場面**: スタック内の位置を示す必要がある開発者向けプロダクト — 可観測性ツール、エッジファンクション、ORM、取り込みサービス。**避ける場面**: アーキテクチャが 5 ティアを超える、またはトポロジが非線形（このレシピは「3 ボックスのフロー」モデル限定。グラフ的トポロジには本物の図ツールを使い、SVG エクスポートを埋め込む）。

*インスピレーション:* Vercel のネットワーク / エッジ図、Diana Smith のジオメトリ配置における構造的精度。

### レシピ 4 · 植物の葉あしらい

小さな（約 40 × 80 px）手描き風の小枝、+25° と -30° で回転した非対称な葉 2 枚。葉脈は不透明度 0.6。見出しの脇にインラインアクセントとして置ける。ピュア SVG、デフォルトではアニメーションなし（静けさそのものがデザイン）。

```html
<svg class="sprig" viewBox="0 0 40 80" aria-hidden="true">
  <path class="sprig__stem" d="M 20 76 Q 18 56 21 36 Q 22 22 20 8" />

  <g transform="translate(8 38) rotate(-25)">
    <ellipse class="sprig__leaf"  cx="0" cy="0" rx="6" ry="11" />
    <path     class="sprig__vein" d="M 0 -10 Q 1 0 0 10" />
  </g>

  <g transform="translate(28 52) rotate(30)">
    <ellipse class="sprig__leaf"  cx="0" cy="0" rx="6" ry="11" />
    <path     class="sprig__vein" d="M 0 -10 Q -1 0 0 10" />
  </g>

  <path class="sprig__stem" d="M 20 22 Q 16 19 13 22" />
</svg>
```

```css
.sprig {
  width: 32px;
  height: 64px;
  display: inline-block;
  vertical-align: -0.6em;
  margin-inline-end: 0.4em;
  color: var(--color-accent);
}

.sprig__stem  { fill: none; stroke: currentColor; stroke-width: 1.4; stroke-linecap: round; }
.sprig__leaf  { fill: none; stroke: currentColor; stroke-width: 1.4; }
.sprig__vein  { fill: none; stroke: currentColor; stroke-width: 0.9; opacity: 0.6; stroke-linecap: round; }

/* Use beside a headline */
h1.has-flourish { display: flex; align-items: baseline; gap: 0.4em; }
```

**使う場面**: 要件がベーカリー、レストラン、カフェ、ブティック、ハーバリスト、フローリスト、アトリエ — 手描き的な「丁寧さ」のシグナルがブランドに合うもの。**避ける場面**: ブランドが技術的、ブルータリスト、静かに簡素なとき（小枝は抑制を望むページに温かみを加えてしまう）。

*インスピレーション:* 昔の大判新聞の手描き植物素材、リスボンと東京のレストランメニュー、Lynn Fisher の制約駆動のシンプルさ（このレシピは clip-path をもっと巧みに使えば *A Single Div* で書けたが、SVG の方が小さいスケールで判読性が高い）。

---

### レシピ横断の技法

4 つのレシピが共有するもの — 2026 年における手組み CSS / SVG イラストの 4 つの習慣:

1. **宣言的補間のための `@property`。** 型付きカスタムプロパティ（`<length>`、`<number>`、`<angle>`、`<color>`）をアニメーションすると、JS ゼロで GPU 合成アニメーションになる。ベーカリーのパン、ワークフローのフローライン、アーキテクチャのデータフロー、マスコットの瞬き — すべて使っている。
2. **手描き感のための非対称な `transform: rotate()`。** ワークフローのボックスは ±1°、マスコットの目には 80 ms のディレイ差、小枝の葉は +25° / -30°。対称はアルゴリズム的に読まれ、制御された非対称は描かれたものとして読まれる。
3. **鉛筆 / 副次的ディテールのための不透明度レイヤリング。** ワークフローの戻り矢印は `var(--color-muted)`、アーキテクチャのサブラベルは 60 % 不透明、小枝の葉脈は 0.6 不透明。不透明度の階層は注意の階層。
4. **装飾を機能に接地するモノラベル。** アーキテクチャ図の `arch__sub` テキストは 8 px の `var(--font-mono)`。ワークフローの「small predicate language」もモノ。装飾は判読性と正確性で居場所を勝ち取り、モノはそれを示す。

これらのレシピは合うときはそのまま、要件が違うときは技法だけ抜いて使う。要点は、*Hallmark ページのすべてのイラストは組み上げるものであり、拾ってくるものではない*ということ。

- **CSS で済むのに Lottie に手を伸ばす。** 新しいシグナル。パンはピュア CSS か手組み SVG で作る。Lottie はコストのかかるショートカット。
- **フェードイン 1 個のために 50 KB の GSAP を import。** `transition: opacity 400ms var(--ease-out)` を使う。0 バイト。
- **「滑らかなリサイズ」のために `width` や `height` をアニメーション。** レイアウトをリフローする。`transform: scale(...)` と `transform-origin` を使う。
- **非インタラクティブな回転に Three.js。** インタラクションなし = 正当化なし。`transform: rotate()` でアニメーションする SVG を使う。
- **未調整の Figma エクスポート。** 必ず SVGOMG を通す。
- **未加工で出荷した生成ラスター。** ポストプロセスする。グレイン、クロップ、カラーグレード。生出力は AI と読まれる。
- **Linear イージング。** 最低限 ease-out を足す。「動いている」と「生きている」の差。
