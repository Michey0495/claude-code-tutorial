# ヒーローエンリッチメント — いつ、何を、どれくらい

このファイルはマクロ構造のピック（デザインフローの Step 3）の後、Step 4「ヒーローエンリッチメントを決める」に到達したときに読み込まれる。そもそもヒーローをメディアでエンリッチするのか、するならどのアーキタイプか、どう組み上げるかを示す。

**約束。** エンリッチメントはオプションであって、デフォルトではない。タイポグラフィのみのヒーローは*常に*受け入れ可能な答え。ビジュアルエンリッチメント — デモ動画、イラスト、モックアップ、アニメーションループ、抽象背景、写真 — は*居場所を勝ち取らなければならない*。ヒーローからエンリッチメントを削除しても機能するなら、エンリッチメントは居場所を勝ち取った。エンリッチメントなしでヒーローが崩れるなら、弱いタイポグラフィを松葉杖で支えていたということ。

**基準。** 悪い何かよりは何もない方がいい。静かでよく組まれたタイポグラフィのみのヒーローを出すページは、ストックイラスト・Lottie チェックマーク・オーロラブロブ背景・汎用センター動画ブロックを出すページより常にいい。

---

## 画像必要性の検出 — そもそも要件にビジュアル素材が必要か

エンリッチメントティアを選ぶ前に、要件が実際にビジュアル素材を欲しているかを判断する。デフォルトは**タイポグラフィのみ**。要件をこの表に照合し、*最初に*ヒットした行で動く:

| 要件のシグナル（次の語 / 意図のいずれか） | 画像戦略 |
| --- | --- |
| e-commerce、shop、store、product catalogue、brand、fashion、lookbook | 実プロダクト写真必須 — ユーザーが提供するまでプレースホルダ |
| photography、portfolio、gallery、artist | ビジュアル素材*そのものが*ページ — ユーザー提供までプレースホルダ |
| food、restaurant、menu、dish、coffee、wine、recipe | ヒーロー写真 + プロダクトクロップ — ユーザー提供までプレースホルダ |
| team、staff、「about us」、portraits、hiring、careers | ポートレートクロップ — ユーザー提供までプレースホルダ |
| travel、hotel、destination、real estate、listing、property | カバー写真 + タイル写真 — ユーザー提供までプレースホルダ |
| news、blog、magazine、journal、publication | 記事ごとの特集画像 — ユーザー提供までプレースホルダ |
| SaaS landing、manifesto、agency、studio、atmospheric、slow-and-editorial | **キット主導。** Hallmark imagery kit（ウォッシュ、透過の抽象、装飾）を使う — [`assets.md` § Placeholder strategy](assets.md) と [`imagery-kit.md`](imagery-kit.md) 参照。 |
| API、docs、changelog、CLI、library、dev-tool、SDK、package | **ビジュアル素材なし。** タイポグラフィのみ。必要ならコードブロック。 |
| editorial、essay、letter、foundry、type-specimen、broadside | **ビジュアル素材なし。** ディスプレイタイポグラフィがデザイン。 |
| （その他 / 曖昧 / 未指定） | **デフォルト: タイポグラフィのみ。** 迷ったら画像なし。 |

ルール:

- ユーザーが画像アセットを添付している（または `.hallmark/preflight.json` がキャッシュしている）なら、それを使う。プレースホルダで上書きしない。
- 要件が「写真が必要」行と「画像なし」行のあいだで本当に曖昧なら、短い質問を 1 つ: *「プロダクト写真は用意されますか？ それともスワップ可能なプレースホルダを置いておきますか？」*
- プレースホルダはプレースホルダに見えるべきで、確信のある決定に見せてはいけない。スキルは最終デザインのつもりでストック写真を捏造することを拒否する。
- 上の素材行はジャンルオーバーレイを上書きしない。Modern-minimal ジャンルは依然として装飾キット画像を抑制する（`imagery-kit.md` のアンチパターンでゲートする）。

下の階層はこのゲートが画像が必要だと判断した*後*にティアを選ぶ。このゲートを飛ばすと「全ページにブロブイラスト」出力になる — まさに Hallmark が拒否する AI のデフォルト。

---

## エンリッチメント階層

要件と時間が許す最高ティアに手を伸ばす。ティア飛ばしが新しいシグナル。

| ティア | 何 | いつ |
| --- | --- | --- |
| **0 · タイポグラフィのみ** | エンリッチメントなし。ディスプレイ、リード、任意の CTA。 | 常に受け入れ可能。最強のフェイルセーフ。 |
| **A · カスタム構築 CSS アート** | ピュア CSS の形、グラデーション、clip-path、アセットなし、依存ゼロ。 | 幾何学的形、グラデーション構成、グリフ風装飾。 |
| **B · 手組み SVG** | Figma で設計、最適化、宣言的にアニメーション。 | CSS では綺麗に扱えない複雑なイラスト — パン、マスコット、ワークフロー図。 |
| **C · 生成イラスト** | Nanobanana / Recraft V4 / Midjourney、出自 + ポストプロセス付き。 | 手組みでは経済的に届かないキャラクターや特定シーン。常にポストプロセス。 |
| **D · ライブラリイラスト** | Storyset / Humaaans / unDraw、ブランドカラーでカスタマイズ。 | 予算とタイムラインがショートカットを強いるとき — それでも無改変は不可。 |
| **E · Lottie アニメーション** | 最終手段。手組みできない複雑なキャラクターモーションだけ。 | 関節を持つ人物、マルチフレームのマスコットループ。「回転ロゴ」や「チェックマーク描画」には絶対使わない — それは CSS。 |

**規律。** Tier A でできるなら A でやる。A で届かないなら B を試す。キャラクターが必要なときだけ C に落とす。要件が明確に「速くて安く」と言うときだけ D。E が本当に唯一の選択肢のときだけ E。馴染みがあるから E に手を伸ばすのは — 多くの AI ツールがそうする — テンプレートページのシグネチャ。

Tier A と B での*組み方*は [`custom-craft.md`](custom-craft.md)。Tier C、D、E のソースカタログは [`assets.md`](assets.md)。

---

## 目視で決めるか、聞くか — 判断プロトコル

エンリッチメントを選ぶ 2 つのパス:

```
要件に明示的なビジュアル手掛かりがあれば、このマップから選ぶ:

  • "demo", "show how it works", "product tour"           → E1 / E2 デモ動画
  • "platform", "tool", "infra", "dashboard", "developer" → E3 / E4 モックアップ
  • "shop", "store", "menu", "products", "items"          → E8 写真（または F6 プロダクトグリッド）
  • "bakery", "kitchen", "café", "atelier" + クラフト要件 → E5 カスタムイラスト（Tier B SVG）
  • "agency", "studio", "portfolio"                       → E8 写真かエンリッチメントなし
  • "manifesto", "essay", "book", "letter"                → エンリッチメントなし（タイポグラフィのみ）
  • Quiet 系テーマがピックされている                       → エンリッチメントなし（テーマそのものが抑制）

要件が本当に曖昧なら、質問を 1 つ:
  「Want me to add a demo video, an illustration, or keep it
   typography-only? I default to typography-only because it's
   the strongest fail-state.」

それ以外はエンリッチメントなしをデフォルトに。返信でマクロ構造の推測と
並べて、推測内容を 1 文で明示。
```

迷ったらエンリッチしない。ヒーローは大丈夫。多くの優れたランディングはタイポグラフィ的。

---

## 8 つのエンリッチメントアーキタイプ

各アーキタイプには 1 行定義、「使う場面」「避ける場面」、短いコードスケッチ、アーキタイプ内の 2〜3 個の variation knob がある（[`component-cookbook.md`](component-cookbook.md) と整合）。

### E1 · デモ動画 — ビューポート端でクリップ

左にディスプレイ見出し、右にデモ動画、動画の右端 10〜20 % をビューポートからはみ出させて意図的に切る。クリップ*が*デザイン — 「この画面に収まる以上のプロダクトがある」を示唆する。Linear が開拓、Vercel・Resend・Cursor が洗練。

*使う場面:* 要件が SaaS / 開発ツール / ダッシュボード / プラットフォームで、プロダクトの実映像がある。
*避ける場面:* 実映像がない。ストック映像の都市スカイラインの端クリップは埋め草に読まれる。

**Knobs:**
- クリップ側（right · left · both）
- アスペクト比（16/10 · 16/9 · 4/3）
- フレーム処理（hairline 1 px frame · browser chrome · none）

**実例。** Tracejam（SaaS 可観測性 — [`site/_tests/05-tracejam-saas/`](../../site/_tests/05-tracejam-saas/) 参照）。左にディスプレイ見出し（「Distributed tracing that explains itself.」）、右に手組み CSS アートのトレースウォーターフォール、-0.4° に傾けてビューポート右端を 12 vw 越える。アスペクト 16/10。ヘアラインフレーム。**実動画ではない** — モックアップは Tier A のカスタム構築 CSS（フレームチャートを模した % グリッド上の矩形）。モバイル（< 60 rem）: クリップを外し、縦積み。

```html
<section class="hero hero--clipped">
  <div class="hero__copy">
    <h1>Plan, build, ship.</h1>
    <p>The project tracker your engineering team won't ignore.</p>
    <a class="btn" href="/signup">Try it free</a>
  </div>
  <figure class="hero__media">
    <video autoplay muted loop playsinline preload="metadata"
           poster="/hero-poster.webp" fetchpriority="high"
           aria-label="Tour of the dashboard interface">
      <source src="/hero.av1.mp4"  type='video/mp4; codecs="av01.0.05M.08"'>
      <source src="/hero.vp9.webm" type="video/webm">
      <source src="/hero.h264.mp4" type="video/mp4">
    </video>
  </figure>
</section>
```

```css
.hero--clipped {
  display: grid;
  grid-template-columns: minmax(20rem, 1fr) 1.4fr;
  gap: var(--space-2xl);
  align-items: center;
  overflow: visible;        /* let the media spill past the page edge */
}
.hero__media {
  width: calc(100% + 12vw); /* the 12 % of viewport that sits beyond the right edge */
  aspect-ratio: 16 / 10;
  border-radius: 12px;
  border: var(--rule-hair) solid var(--color-rule);
  overflow: hidden;
}
.hero__media video { width: 100%; height: 100%; object-fit: cover; }

@media (max-width: 60rem) {
  .hero--clipped { grid-template-columns: 1fr; }
  .hero__media { width: 100%; }    /* don't try to clip on mobile — reads as broken */
}

@media (prefers-reduced-motion: reduce) {
  .hero__media video { display: none; }
  .hero__media { background: url('/hero-poster.webp') center/cover; }
}
```

**Critical:** ヒーロー動画に `loading="lazy"` は決して付けない — LCP が死ぬ。`preload="metadata"` と `fetchpriority="high"` を使う。常に `poster=""` とアクセシビリティ用 `<track kind="captions">` を含める。

### E2 · デモ動画 — フルブリードのミュートループ + ゴーストオーバーレイ

動画がフォールドを満たし、`mix-blend-mode: multiply` でペーパー色のオーバーレイに透けさせ、タイプが読めるようにする。動画は壁紙、被写体ではない。

*使う場面:* プロダクトの*感じ*がメッセージのとき（ムード、触感、雰囲気）。
*避ける場面:* プロダクトをはっきり*見せたい*とき — E1 か E3 を使う。

**Knobs:**
- ゴースト不透明度（0.3 / 0.5 / 0.7）
- テキスト整列（left-bias / centred）
- 一時停止挙動（always-loop · pause-on-hover · pause-when-out-of-viewport）

**実例。** 小さなファッションブランドの春のルックブック。スタジオで布地がドレープする 8 秒ミュートループ。`mix-blend-mode: multiply` で 0.5 不透明の暖クリームオーバーレイに重ね、イタリックディスプレイ見出し（「Spring · 2026 · Lookbook 04」）が動く映像の上で綺麗に読める。ホバーで停止し、リードを邪魔されずに読める。キャプショントラック（VTT）が映像をアクセシビリティ用に説明。

### E3 · モックアプリスクリーンショット — ブラウザフレーム付きスプリット

左にディスプレイ見出し、右にブラウザフレームのモックアップ、モックアップウィンドウを少し（1〜3°）傾けて生命感。フレームは [Browserframe](https://browserframe.com) または手組み（1 px ヘアライン + macOS の 3 つのドット）。

*使う場面:* Web アプリを売っていて、綺麗で照明の整ったスクリーンショットがある。
*避ける場面:* スクリーンショットが雑然または曖昧 — フレームが乱雑さに目を向けさせる。

**Knobs:**
- フレームスタイル（browser chrome · macOS toolbar · minimal hairline · none）
- 傾き角度（0° · 1.5° · 3°）
- スクリーンショット数（1 · stack-of-3 · orbit-of-3）

**実例。** Linear 風のプロジェクトトラッカー SaaS ランディング。左に見出し（「Plan, build, ship.」）、右にカンバンビューのブラウザフレームスクリーンショット、時計回りに 1.5° 傾斜。3 つの番号付きアノテーション（1 · 自動アサイン · 2 · リアルタイムプレゼンス · 3 · キーボードファースト）、各々小さな番号ピンとマージン揃えのキャプション付き — 矢印とラベルの組み合わせは絶対不可。スタックではなく単一スクリーンショット — 読み込むアセットが少なく、読みが鋭くなる。

### E4 · モックアプリスクリーンショット — フレームなしフローティング

E3 と同じ構成だがブラウザクロームなし — スクリーンショットがソフトシャドウと 12 px のコーナー半径でフローティング。よりクリーン。クロームの寛容さがないので、より高品質のスクリーンショットが必要。

*使う場面:* スクリーンショット自体が裸で立てる美しさを持つとき。
*避ける場面:* プロダクトに「これは本物のウェブアプリ」の合図が必要なとき。

**Knobs:**
- シャドウの深さ（subtle / medium / dramatic）
- コーナー半径（0 · 8 px · 16 px）
- 背景の見え方（gradient / solid / none）

**実例。** コードフォーマッタ CLI のマーケティングページ。左に見出し（「Format anything, in eight lines.」）、右に `before` / `after` のコードを並べた 1 枚のフローティングスクリーンショット。12 px コーナー半径、-10 px オフセットの 24 px ソフトシャドウ、わずかにティントされたグラデーションサーフェスの上に置く。**ブラウザクロームなし** — スクリーンショット自体が構成されていて裸で立てる美しさ。スクリーンショットが特に高品質なときに使う。そうでなければ E3 に切り替える（クロームが乱雑なキャプチャを許容してくれる）。

### E5 · カスタムイラストセンターピース

手組み SVG（デフォルト、Tier B）または生成ラスター（Tier C、キャラクターが必要なとき）が単一のイラスト要素としてヒーローに座る — ベーカリーのパン、スタジオのマスコット、ワークフローの流れの図。

*使う場面:* ブランドにストーリーや作っているものがあり、絵にする価値があるとき。
*避ける場面:* ブランドが「モダンなプロフェッショナルチーム」的に汎用 — それをイラスト化するのが新しいテンプレ。

**Knobs:**
- 構築方法（Tier A ピュア CSS / Tier B 手組み SVG / Tier C 生成 / Tier D ライブラリ）
- アニメーション（none · loop · scroll-linked）
- スケール（small accent · dominant）

**実例。** Maple Street Bread（ベーカリー — [`site/_tests/03-maple-bakery/`](../../site/_tests/03-maple-bakery/) 参照）。左に Letter スタイルのヒーロー文言（「Saturday, 6:14 a.m. The dough went in at midnight.」）、右に 60 行手組み SVG のパン、3 パス（body、shade、score-marks）。`@property --rise` で 6 秒の 4 px ブレシングループ、alternate でアニメーション。スコアマークは `stroke-dasharray` で初回ペイント時に自ら描かれる。Tier B、dominant スケール、animation: loop。reduced-motion フォールバックは静止キーフレーム。

60 行 SVG で手描き風のパンを*組み上げ*、`@property` で呼吸をアニメーションする方法は [`custom-craft.md`](custom-craft.md) — ベーカリーの完全実例に加え、4 つのレシピ（ワークフロー図、マスコット、アーキテクチャ図、植物アクセント）がある。

### E6 · アニメーションループ — ピュア CSS / SVG / Motion

小さなカスタム構築ループ — 周回するドット、呼吸する矩形、アニメーショングラデーションストップ、タイプマスクリビール。要点は*小さい*、カスタム、ループは*reduced-motion がオフのときだけ*。

*使う場面:* ページが他は静止していて、小さなアニメーション要素 1 つが命を与えるとき。
*避ける場面:* ページに既に動きがある — 足すと不安に読まれる。

**Knobs:**
- 媒体（CSS keyframes · SVG SMIL/CSS · Motion）
- 配置（margin · inline-with-headline · corner-accent）
- ループ時間（≤ 4 秒 — 長いと引きずる）

**実例。** コラボレーションホワイトボードアプリ。見出しの隣に 2 秒のピュア CSS ループ: 1 つのドットがゆっくり楕円を周回し、Lottie なしで「リアルタイムコラボ」を示唆。`@property --angle` で `transform: rotate()` を 0deg → 360deg 補間。マージン配置、約 64 × 64 px、アクセント色を低クロマで。**Lottie ではない** — ピュア CSS で 0 バイト、reduced-motion にも上品に対応（メディアクエリで animation: none）。

### E7 · 抽象背景 — サブトルなグラデーション + グレイン

低クロマの 2 色 CSS グラデーション、SVG `<feTurbulence>` のグレインを 0.1 未満の不透明度で重ねる。*オーラではない*、*紫からシアンのメッシュではない*、*浮遊する球体でもない*。要点はかろうじて見える*テクスチャ* — 紙の質感であり、装飾ではない。

*使う場面:* ページが平らなサーフェスでは合成的に感じるとき。
*避ける場面:* テーマが既にペーパーフィールを持っているとき（Specimen、Linen、Riso）。グレインの重ねがけは濁る。

**Knobs:**
- グラデーション方向（45° / 135° / radial）
- グレイン量（off · subtle · textured）
- アニメーション（none · slow drift · scroll-linked parallax）

**実例。** 小さなポッドキャストサイト（ホストが Tide のタイポグラフィのみの引用より少し視覚的な熱を欲しいとき）。*ヒーローのみ*に 135° の 2 ストップ CSS グラデーション（暖クリーム → わずかオレンジ、両方 < 0.04 クロマ） — ページ全幅には絶対適用しない。SVG `<feTurbulence>` グレインオーバーレイを 0.06 不透明、`mix-blend-mode: multiply`。アニメーションなし。あらゆるオーロラブロブの誘惑に抗う。

```html
<section class="hero hero--bg">
  <div class="hero__bg" aria-hidden="true">
    <svg width="0" height="0" style="position: absolute;">
      <filter id="grain"><feTurbulence baseFrequency="0.9" numOctaves="2"/></filter>
    </svg>
  </div>
  <div class="hero__copy"> ... </div>
</section>
```
```css
.hero { position: relative; isolation: isolate; }
.hero__bg {
  position: absolute; inset: 0; z-index: -1;
  background:
    linear-gradient(135deg,
      color-mix(in oklch, var(--color-paper) 100%, var(--color-accent) 4%),
      color-mix(in oklch, var(--color-paper) 100%, var(--color-paper-2) 50%));
}
.hero__bg::after {
  content: ""; position: absolute; inset: 0;
  filter: url(#grain);
  opacity: 0.06;
  mix-blend-mode: multiply;
  pointer-events: none;
}
```

### E8 · ヒーロー写真 — タイトにクロップした 1 枚

クックブック既存の H6 アーキタイプ。完全性のためここで相互参照。variation knob は [`component-cookbook.md`](component-cookbook.md) 参照。

**実例。** 小さなリスボンのカフェ。夜明けのエスプレッソマシンを 4/3 比でタイトにクロップした 1 枚、フルブリードなし。キャプションは左下にマージン揃え、モノスモールキャップス（「Plate 04 · 6:42 a.m.」）。写真はソースから 8 % 彩度を落とし、ページの暖紙トーンと調和させる。写真は常にトーンの合うタイポグラフィペアリング（[`typography.md`](typography.md) 参照）と組む — ブルータリストページにラグジュアリートーンの写真はぶつかる。

---

## ヒーロー形状の仕上げ — エンリッチメントを越えるパターン

上の 8 つのエンリッチメントアーキタイプ（E1〜E8）は*見出しの隣に何が座るか*を決める。下の 4 つの仕上げパターンは*見出し自身がどう座るか*を決める — レイアウト、タイプ、モーションに作用し、装飾を上に乗せはしない。これらはどのヒーローマクロ構造（Marquee Hero、Stat-Led、Quote-Led、Letter、Photographic、Clipped）にも上乗せ可能。ヒーローが形状的に平坦に感じるとき — 色だけ、対称、予測可能 — 仕上げパターンを 1 つ選ぶ。

ヒーローには仕上げパターン 1 つ*と*エンリッチメントアーキタイプ 1 つを同時に乗せてよいが、仕上げパターンを同時に 2 つは絶対不可。ヒーローはステークスの高いサーフェス。構造選択 1 つで運ぶ。

### HP1 · 垂直レール見出し

ワードマークまたはプルラベルが中央本文の脇を*垂直に*走る。CSS: レールに `writing-mode: vertical-rl; text-orientation: mixed;`、本文は脇の通常フロー。Studio · atelier · editorial 的に読まれる — 和的な版面のリズム、手組みの版面装飾。

*使う場面:* ヒーローが他は中央またはマーキー型で、ページにルールでも数字でもない構造的アンカーが欲しいとき。
*避ける場面:* 本文タイトル自体が大きく中央 — 垂直レールと巨大な水平ディスプレイは軸の取り合いになる、方向は 1 つに。

```html
<header class="hero hero--rail">
  <p class="hero__rail" aria-hidden="true">STUDIO · 2026 · WORK · LETTERS</p>
  <div class="hero__body">
    <h1 class="hero__display">A working archive.</h1>
    <p class="hero__lede">Twelve years. Selected projects, in their own time.</p>
  </div>
</header>
```
```css
.hero--rail { display: grid; grid-template-columns: auto 1fr; gap: var(--space-2xl); padding: var(--space-2xl) var(--page-gutter); align-items: end; }
.hero__rail { writing-mode: vertical-rl; text-orientation: mixed; font-family: var(--font-display); font-size: var(--text-sm); letter-spacing: 0.18em; color: var(--color-ink-2); margin: 0; }
@media (max-width: 60rem) { .hero--rail { grid-template-columns: 1fr; } .hero__rail { writing-mode: horizontal-tb; font-size: var(--text-xs); } }
```

*アンチパターン:* 垂直テキスト*と*水平ディスプレイ見出しが同じスケールで競合する。方向は 1 つ、レールはサポートのボイス。

### HP2 · マーキーオーバーフロー

H1 が意図的にビューポートより大きい — ヒーローコンテナに `overflow-x: clip`、見出しが右端を越える。Manifesto · brutal · sport として読まれる — ページが収めきれないほど大声の見出し。

*使う場面:* ジャンルが遊び心ある（Brutal、Manifesto、Sport）かつ見出しが*短い*（≤ 6 語）。長い見出し + オーバーフロー = ノイズ。
*避ける場面:* 見出しが完全に読める必要がある法的情報を運ぶとき（プライバシー通知、利用規約）。

```html
<header class="hero hero--overflow">
  <h1 class="hero__display hero__display--xxl">STOP MAKING UI THAT LOOKS LIKE EVERYONE ELSE'S UI.</h1>
  <p class="hero__lede">Hallmark. A design skill that refuses defaults.</p>
</header>
```
```css
.hero--overflow { overflow-x: clip; padding: var(--space-2xl) var(--page-gutter); }
.hero__display--xxl { font-family: var(--font-display); font-weight: 800; font-size: clamp(4rem, 14vw, 14rem); line-height: 0.92; letter-spacing: -0.04em; margin: 0; white-space: nowrap; }
@media (max-width: 60rem) { .hero__display--xxl { white-space: normal; font-size: clamp(2.5rem, 10vw, 5rem); } }
```

*アンチパターン:* このヒーローと同時に `<html>` か `<body>` に `overflow-x: hidden` — 子孫の水平スクロール挙動が壊れる。`overflow-x: clip` のみ、ヒーローコンテナにスコープする。

### HP3 · カーソルスポットライト

`mousemove` を追う radial-gradient 背景、ヒーローのみにスコープ。Atmospheric · モダンミニマル SaaS として読まれる — Linear、Tailwind Labs、Raycast。

*使う場面:* ページが atmospheric / ダークペーパー / SaaS マーケで、ヒーローに遊べる空の余白があり、ブランドボイスが「触覚的、生きている」を運べるとき。
*避ける場面:* カーソルがコンテンツ（テキスト、ボタン）の上を追ってしまうとき — 読みのフォーカスを奪う。スポットライトはテキストの下のバックドロップレイヤーにスコープ、決してテキストの上ではない。

```html
<header class="hero hero--spotlight">
  <div class="hero__spotlight" aria-hidden="true"></div>
  <div class="hero__body">
    <h1 class="hero__display">Distributed tracing that explains itself.</h1>
    <p class="hero__lede">Open one trace. See the whole story.</p>
  </div>
</header>
```
```css
.hero--spotlight { position: relative; isolation: isolate; padding: var(--space-2xl) var(--page-gutter); overflow: hidden; }
.hero__spotlight { position: absolute; inset: 0; z-index: -1; background: radial-gradient(600px circle at var(--mx, 50%) var(--my, 30%), color-mix(in oklch, var(--color-accent) 22%, transparent), transparent 60%); transition: background 200ms var(--ease-out); }
@media (prefers-reduced-motion: reduce) { .hero__spotlight { transition: none; --mx: 50%; --my: 30%; } }
```
```js
// Scope to hero only — never page-wide.
const hero = document.querySelector('.hero--spotlight');
hero?.addEventListener('pointermove', (e) => {
  const r = hero.getBoundingClientRect();
  hero.style.setProperty('--mx', `${e.clientX - r.left}px`);
  hero.style.setProperty('--my', `${e.clientY - r.top}px`);
});
```

*アンチパターン:* カーソルを*ページ全体*で追う — 酔う、フォーカスを奪う。ヒーローのみにスコープ。reduced-motion フォールバックは効果を無効化するだけでなく（平らなサーフェスが残ってしまう）、グラデーションを妥当な静止位置（50% / 30%）にピン留めする。

### HP4 · 装飾的数字

巨大なエディション番号 / 年 / チャプターのグリフがディスプレイイタリックでヒーローの隅に置かれる。数字に*意味がある* — issue 22、year 2026、chapter 03、version 0.8。Editorial · salon · newsprint · almanac として読まれる。

*使う場面:* ページが本当にエディション / 号 / チャプター / バージョンのセマンティクスを持つ — 雑誌、ジャーナル、アーカイブ作品、日付つきエッセイ。
*避ける場面:* 数字にセマンティックアンカーがない。隅にランダムな「42」は装飾と読まれ、それはスロップ（slop-test ゲート 55 参照）。

```html
<header class="hero hero--num">
  <p class="hero__eyebrow">Studio · Spring 2026</p>
  <h1 class="hero__display">A working archive.</h1>
  <p class="hero__lede">Twelve years. Selected projects, in their own time.</p>
  <span class="hero__num" aria-hidden="true">22</span>
</header>
```
```css
.hero--num { position: relative; padding: var(--space-2xl) var(--page-gutter) var(--space-3xl); overflow: hidden; }
.hero__num { position: absolute; right: var(--page-gutter); bottom: -0.15em; font-family: var(--font-display); font-style: italic; font-weight: 600; font-size: clamp(8rem, 22vw, 18rem); line-height: 1; color: color-mix(in oklch, var(--color-ink) 8%, transparent); pointer-events: none; user-select: none; }
@media (max-width: 60rem) { .hero__num { font-size: clamp(5rem, 26vw, 9rem); right: -0.1em; } }
```

*アンチパターン:* 意味のない数字。数字は情報を運ばなければならない — 号、年、バージョン、チャプター、プレート。数字が*何*なのか名指しできないなら、外す。

---

## ヒーロー空間の規律

すべてのヒーロー — エンリッチされていようと、仕上げられていようと — がこれらのルールに従う。

- **フットプリント。** ヒーローは最初のビューポートの高さの 70〜90 % — それ以上でも以下でもない。`min-height: 100vh / 100dvh` は AI の指紋（ゲート 7）。ビューポートの 20 % しかないヒーローはヘッダーに感じる。`min-height: clamp(60vh, 75dvh, 88dvh)` を狙い、中にコンテンツを落ち着かせる。
- **非対称パディング。** `padding-block-end` ≥ 1.3× `padding-block-start`。ヒーローはページに*座る*、対称パディングは浮く。Slop-test ゲート 54 が強制。
- **すべてを中央に置かない。** アイブロウ + タイトル + リード + CTA を全部中央に積むのは AI の指紋。中央配置は最大*2 つ*まで、他はアラインメントを崩す。ゲート 53 が強制。中央寄せの狭いヒーローはジャンルが editorial / salon / atelier かつアイブロウか CTA がアラインメントを崩す場合のみ許容。
- **入場アニメーション。** 要素ごとに {fade, sweep, none} から 1 つ — 同じ要素に fade*と*sweep の両方は不可。Duration ≤ 220 ms。`prefers-reduced-motion: reduce` で無効化。下の「ページごとに 1 つのオーケストレーションされたリビール」ルールと相互参照。
- **見出しタイポグラフィ。** デフォルト 0 ではなく 1 つのディスプレイウェイト + タイトな字間（-0.02em〜-0.04em）を優先。ディスプレイの line-height は 0.95〜1.05、決して 1.2（本文の line-height を継承して未調整に読まれる）にしない。同じ見出し内に 2 つのディスプレイウェイトは避ける（タイトル内に違うウェイトの `<strong>` は AI の「強調」観念、ウェイトは 1 つ、語に運ばせる）。
- **仕上げパターンは 1 つまで。** HP1〜HP4 は単一ヒーロー上で排他。垂直レール*と*マーキーオーバーフロー*と*カーソルスポットライト*と*装飾数字を 1 つのヒーローに乗せるのはパニック発作。1 つ選ぶ。

判断順:

1. ヒーローマクロ構造をピック（Marquee Hero、Stat-Led、Quote-Led、Letter、Photographic、Clipped） — [`macrostructures.md`](macrostructures.md) 参照。
2. ゼロから 1 つの**エンリッチメントアーキタイプ**を選ぶ（上の E1〜E8）。
3. ゼロから 1 つの**仕上げパターン**を選ぶ（上の HP1〜HP4）。
4. 空間の規律ルールを適用。
5. 選択をマクロ構造刻印に刻む。

---

## アニメーション規律（ヒーロー固有）

[`motion.md`](motion.md)、[`microinteractions.md`](microinteractions.md)、[`custom-craft.md`](custom-craft.md) と相互参照。ヒーローはページで最もステークスが高いアニメーションサーフェス。ルールは他より厳しい。

**ページごとに 1 つのオーケストレーションされたリビール。** 8 個ではない。「スクロールで全部フェードイン」ではない。1 つ: ヒーローが 0.4〜0.8 秒で 1 つの coordinated motion で落ち着き、止まる。

**ヒーロー入場の禁止事項:**
- 弾むエラスティックイージング（`cubic-bezier(0.34, 1.56, ...)`） — 2016 Framer デモに読まれる
- スクロールフェード全部のせ（全セクションがビューポート進入でフェードイン）
- SaaS ランディングでのマウス追従グラデーション（ポートフォリオ / クリエイティブ / エージェンシー作品でのみ許容）
- マウス上のパララックス（モーション酔い、ギミック）
- パーティクル / 星空背景（2010 年代ノスタルジア、注意散漫）
- 自動回転ヒーローカルーセル（pause-on-hover-and-focus 実装がなければ WCAG 2.2.2 違反）

**許容:**
- 見出しが着地した後の単一画像フェードイン（約 0.6 秒後、約 0.4 秒持続）
- 見出しのタイプアンマスク（テキストの上を `clip-path` で開く）
- 状態変更（テーマ切り替え、ルート変更）への View Transitions API
- スタット主導ヒーローのナンバーティック（0 から最終値、≤ 1.2 秒）
- 単一のサブトルな Lottie / CSS ループ ≤ 4 秒、`prefers-reduced-motion` フォールバック付き

**2026 では reduced-motion がデフォルト。** すべてのアニメーションに `@media (prefers-reduced-motion: reduce)` ブロックを置き、モーションを無効化するか静止キーフレームに置換する。妥協なし、スロップテストが捕まえる。

---

## 品質基準 — 出荷前の 8 つの質問

エンリッチメントを出荷する前に全部 *yes* で答える。1 つでも *no* なら、タイポグラフィのみのヒーローを出す。

1. エンリッチメントはタイポグラフィでは**伝えられない**ことを伝えているか？
2. 合計 **2 MB** 未満か（動画ポスター + 最初のセグメント、イラスト + アニメーション JSON、画像 + グレイン）？
3. **`prefers-reduced-motion` フォールバック**があるか？
4. 動画なら: muted、looped、`playsinline`、ポスター + `fetchpriority="high"` + キャプショントラックあり？
5. イラストなら: 意図を持って組み上げ・生成したか？ **Lottie ライブラリからのショートカット拾いではない**？
6. 背景なら: アクセント色 1 つ未満で < 5 % フットプリントか？（オーロラとメッシュグラデは落ちる）
7. 削除しても生き残るか？（エンリッチメントなしでヒーローが機能するなら、居場所を勝ち取った。崩れるなら、弱いタイポグラフィを松葉杖で支えていた）
8. トーンがページのトーンに合うか？（ブルータリストページのリソグラフ = 違う。Workbench 開発者ツールページの手描きドゥードゥル = 違う。Quiet ページの Three.js bloom = 違う）

スロップテスト（[`SKILL.md`](../SKILL.md) §5）はこれらの質問を反映する 4 つのバイナリゲートを持ち、audit 動詞コマンドが実行する。

---

## 出力刻印

エンリッチメントを出荷するとき、マクロ構造刻印は選択を記録する:

```css
/* Hallmark · macrostructure: Marquee Hero · H1 hero knobs: size=xxl, alignment=left-bias
 * enrichment: E1 Clipped-Edge Video · clip=right, aspect=16/10, frame=hairline
 * polish: HP3 Cursor-spotlight (scoped to hero, reduced-motion fallback pinned at 50%/30%)
 * nav: N5 Floating pill · footer: Ft5 Statement
 * craft: tier-A CSS art (no real video — pure custom-built mockup)
 * theme: Linen · accent: steel-blue ~3% · studied: no
 */
```

仕上げパターンを使わなければ `polish:` 行を省略 — でっち上げない。エンリッチメントも同様。

これは将来の Hallmark 実行（と audit 動詞コマンド）に何がどう選ばれたかを示す。ユーザーも 1 か所で推測を見て、ズレていれば方向修正できる。

---

## よくあるミスとその修正

- **すべての要件で E5 イラストにデフォルト落ちする。** 多くのヒーローはイラストを欲しがらない。まず E0（タイポグラフィのみ）に手を伸ばす。E1〜E4 は*見せる*ものがあるとき。E5 はイラストが本当にトーンに合うときだけ。
- **ヒーローアニメーションにストックの Lottie チェックマーク。** これは Tier A〜D をスキップして Tier E を使うやつ。チェックマークはピュア CSS で組み上げる（`stroke-dasharray` でアニメーション）。8 行で済む。
- **どこにでもグレイン背景を足す。** グレインはトリートメントであってデフォルトではない。既存テーマの半分は既にテクスチャを持つ（Riso、Linen、Specimen）。重ねない。
- **抽象背景をヒーロー扱いする。** 違う。見出しがヒーロー。背景はペーパー。
- **無改変の Storyset SVG を出荷。** これは Tier D を接地なしで使うやつ — ライブラリルック。最低でも色をアンカー色相にカスタマイズ、できれば再構成。
- **モバイルでクリップエッジ動画。** 375 px ビューポートでは壊れて読まれる。< 60 rem では必ず縦積みに崩す。
