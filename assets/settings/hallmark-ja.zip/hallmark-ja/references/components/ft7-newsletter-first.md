### Ft7 · Newsletter-first
フォーム（ラベル＋入力欄＋送信ボタン）がフッターの*主要*要素。ワードマーク、リンク、著作権はすべて12pxの控えめな書体で下に置く。Stratechery、Substack型のサイト、インディマガジン。
*使う場面:* ブランドが本当に発行物を出していて、なおかつページのファースト画面で*すでに*購読を提示済みのとき。フッターは最後の招待であり、不意打ちではない。
*混同しない:* Ft1（こちらは何も要求しない）。

```html
<footer class="foot-news">
  <form class="foot-news__form" action="/subscribe" method="post">
    <label for="foot-email">Letters from the studio · monthly</label>
    <div class="foot-news__row">
      <input id="foot-email" name="email" type="email" required placeholder="you@domain">
      <button type="submit" class="cta-fill">Subscribe</button>
    </div>
  </form>
  <p class="foot-news__meta muted">Studio · © 2026 · <a href="/imprint">Imprint</a></p>
</footer>
```
```css
.foot-news { padding: var(--space-2xl) var(--page-gutter); display: grid; gap: var(--space-lg); max-width: 56ch; }
.foot-news__form label { display: block; font-size: var(--text-sm); margin-block-end: var(--space-2xs); }
.foot-news__row { display: flex; gap: var(--space-2xs); }
.foot-news__row input { flex: 1; min-height: 44px; padding-inline: var(--space-sm); border: var(--rule-hair) solid var(--color-rule); border-radius: var(--radius-input); background: var(--color-paper); }
.foot-news__row input:focus-visible { outline: 2px solid var(--color-focus); outline-offset: 1px; }
.foot-news__meta { font-size: var(--text-xs); }
```

*アンチパターン:* ファースト画面で一度も「subscribe」と言っていないのに Ft7 を出す。フッターは誠実な*結論*。事前にお願いしていないなら不意打ちしない。Ft2にする。
