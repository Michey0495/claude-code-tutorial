### Ft2 · Inline-rule single line
クレジット、住所、著作権を1行に並べる。上にヘアラインルール。カラム分けなし。
*使う場面:* ページがエディトリアルで、フッターは余韻程度に置きたいとき。
*混同しない:* Ft4 Dense typographic（こちらはもっと情報を詰める）。

```html
<footer class="foot-line">
  <p>© 2026 · 137 Marlow Street · MIT licensed</p>
</footer>
```
