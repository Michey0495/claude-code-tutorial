### Ft8 · Marquee scroll
タグライン＋ドット区切りが横方向に無限スクロールする1行: `STUDIO · 2026 · STUDIO · 2026 · STUDIO · 2026 ·`。スポーツ系サイト、ファッションルックブック、ブランド主張の強いエージェンシー。
*使う場面:* ブランドの声色が大きく、躍動的で、スポーツまたはマニフェスト調のとき。
*混同しない:* Ft4 Dense colophon（こちらは静的なテキスト）。

```html
<footer class="foot-marquee" aria-label="Footer">
  <div class="foot-marquee__track" aria-hidden="true">
    <span>STUDIO · 2026 · STUDIO · 2026 · STUDIO · 2026 · STUDIO · 2026 ·</span>
    <span>STUDIO · 2026 · STUDIO · 2026 · STUDIO · 2026 · STUDIO · 2026 ·</span>
  </div>
  <p class="visually-hidden">Studio · 2026 · MIT licensed</p>
</footer>
```
```css
.foot-marquee { overflow: hidden; border-top: 2px solid var(--color-ink); }
.foot-marquee__track { display: flex; gap: var(--space-2xl); white-space: nowrap; padding-block: var(--space-md); animation: foot-marquee 32s linear infinite; }
.foot-marquee__track span { font-family: var(--font-display); font-weight: 700; letter-spacing: 0.08em; font-size: clamp(1rem, 2.5vw, 1.5rem); }
@keyframes foot-marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }
@media (prefers-reduced-motion: reduce) { .foot-marquee__track { animation: none; } }
```

*アンチパターン:* エディトリアル／静かな文脈で Ft8 を使う。動きが大きく主張的に読まれる。プレイフル／スポーツ／マニフェスト系の声色とのみ組み合わせ、必ず `prefers-reduced-motion: reduce` を尊重する。

---
