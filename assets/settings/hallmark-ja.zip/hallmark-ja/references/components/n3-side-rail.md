### N3 · Side-rail
左端の細い縦帯。回転させたワードマークと、セクション用のドットインジケーター2〜3個。エディトリアル／ポートフォリオの趣。
*使う場面:* 長いページで、セクションに番号が振ってあるとき。
*混同しない:* N1 Top wordmark（こちらは横置き）。

```html
<nav class="nav-rail">
  <p class="wordmark vertical">Studio</p>
  <ul class="dots"><li></li><li></li><li></li></ul>
</nav>
```
```css
.nav-rail { position: fixed; left: 0; top: 0; bottom: 0; width: 3rem; padding: var(--space-md); writing-mode: vertical-rl; }
```
