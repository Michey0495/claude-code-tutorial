### N5 · Floating pill
全周丸めのピル型ナビ。ページ端から*はっきり離れて*、上端から `var(--space-md)` ほどの位置に浮かぶ。背景は柔らかいブラー、影もソフト。Vercel、Linear、Framer、Raycastなどの現代的ミニマルな質感。
*使う場面:* 現代的ミニマル／雰囲気重視のページで、ピルの下にブラーが乗る独立した面や画像がヒーローにあるとき。
*混同しない:* N1 Wordmark + 2 links（こちらは全幅）、N2 Floating chip（こちらは隅にアンカー）。

```html
<nav class="nav-pill" aria-label="Primary">
  <a class="wordmark">Studio</a>
  <ul class="nav-pill__links"><li><a>Catalog</a></li><li><a>Voice</a></li></ul>
  <a class="cta-fill">Get →</a>
</nav>
```
```css
.nav-pill {
  position: fixed; inset: var(--space-md) auto auto 50%;
  transform: translateX(-50%);
  display: inline-flex; align-items: center; gap: var(--space-md);
  padding: 0.5rem 0.875rem;
  background: color-mix(in oklch, var(--color-paper) 78%, transparent);
  backdrop-filter: blur(14px) saturate(120%);
  border: var(--rule-hair) solid var(--color-rule);
  border-radius: 999px;
  box-shadow: 0 8px 24px -12px oklch(0% 0 0 / 0.18);
  z-index: 20;
}
```

*アンチパターン:* ビューポートの95%幅を占める「ピル」は、ただの両端丸め全幅ナビ。意味がない。ピルは見て独立しており、内容にちょうどフィットする幅でなければならない。リンク群でおよそ720pxを超えるなら、リンクを1本減らすかN1に切り替える。
