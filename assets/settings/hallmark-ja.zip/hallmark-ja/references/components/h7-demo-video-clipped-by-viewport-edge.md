### H7 · Demo Video — Clipped-by-viewport-edge
左にディスプレイ見出し、右にデモ動画。右端の10〜20%をビューポート外まで延ばし、意図的に見切れさせる。この見切れ自体がデザインで、「画面に収まりきらないほどプロダクトがある」ことを示す。Linearが先駆け、Vercel / Resend / Cursorが洗練させた。
*使う場面:* SaaS／開発者ツール／ダッシュボード／プラットフォームで、プロダクトの実映像（または手作りのCSSアートモックアップ）があるとき。
*混同しない:* H4 Stat-Led（数値主導で動画なし）、H8 Mockup Split（動画ではなく静止スクリーンショット）。

E1レシピ一式（コーデック連鎖、自動再生ルール、`prefers-reduced-motion`フォールバック、モバイル折り畳み）は [`hero-enrichment.md`](hero-enrichment.md) を参照。下のクックブック項目は構造の素描。

```html
<section class="hero hero--clipped">
  <div class="hero__copy">
    <h1>Plan, build, ship.</h1>
    <p>The project tracker your engineering team won't ignore.</p>
  </div>
  <figure class="hero__media">
    <video autoplay muted loop playsinline preload="metadata"
           poster="/hero-poster.webp" fetchpriority="high">
      <source src="/hero.av1.mp4" type='video/mp4; codecs="av01.0.05M.08"'>
      <source src="/hero.h264.mp4" type="video/mp4">
    </video>
  </figure>
</section>
```
```css
.hero--clipped { display: grid; grid-template-columns: 1fr 1.4fr; gap: var(--space-2xl); overflow: visible; }
.hero__media   { width: calc(100% + 12vw); aspect-ratio: 16 / 10; border-radius: 12px; overflow: hidden; }
@media (max-width: 60rem) { .hero--clipped { grid-template-columns: 1fr; } .hero__media { width: 100%; } }
```
