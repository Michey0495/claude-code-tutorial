
### F1 · Bento grid
8〜15枚のタイルを非対称グリッドに混在配置（1×1、2×1、1×2、2×2）。サイズで視覚的なリズムを作る。
*使う場面:* 同等に有効な入り口が複数あるとき。SaaSの機能ページ。
*混同しない:* F2 Sticky-scroll（こちらはスティッキーなペース配分で縦に積む）。

```html
<section class="bento">
  <article class="cell span-2x2">…</article>
  <article class="cell span-1x1">…</article>
  <article class="cell span-2x1">…</article>
</section>
```
```css
.bento { display: grid; grid-template-columns: repeat(4, 1fr); grid-auto-rows: 12rem; gap: var(--space-md); }
.span-2x2 { grid-column: span 2; grid-row: span 2; }
.span-2x1 { grid-column: span 2; }
.span-1x2 { grid-row: span 2; }
@media (max-width: 56rem) { .bento { grid-template-columns: repeat(2, 1fr); } }
```
