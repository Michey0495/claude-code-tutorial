### S3 · Sticky pinned
本文がスクロールしている間、見出しはビューポートに留まる。現在地の手がかり。
*使う場面:* セクションが情報量豊富で、ユーザーが今どこにいるかを常に見えていると助かるとき。
*混同しない:* S1 Left-margin（こちらは動かない）。

```html
<header class="head-sticky">
  <p class="num-label">02</p>
  <h2>…</h2>
</header>
```
```css
/* ページにスティッキーのトップナビがある場合は、その高さ分オフセットして
   スティッキー見出しがナビの下に収まるようにする（slop-test gate 68）。
   --z-sticky（ページ内）を使い、ナビの --z-sticky-nav が上に重なるようにする。 */
.head-sticky { position: sticky; top: var(--banner-height, 0px); background: var(--color-paper); padding-block: var(--space-sm); border-bottom: 1px solid var(--color-ink); z-index: var(--z-sticky); }
```

**スティッキーペアリング規則:** ページがスティッキーな `<header>` / `<nav>` / `.banner`（つまり `position: sticky; top: 0` を持つもの）を出すなら、`tokens.css` で `--banner-height`（ナビの高さに一致するpx値）と `--z-sticky-nav`（`--z-sticky` より少なくとも1段上）を必ず宣言する。上のS3レシピは両方を参照する。これらのトークンが無いと、スクロール中にセクション見出しがナビの上を塗りつぶす ― slop-test gate 68を参照。
