### Ft3 · Index-style category list
3〜4本の短いカラム。各カラムの先頭にスモールキャップスでカテゴリを置き、4〜6本のリンクを並べる。
*使う場面:* ハブページまたはドキュメントのルート。
*混同しない:* Ft4 Dense typographic（こちらは1つの大きなブロック、カラム分けなし）。

```html
<footer class="foot-index">
  <div><p class="caps">Product</p><ul>…</ul></div>
  <div><p class="caps">Company</p><ul>…</ul></div>
  <div><p class="caps">Resources</p><ul>…</ul></div>
</footer>
```
