### H3 · Quote-Led
帰属付きのプルクォートがヒーロー。見出しは借りてきた信用。
*使う場面:* トップページに掲げる価値のある本物の推薦文があるとき。
*混同しない:* T3 Single huge quote（こちらはヒーロー枠ではなくページ中盤に置く）。

```html
<section class="hero-quote">
  <blockquote class="display-italic">"…"</blockquote>
  <p class="attribution">— Name, Role, Company</p>
</section>
```
