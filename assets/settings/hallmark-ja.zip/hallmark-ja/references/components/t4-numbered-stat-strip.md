### T4 · Numbered stat strip
1行に並ぶ3〜5個のスタット（数値＋修飾語）の横帯。等幅数字を使う。
*使う場面:* 相互補完的な複数の指標が一緒に機能するとき。
*混同しない:* H4 Stat-led hero（こちらは単一の焦点数値で、複数ではない）。

```html
<section class="stat-strip tnum">
  <div><b>2.4M</b><span>users</span></div>
  <div><b>99.97%</b><span>uptime</span></div>
  <div><b>14</b><span>regions</span></div>
</section>
```

---
