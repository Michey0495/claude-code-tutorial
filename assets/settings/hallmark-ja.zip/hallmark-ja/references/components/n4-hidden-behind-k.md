### N4 · Hidden behind ⌘K
表示されるナビを持たない。ユーザーは `⌘K` でコマンドパレットを開き、どこへでも飛ぶ。キーボードファーストな読者層向けの設計。
*使う場面:* このアフォーダンスを期待する技術系ユーザー向けのページ。
*混同しない:* N2 Floating chip（こちらは常時表示）。

```html
<button class="kbd-hint">⌘ K</button>
<dialog class="palette">…</dialog>
```
