### H5 · Letter Hero
一人称で始める書き出し ― "Dear reader,"。ファースト画面にボタンを置かない。個人的な往復書簡として読ませる。
*使う場面:* 創業者の声がそのままブランドのとき。
*混同しない:* H1 Marquee（こちらは非個人的な宣言）。

```html
<section class="hero-letter">
  <p class="salutation"><em>Dear reader,</em></p>
  <p class="lede">…</p>
</section>
```
