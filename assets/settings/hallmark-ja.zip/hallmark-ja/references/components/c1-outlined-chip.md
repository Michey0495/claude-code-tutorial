
### C1 · Outlined chip
枠線付き透明背景のボタン。タイポグラフィックな動詞（"Save changes"）を載せる。
*使う場面:* 主要アクションが1つで、目立たせつつ控えめにしたいとき。
*混同しない:* C2 Oversized solid（こちらは主張が強い）。

```html
<a class="cta-outline">Open your studio →</a>
```
```css
.cta-outline { display: inline-flex; align-items: center; gap: 0.4em; padding: 0.7rem 1.2rem; border: 1px solid var(--color-ink); min-height: 44px; }
```
