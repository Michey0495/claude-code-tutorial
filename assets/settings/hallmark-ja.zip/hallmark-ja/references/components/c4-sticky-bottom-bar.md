### C4 · Sticky bottom bar
ビューポート下端に固定された横長バー。CTAと簡潔な安心材料の一文を載せる。
*使う場面:* 長いページで、CTAに常時アクセス可能にしたいとき。
*混同しない:* ファースト画面の要素とは別物。これは*常駐*要素であり、ヒーロー部のCTAではない。

```html
<aside class="cta-sticky">
  <span>Try it free for 14 days.</span>
  <a class="cta-outline">Start →</a>
</aside>
```
```css
.cta-sticky { position: fixed; left: 0; right: 0; bottom: 0; padding: var(--space-sm) var(--space-md); background: var(--color-paper); border-top: 1px solid var(--color-rule); display: flex; justify-content: space-between; align-items: center; }
```

---
