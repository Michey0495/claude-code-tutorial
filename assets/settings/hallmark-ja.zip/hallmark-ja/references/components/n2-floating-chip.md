### N2 · Floating chip
隅に固定された小さなチップ。ワードマーク＋単一アクション（"Try it"）。ドキュメントフローには載らない。
*使う場面:* ファースト画面の比重が大きく、従来のナビが内容と競合してしまうとき。
*混同しない:* C4 Sticky bottom bar（こちらは全幅）。

```html
<aside class="nav-chip">
  <a class="wordmark">Studio</a>
  <a class="cta-outline">Try →</a>
</aside>
```
```css
.nav-chip { position: fixed; top: var(--space-md); right: var(--space-md); display: inline-flex; gap: var(--space-md); padding: 0.5rem 0.75rem; background: var(--color-paper); border: 1px solid var(--color-rule); }
```
