
### Ft1 · Mast-headed
ワードマークとタグラインを1本の横帯に据える。横に小さなリンク2〜3本、下に住所やライセンス。
*使う場面:* ページが情報量豊富で、フッターは静かに単独であってほしいとき。
*混同しない:* Ft2 Inline-rule（こちらはさらに削ぎ落とした形）。

```html
<footer class="foot-mast">
  <p class="wordmark">Studio Name</p>
  <p class="tagline muted">Designs that don't look generated.</p>
  <p class="links muted">Imprint · Privacy · Contact</p>
</footer>
```
