### F5 · Annotated screenshot
プロダクトのキャプチャを中央に置き、UIの細部を矢印や短いラベルで指し示す。
*使う場面:* プロダクトのUIそのものが説明となるとき。
*混同しない:* F2 Sticky-scroll（こちらは複数のスクリーンショットを順に並べる）。

```html
<figure class="annotated">
  <img src="" />
  <span class="callout" style="--x:60%; --y:30%;">→ assigns automatically.</span>
</figure>
```
