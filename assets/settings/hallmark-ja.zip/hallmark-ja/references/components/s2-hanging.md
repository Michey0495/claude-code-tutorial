### S2 · Hanging
見出しがセクション上部の余白に浮かぶ。枠線もルールもなし。
*使う場面:* 内容が静謐で、息継ぎの余地を要するとき。
*混同しない:* S3 Sticky-pinned（こちらはスクロールと連動して動く）。

```html
<header class="head-hang">
  <h2>…</h2>
</header>
```
```css
.head-hang { padding-block: var(--space-3xl) var(--space-xl); }
```
