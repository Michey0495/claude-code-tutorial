
### N1 · Wordmark + 2 links
ページ最上部のバー。左にワードマーク、右にテキストリンク2本（"Pricing" / "Sign in"）。ロゴ画像もメニューアイコンも使わない。
*使う場面:* 行き先がごく少ないとき。
*混同しない:* N3 Side-rail（こちらは縦置き）。

```html
<nav class="nav-min">
  <a class="wordmark">Studio</a>
  <ul><li><a>Pricing</a></li><li><a>Sign in</a></li></ul>
</nav>
```
