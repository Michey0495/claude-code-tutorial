
### H1 · Marquee
ひとつのステートメントでファースト画面を埋める。サブヘッドもCTAも画面内に置かない。
*使う場面:* ブランドや人物そのものがメッセージのとき。
*混同しない:* H4 Stat-Led（こちらは数値であって文ではない）。

```html
<section class="hero-marquee">
  <h1 class="display-xxl">A statement.</h1>
</section>
```
```css
.hero-marquee { min-height: 80dvh; display: grid; align-content: end; padding: 0 var(--page-gutter) var(--space-2xl); }
.display-xxl { font-size: clamp(4rem, 12vw, 12rem); line-height: 0.92; }
```
