### N9 · Edge-aligned minimal
ワードマークを左端ぎりぎりに、CTAを1つ右端ぎりぎりに置き、中間は広大な空白。リンク行は一切なし。*無いこと*がデザイン ― Appleのプロダクトページ、Carl Hauser、ラグジュアリーサイト。
*使う場面:* ラグジュアリー／静謐／Atelier／Salon系で、その沈黙にブランドが値するとき。
*混同しない:* N1 Wordmark + 2 links（こちらは中間を埋める）。

```html
<header class="nav-edge">
  <a class="wordmark">Studio</a>
  <a class="cta-outline">Get →</a>
</header>
```
```css
.nav-edge { display: flex; justify-content: space-between; align-items: center; padding: var(--space-md) var(--page-gutter); }
.nav-edge .wordmark { font-family: var(--font-display); font-size: var(--text-md); }
```

*アンチパターン:* ワードマークとCTAの間に「空白を埋めるために」インラインリンクを4本足す。空白*こそが*デザイン。埋めたら、ただ手間のかかるN1を作っただけになる。
