### Ft5 · Statement
ひとつの大きなディスプレイ文がフッターを支配する。サイトマップではなくクロージングライン。ワードマーク、最小限のリンク、著作権を控えめな小さな書体で下に置く。Stripe（旧版）、リブランド前のMailchimp、エージェンシーのポートフォリオ末尾。
*使う場面:* ページが*締めの一文*を望むとき。エディトリアル、マニフェスト、雰囲気重視。この一文はページの主張と対をなす。
*混同しない:* Ft1 Mast-headed（こちらはワードマークが主役で、一文ではない）。

```html
<footer class="foot-stmt">
  <p class="foot-stmt__line">Build something they'll remember.</p>
  <div class="foot-stmt__meta">
    <span class="wordmark">Studio</span>
    <span class="muted">© 2026 · MIT</span>
  </div>
</footer>
```
```css
.foot-stmt { padding: var(--space-2xl) var(--page-gutter) var(--space-xl); display: grid; gap: var(--space-lg); }
.foot-stmt__line { font-family: var(--font-display); font-size: clamp(1.75rem, 5vw, 3.25rem); line-height: 1.0; letter-spacing: -0.02em; max-width: 28ch; margin: 0; }
.foot-stmt__meta { display: flex; justify-content: space-between; align-items: baseline; padding-block-start: var(--space-sm); border-top: var(--rule-hair) solid var(--color-rule); }
```

*アンチパターン:* ドキュメントルートやハブにStatementフッターを使う。そこではその一文がマーケコピーのように読める。Ft3を既定にする。
