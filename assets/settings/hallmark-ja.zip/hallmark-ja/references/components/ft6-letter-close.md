### Ft6 · Letter close
手紙のように締める。`Yours, the team. 2026.` 任意で追伸の一行を下に置く。プロダクトではなく書き物としてのページにする。
*使う場面:* ページの語り口が温かく、手書き感のある、エディトリアル寄りで静かなとき。Garden、Atelier、Salon、個人サイト。
*混同しない:* Ft1 Mast-headed（こちらはワードマーク主体のアンカーで、サインオフではない）。

```html
<footer class="foot-letter">
  <p class="foot-letter__close">Yours,<br><span class="foot-letter__sign">— Studio</span></p>
  <p class="foot-letter__ps muted">P.S. — letters back welcome at <a href="mailto:hello@studio">hello@studio</a>.</p>
</footer>
```
```css
.foot-letter { padding: var(--space-2xl) var(--page-gutter); max-width: 60ch; }
.foot-letter__close { font-family: var(--font-display); font-style: italic; font-size: var(--text-lg); line-height: 1.4; }
.foot-letter__sign { font-style: normal; font-weight: 600; }
.foot-letter__ps { font-size: var(--text-sm); margin-top: var(--space-md); }
```

*アンチパターン:* スタット主導／B2Bプロダクトページに Ft6 を使う。声色の不一致で気取って見える。本当に手紙の形をしたページにだけ使う。
