### N8 · Terminal command
CLIプロンプトとして組まれたナビ: `> studio --catalog --voice --get▮`。「リンク」はコマンドフラグ。明滅カーソル（`▮`）は*ここだけ*許される（「次にあなたが打つ」を示す意味がある）。ページの他の場所では単独使用しない。Vercel CLIドキュメントのランディング、Charm、Mitchell Hashimotoのサイトなど。
*使う場面:* ページがCLIツール、開発者ツールのドキュメント、またはTerminalテーマを纏うとき。
*混同しない:* N4 ⌘K-only（こちらはパレットで、見えるバーではない）。

```html
<header class="nav-term">
  <pre class="nav-term__line"><span class="prompt">&gt;</span> studio <a href="#catalog">--catalog</a> <a href="#voice">--voice</a> <a href="#get">--get</a><span class="caret" aria-hidden="true">▮</span></pre>
</header>
```
```css
.nav-term { padding: var(--space-sm) var(--page-gutter); border-bottom: var(--rule-hair) solid var(--color-rule); }
.nav-term__line { font-family: var(--font-outlier, ui-monospace, "JetBrains Mono", monospace); font-size: var(--text-sm); margin: 0; }
.nav-term__line .prompt { color: var(--color-accent); padding-right: 0.4ch; }
.nav-term__line a { color: var(--color-ink); text-decoration: underline; text-underline-offset: 2px; }
.caret { display: inline-block; width: 1ch; animation: blink 1.05s steps(2) infinite; color: var(--color-accent); }
@keyframes blink { 50% { opacity: 0; } }
@media (prefers-reduced-motion: reduce) { .caret { animation: none; opacity: 1; } }
```

*アンチパターン:* 開発者向けでないサイトに `>` プロンプト語彙を使う（結婚式の写真家ポートフォリオで `> view --gallery` ナビは舞台装置にしか見えない）。N8は本物のターミナル／CLIブランドだけのもの。
