
### S1 · Left-margin numbered
左の細いカラムに `01 — LABEL.` を置き、右の広いカラムに見出しと本文を置く。
*使う場面:* エディトリアル／スペシメン的なページ。
*混同しない:* S5 Bottom-anchored（こちらはラベルをセクションの*下*に置く）。

```html
<header class="head-margin">
  <p class="num-label">01 — Foundations</p>
  <h2>…</h2>
</header>
```
```css
.head-margin { display: grid; grid-template-columns: 10rem 1fr; gap: var(--space-xl); align-items: baseline; }
```
