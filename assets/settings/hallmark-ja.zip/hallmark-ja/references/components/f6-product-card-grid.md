### F6 · Product card grid
各カードは機能ではなくプロダクト。画像・名前・価格・小さなアクション1つ。マーケティングサイトではなく売り場のように読ませる。
*使う場面:* コマース、カタログ、ルックブック、マーケットプレイスといった、*機能*ではなく*モノ*を売るページ。
*混同しない:* F1 Bento（こちらは*機能*を売る。タイルのサイズやスパンが可変）。プロダクトカードは意図的に均一で、リズムはレイアウトではなくプロダクト自体から生まれる。

**バリエーションつまみ:** カード比率（3/4縦・1/1正方形・4/3横）・密度（3列・4列・5列）・価格扱い（名前下・画像上・ホバーで表示）・小アクション（Add・Save・View →・なし）。

```html
<section class="product-grid">
  <article class="product">
    <a class="product__media" href=""><img src="" alt="" loading="lazy" /></a>
    <div class="product__meta">
      <h3 class="product__name">Linen Apron · Indigo</h3>
      <p class="product__price tabular-nums">¥ 6,400</p>
    </div>
    <button class="product__add" aria-label="Add Linen Apron to bag">+</button>
  </article>
  <!-- ... more products, uniform shape ... -->
</section>
```
```css
.product-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: var(--space-xl) var(--space-lg); }
@media (max-width: 60rem) { .product-grid { grid-template-columns: repeat(2, 1fr); } }
.product { display: grid; gap: var(--space-sm); position: relative; }
.product__media { display: block; aspect-ratio: 3 / 4; background: var(--color-paper-2); overflow: hidden; }
.product__media img { width: 100%; height: 100%; object-fit: cover; transition: transform var(--dur-long) var(--ease-out); }
.product__media:hover img { transform: scale(1.02); }
.product__name { font-family: var(--font-body); font-size: var(--text-md); margin: 0; }
.product__price { font-family: var(--font-mono); font-size: var(--text-sm); color: var(--color-ink-2); }
.product__add { position: absolute; top: var(--space-sm); right: var(--space-sm); width: 32px; height: 32px; background: var(--color-paper); border: var(--rule-hair) solid var(--color-rule-2); cursor: pointer; opacity: 0; transition: opacity var(--dur-short) var(--ease-out); }
.product:hover .product__add, .product:focus-within .product__add { opacity: 1; }
@media (pointer: coarse) { .product__add { opacity: 1; } }
```

**プロダクトグリッドで避けるべきアンチパターン:**
- Bentoの不揃いなスパンを流用しない。プロダクトは均一なリズムが望ましい。
- プロダクト名の下に機能紹介のような2行説明を入れない。価格自体が説明。
- アイドル時に画像をスケールさせない。ホバー時のみ、最大1.02倍まで。
- 影＋角丸＋枠線＋タイル＋リボンを全部盛りにしない。コンテナの主張は1つだけ選ぶ。

---
