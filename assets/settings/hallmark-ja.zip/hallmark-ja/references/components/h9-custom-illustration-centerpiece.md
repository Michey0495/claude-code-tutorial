### H9 · Custom Illustration Centerpiece
手で組み上げたSVG1枚（拡張階層のTier B ― シンプルな形ならTier Aの純CSS）をヒーローに1つだけ載せる。パン屋のローフ、スタジオのマスコット、ワークフロー図など。
*使う場面:* ブランドに描かれることで活きる*何か*がある場合 ― 工芸、キャラクター、プロセスなど。
*混同しない:* H6 Photographic（こちらは実写写真）、H8 Mockup（こちらはプロダクトのスクリーンショットで、作品ではない）。

イラスト自体は*組み上げる*ものであって、Storyset / Humaaans / unDraw / Lottieから拾ってこない。完全なレシピ（CSSアート、手組みSVG、宣言的アニメーション）は [`custom-craft.md`](custom-craft.md) を参照。下のクックブック項目はページレベルの構造素描。

```html
<section class="hero-art">
  <div>
    <p class="eyebrow">Maple Street Bread · est. 2026</p>
    <h1>Sourdough, every morning.</h1>
    <p>Slow-fermented overnight, baked on stone, before you wake.</p>
  </div>
  <svg viewBox="0 0 200 100" class="loaf" aria-label="A loaf of bread">
    <path class="loaf__body" d="M 20 70 Q 100 10 180 70 L 180 90 L 20 90 Z" />
    <path class="loaf__score" d="M 60 50 L 90 30 M 100 45 L 130 25 M 140 50 L 165 35" />
  </svg>
</section>
```
```css
.hero-art   { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-2xl); align-items: center; }
.loaf__body { fill: oklch(72% 0.14 50); }
.loaf__score{ stroke: oklch(38% 0.10 35); stroke-width: 2; fill: none; stroke-linecap: round; }
```

---
