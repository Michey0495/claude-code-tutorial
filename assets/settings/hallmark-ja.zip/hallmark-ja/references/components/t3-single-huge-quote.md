### T3 · Single huge quote
1つのクォートを大きく中央に据え、セクション全体を使う。補助テキストも帰属ボックスもなし。帰属は下に小さなスモールキャップス1行。
*使う場面:* 1つのクォートが部屋全体に値するほど良いとき。
*混同しない:* T1 Margin pull-quote（こちらは*脇役*であり、*部屋*ではない）。

```html
<section class="proof-room">
  <blockquote class="display-italic">"…"</blockquote>
  <p class="attribution"><span class="caps">— Name, Company</span></p>
</section>
```
