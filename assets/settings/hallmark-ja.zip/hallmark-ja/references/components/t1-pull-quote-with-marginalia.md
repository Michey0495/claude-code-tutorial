
### T1 · Pull-quote with marginalia
クォートは広いカラムに、帰属と出典リンクは狭い余白カラムに浮かす。
*使う場面:* ページがすでに余白注記のリズムを持つとき（Tufte寄り、エディトリアル）。
*混同しない:* T3 Single huge quote（こちらは中央寄せで全画面を支配する）。

```html
<aside class="proof-margin">
  <blockquote class="serif-italic">"…"</blockquote>
  <p class="attribution muted">— Name<br />Role, Company</p>
</aside>
```
