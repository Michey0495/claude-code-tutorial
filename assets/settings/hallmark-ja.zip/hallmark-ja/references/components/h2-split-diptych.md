### H2 · Split Diptych
片側に見出し＋リード、もう片側に画像またはプロダクトキャプチャ。6/6 または 7/5 のカラム。
*使う場面:* あらゆる主張をビジュアルの証拠と対にできるとき。
*混同しない:* H6 Photographic（こちらは画像をフルブリードで置き、対にしない）。

```html
<section class="hero-split">
  <div><h1>…</h1><p>…</p><a class="cta-outline">…</a></div>
  <figure><img src="" /></figure>
</section>
```
```css
.hero-split { display: grid; grid-template-columns: 7fr 5fr; gap: var(--space-2xl); align-items: center; }
@media (max-width: 56rem) { .hero-split { grid-template-columns: 1fr; } }
```
