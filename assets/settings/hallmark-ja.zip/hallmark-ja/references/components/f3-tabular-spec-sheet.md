### F3 · Tabular spec sheet
各行が1つの機能。列に名前、値、脚注を載せる。行間はヘアラインルール。等幅数字を使う。
*使う場面:* 機能を数値で比較するとき。
*混同しない:* F1 Bento（こちらは非表組で、視覚的リズム重視）。

```html
<table class="spec-sheet tnum">
  <tr><th>Latency</th><td>p99 &lt; 50 ms</td><td class="muted">measured externally</td></tr>
  <tr>…</tr>
</table>
```
