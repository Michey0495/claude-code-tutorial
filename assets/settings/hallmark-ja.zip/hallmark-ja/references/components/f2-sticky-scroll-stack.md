### F2 · Sticky-scroll stack
左ペインをスティッキー固定、右ペインで関連スクリーンショットをスクロール送り。
*使う場面:* 機能に複数のサブ状態があり、順に見せる価値があるとき。
*混同しない:* F4 Step sequence（こちらは番号付きで線形、同期しない）。

```html
<section class="sticky-stack">
  <div class="pane-sticky"><h3>…</h3><p>…</p></div>
  <div class="pane-scroll">
    <figure>1</figure><figure>2</figure><figure>3</figure>
  </div>
</section>
```
```css
.sticky-stack { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-2xl); }
/* `calc(--banner-height + --space-xl)` でスティッキーペインをナビ下に余白を持って配置。
   ページにスティッキーナビがない場合は --space-xl 単体にフォールバック
   （slop-test gate 68）。 */
.pane-sticky { position: sticky; top: calc(var(--banner-height, 0px) + var(--space-xl)); align-self: start; z-index: var(--z-sticky); }
```
