### C2 · Inline form-as-CTA
CTAそのものがフォーム。メール入力欄1つに "Submit →" を並べる。サインアップ用の別ページを設けない。
*使う場面:* アクションがメール収集のとき。
*混同しない:* C1 Outlined chip（こちらは遷移用で、送信ではない）。

```html
<form class="cta-form">
  <label for="email" class="visually-hidden">Email</label>
  <input id="email" type="email" placeholder="you@example.com" />
  <button type="submit">Send →</button>
</form>
```
```css
.cta-form { display: grid; grid-template-columns: 1fr auto; border-bottom: 1px solid var(--color-ink); }
.cta-form input { background: none; border: 0; padding: 0.7rem 0; min-height: 44px; }
```
