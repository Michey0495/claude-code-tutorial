### Ft4 · Dense typographic
クレジット、出典、ライセンス、住所をひとつの大ブロックに、小さな等幅フォントで両端揃えまたは右ラギッドで配置。エディトリアルのコロフォンの趣。
*使う場面:* エディトリアルなブランドで、コロフォン風の締めくくりが似合うとき。
*混同しない:* Ft3 Index（こちらは導線として機能する）。

```html
<footer class="foot-dense mono">
  <p>Hallmark v0.2.0. Built with The Future, Fraunces, IBM Plex Mono. MIT licensed. Powered by Together AI. 137 Marlow Street, 2026.</p>
</footer>
```
