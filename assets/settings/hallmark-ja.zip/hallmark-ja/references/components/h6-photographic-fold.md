### H6 · Photographic Fold
1枚のフルブリード画像がビューポートを埋める。キャプションは隅に置く。
*使う場面:* フルブリードに耐える本物の写真があるとき。
*混同しない:* H2 Split（こちらは画像とテキストをグリッドで対にする）。

```html
<section class="hero-photo">
  <img class="bleed" src="" alt="" />
  <p class="caption">Spring, 2026.</p>
</section>
```
```css
.hero-photo { position: relative; height: 80dvh; }
.hero-photo .bleed { width: 100%; height: 100%; object-fit: cover; }
.hero-photo .caption { position: absolute; bottom: var(--space-md); right: var(--space-md); }
```
