### F4 · Step sequence
番号付きステージ（`1.0 → 2.0 → 3.0`）を縦方向に流す。各ステージは見出し、段落、必要なら小さなビジュアル。
*使う場面:* プロダクトが単一の瞬間ではなく、ワークフローのとき。
*混同しない:* F2 Sticky-scroll（こちらはステージに番号を振らない）。

```html
<ol class="steps">
  <li><span class="stage">1.0</span><h3>Intake.</h3><p>…</p></li>
  <li><span class="stage">2.0</span><h3>Plan.</h3><p>…</p></li>
</ol>
```
