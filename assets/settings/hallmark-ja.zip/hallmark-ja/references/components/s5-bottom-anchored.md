### S5 · Bottom-anchored
ラベルや見出しをセクション本文の*下*に置く。階層を反転させる。
*使う場面:* 本文が主役で、ラベルがそのフッターになるとき。
*混同しない:* S1 Left-margin（こちらはラベルが先導）。

```html
<section>
  <div class="content">…</div>
  <p class="num-label">— end of 02</p>
</section>
```

---
