### N7 · Brutal slab
重厚な全幅ナビ。下に2pxの実線ボーダー、オールキャップスのワードマーク、字間を広げた大文字リンク行、密なリズム、影なし、角丸なし。Pentagramの案件ページ、Liquid Death、ブルータリズム寄りのエージェンシーの趣。
*使う場面:* ジャンルがプレイフル（Brutal、Manifesto、Sport）で、ブランドの声色が重厚／宣言的なとき。
*混同しない:* N1 Wordmark + 2 links（こちらは小さく静か）。

```html
<header class="nav-slab">
  <a class="slab-mark">STUDIO</a>
  <nav class="slab-nav" aria-label="Primary">
    <ul><li><a>CATALOG</a></li><li><a>VOICE</a></li><li><a>WORK</a></li></ul>
  </nav>
  <a class="cta-fill cta-fill--slab">GET</a>
</header>
```
```css
.nav-slab { display: flex; align-items: center; gap: var(--space-md); padding: var(--space-sm) var(--page-gutter); border-bottom: 2px solid var(--color-ink); background: var(--color-paper); }
.slab-mark { font-family: var(--font-display); font-weight: 800; letter-spacing: 0.04em; }
.slab-nav ul { display: flex; gap: var(--space-md); list-style: none; padding: 0; margin: 0 0 0 auto; }
.slab-nav a { text-transform: uppercase; letter-spacing: 0.08em; font-size: var(--text-sm); font-weight: 600; }
```

*アンチパターン:* N7に角丸、ソフトシャドウ、背景ブラーを組み合わせる。語彙が衝突する。ブラーを使いたいならN5へ、丸みを使いたいならN1へ落とす。
