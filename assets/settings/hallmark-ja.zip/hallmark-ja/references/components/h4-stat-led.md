### H4 · Stat-Led
巨大な数値またはメトリクスがヒーロー。下に小さな修飾の一文。
*使う場面:* 外部から検証可能で防衛可能な数値が1つあるとき。
*混同しない:* T4 Numbered stat strip（こちらは焦点1つではなく、横並びの複数スタット）。

```html
<section class="hero-stat">
  <p class="figure tnum">99.97<span class="unit">%</span></p>
  <p class="qualifier">…</p>
</section>
```
```css
.figure { font-size: clamp(6rem, 18vw, 16rem); font-variant-numeric: tabular-nums; line-height: 0.85; }
```
