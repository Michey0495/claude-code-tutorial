### N6 · Newspaper masthead
全幅ヘッダー。最上段に中央寄せの大きなワードマーク、その上か下にセリフのスモールキャップスで号数／日付の細い行、必要なら下にインラインのリンク行、全体の下にダブルルール。エディトリアル、ブロードシート紙の趣 ― NYT、FT、Vogue。
*使う場面:* エディトリアル、雑誌型、号／エディションとして枠取りされたページ。
*混同しない:* N1 Wordmark + 2 links（こちらは非対称で小さい）。

```html
<header class="nav-mast">
  <p class="mast-line muted">No 22 · Spring 2026 · Studio</p>
  <h1 class="mast-name">STUDIO</h1>
  <nav class="mast-nav" aria-label="Primary">
    <ul><li><a>Catalog</a></li><li><a>Voice</a></li><li><a>Letters</a></li></ul>
  </nav>
  <hr class="mast-rule double" aria-hidden="true">
</header>
```
```css
.nav-mast { display: grid; gap: var(--space-2xs); padding: var(--space-md) var(--page-gutter) 0; text-align: center; }
.mast-name { font-family: var(--font-display); font-size: clamp(2.25rem, 5vw, 3.75rem); letter-spacing: -0.01em; line-height: 0.95; margin: 0; }
.mast-line { font-variant: small-caps; letter-spacing: 0.08em; font-size: var(--text-xs); }
.mast-nav ul { display: inline-flex; gap: var(--space-md); list-style: none; padding: 0; margin: var(--space-2xs) 0 0; }
.mast-rule.double { border: 0; border-top: var(--rule-hair) solid var(--color-rule); border-bottom: var(--rule-hair) solid var(--color-rule); height: 4px; margin: var(--space-sm) 0 0; }
```

*アンチパターン:* SaaSダッシュボードや開発者ツールのプロダクトページに N6 を使う。マストヘッドの語彙は長文／エディトリアルサイトの所有物。B2Bプロダクトに乗せると衣装に見える。
