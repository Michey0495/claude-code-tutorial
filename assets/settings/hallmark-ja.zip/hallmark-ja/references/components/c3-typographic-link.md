### C3 · Typographic link
単語と矢印、1pxのアンダーラインのみ。枠も塗りも持たない。
*使う場面:* ページがエディトリアル／長文ドキュメント系で、CTAが主張すべきでないとき。
*混同しない:* C1 Outlined chip（こちらは枠線あり）。

```html
<a class="link">Read the case study →</a>
```
