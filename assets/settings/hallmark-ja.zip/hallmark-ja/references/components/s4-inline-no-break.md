### S4 · Inline (no break)
見出しは本文の流れの*中に*現れるスモールキャップスのフレーズ。空間的な切れ目を作らない。
*使う場面:* 散文主体のページで、読みを連続させたいとき。
*混同しない:* S2 Hanging（こちらは余白で切る）。

```html
<p>… <span class="head-inline">A small heading.</span> …</p>
```
```css
.head-inline { font-variant-caps: all-small-caps; letter-spacing: 0.06em; font-weight: 500; }
```
