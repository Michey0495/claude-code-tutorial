# カスタムテーマ — プロトコル

ユーザーが Design フロー Step 1 で **custom** テーマ経路を選んだときにのみ読み込まれる。Custom はこの要件向けにチューンされた **完全な OKLCH パレット＋無料フォント ペアリング** を生成する — ページの `:root` にインラインで書かれる1度きりのテーマで、永続カタログ エントリではない。

**自由は組み合わせにあり、ルールにはない。** [`color.md`](color.md)、[`typography.md`](typography.md)、[`anti-patterns.md`](anti-patterns.md) の全制約はそのまま適用される。65 のスロップテスト ゲートは変わらず発火する。Step 5 プレビュー ブロックがコード出力前にパレット＋ペアリングを平文で表面化し、ユーザーが軌道修正できるようにする。

## 2語、平易な英語

- **catalog** — 命名済みのテーマ カタログ。Hallmark の 22 テーマ（Specimen、Atelier、Brutal、Salon、Newsprint、Linen、Studio、Manifesto、Terminal、Midnight、Almanac、Garden、Quiet、Riso、Sport、Bloom、Coral、Violet、Aurora、Halo、Plume、Editorial）。各々は paper-band、display-style、accent-hue の固定組み合わせ。ローテーション ルールが循環し、連続実行が似て読まれないようにする。**これがデフォルト。** ほとんどの要件はこれを使う。
- **custom** — オーダーメイド。1つの要件のために特別に構築されたパレット＋フォント ペアリング、1度きり。スキルが OKLCH 値を構築しフォントを選びページをスタンプするが、新テーマでカタログを **拡張しない**。カタログ背後のルール（paper L 帯、accent 彩度上限、フォント禁止リスト、スロップテスト ゲート）はすべて適用される。要件ごとに変わるのは *組み合わせ* だけ。

## いつこの分岐を表面化するか — Step 1 トリガー シグナル

Hallmark はすべてのプロンプトで catalog 対 custom を提示してはならない。それは規律ではなく摩擦。下記シグナルのどれかが要件に含まれるときだけ分岐を表面化する。

1. **明示的依頼** — ユーザーが `custom`、"custom theme"、"tailored to our brand"、"make it ours"、"something unique"、"play around with the colors and fonts"、"I want my own palette" とタイプ。
2. **名指しのブランド色** — ユーザーが具体的なアンカー色を hex / OKLCH / ブランド名で与える。例: "use our terracotta"、"the brand red is hex #c0392b"、"anchor on sea-blue"。
3. **カタログが運べない多属性の美学** — 3つ以上の vibe 語が特定のカタログ外の感触を指している。例: "moss, lichen, soft pink, herbal" / "sun-drenched, market-day, carbon-black" / "late-night, neon, brutalist deli"。22 カタログ テーマと比較し、どのカタログ テーマも vibe の1軸ステップ以内に無いなら分岐発火。**1形容詞（"warm"、"technical"、"playful"）はシグナルではない — それはトーン、カタログが既に運ぶ。**
4. **ブランド ムード参照が添付** — カラー スウォッチ、ムード ボード、Pantone チップ。（*ページ* スクリーンショットが添付されているなら `study` にルートする。custom はブランド色／ムード用、study はデザイン DNA 用。）

シグナルが発火したら、テーマを選ぶ前に短いフォローアップを1問。

> *"This brief reads like a custom palette would fit better than the 22 named themes. Want me to construct a custom OKLCH palette + free-font pairing tuned to <vibe の1行サマリ>, or stay on the catalog for variety + speed?"*

ユーザーの回答を待つ。custom（または yes / go）と答えたら → § A からこのプロトコルを続ける。catalog（または no / stay catalog）と答えたら → 分岐を落として catalog 経路で進める。**デフォルトは catalog** — 沈黙は custom ではなく catalog にルートする。

**どのシグナルも発火しないなら、分岐に触れない。** 沈黙のうちに catalog フローを続ける。

---

## § A · 1つのフォローアップ質問

ユーザーが `custom` をテーマ経路として命名したら、**1つ** のことを **1つのメッセージ** で聞く。

> *"Custom needs one input — describe the brand's vibe in 4–8 words. Examples: 'archival warmth, hand-set, no varnish' · 'industrial precision, cool, technical' · 'moss, lichen, soft pink, herbal' · 'sun-drenched, market-day, carbon black' · 'late-night, neon, brutalist deli'.*
>
> *Optional second input: an anchor colour — hex, OKLCH, or a name like 'terracotta', 'sea-blue', 'forest-green', 'dusty-pink'. If you skip it, I'll pick one from the vibe."*

**他は何も聞かない。** Step 1 のオーディエンス／用途／トーン＋ブランド vibe で既にシグナルは十分。モデルが paper 明度やフォント ウェイトの指名をユーザーに頼むのは仕事ではない — それはモデルの仕事。

ユーザーが2〜3語（"sun-drenched"）しか出さなくても進める。下記のレシピが十分抽出する。段落で出してきたら受け入れるがスタンプ用に 4–8 語に圧縮する。

---

## § B · パレット構築

この順でパレットを構築する。各ステップは従うルールを引用する。ルールを言い直さず、適用するだけ。

### B.1 · 先にアンカー アクセント

- ユーザーの命名 hex アンカーを OKLCH に変換。
- [`color.md`](color.md) § "Accent — the discipline" に従い彩度を **0.12–0.20** にクランプ。
- ユーザーが省略したら: vibe から色相を導出 — *warmth* → 30–60° · *technical/industrial* → 220–250° · *botanical/moss* → 130–160° · *late-night/neon* → 280–320° · *sun-drenched/market* → 60–80° アンバー。彩度は 0.12–0.16 に保つ（中飽和、彩度ではなく中立色との対比から来る）。

### B.2 · Paper

- Vibe から paper L を導出。
  - bright/airy/breakfast/hand-set → **L 95–98 %**（暖色味付き）
  - archival/editorial/restrained → **L 92–95 %**（暖色味付き）
  - technical/clinical/spec-sheet → **L 98–100 % ニア白**（寒色味付き、#fff と等しくてもよいが下流の中立色は色味付き）
  - dark/restless/late-night/manifesto → **L 12–18 %**（アンカー色味付き）
- [`color.md`](color.md) § "Neutral tinting" に従い、**paper を常にアンカー色相に向けて彩度 0.005–0.020 で色味付ける**。純白 #fff は ink ＋アクセント＋グレー類が彩度を運ぶときのみ許可。paper 自体は *両方向* で彩度 0 にはしない。
- Paper-2（1ステップの elevation）: paper から L ±2–4 % ステップ。
- Paper-3（任意の第2ステップ）: paper から L ±5–7 % ステップ。最小パレットでは省略。

### B.3 · Ink

- Paper L < 50 なら: ink L **88–96 %**。
- Paper L ≥ 50 なら: ink L **16–24 %**。
- Ink 彩度はアンカーに向けて **0.005–0.014**（一段暗／明、決して中立ではない）。
- Ink-2（二次テキスト）: ink から paper に向かって L 4–8 % ステップ。同じ色相ファミリー。

### B.4 · サポートのグレー類

paper と ink の間で約 6–10 % L ステップ、すべて彩度 0.005–0.018 でアンカーに色味付け。

- `--color-rule` — ディバイダー · L 〜70–82 %（明 paper）または 〜26–34 %（暗 paper）。
- `--color-rule-2` — 二次ディバイダー · rule より paper に 4–6 % L 近く。
- `--color-muted` — 強調抑制テキスト · L 〜38–56 %。
- `--color-neutral` — 中グレー相当 · L 〜30–56 %。

これらは恣意ではない。L ステップがアクセントに頼らない **タイポグラフィの深さ** をパレットに与える。

### B.5 · Focus

- アクセントと同じ色相、可視性のため彩度をわずかに高く（0.18–0.22）。
- アクセントと同じ L ±5 %。
- `:focus-visible` でのみ使用 — [`microinteractions.md`](microinteractions.md) § "Focus is a first-class state" に従い即時に表示。

### B.6 · Accent-ink（アクセント上のオーバーレイ テキスト色）

- アクセント L > 50 なら: ink を使う（アクセント塗りの上で暗テキストとして読まれる）。
- アクセント L ≤ 50 なら: paper を使う（アクセント塗りの上で明テキストとして読まれる）。
- [`color.md`](color.md) に従い本文に対して **APCA コントラスト ≥ 7:1**、大きいテキストには ≥ 3:1 を検証。

### B.7 · 検証

- **Gate 8**（純 #000 / #fff のベースなし）: paper と ink の両方が彩度 > 0。Pass。
- **Gate 24**（彩度0の中立色なし）: すべてのグレーが彩度 ≥ 0.005。Pass。
- **Gate 25**（アクセント ≤ 5 % 占有）: ページ上でアクセントの役割を計画する（アクティブ状態、ワードマークのドット1つ、CTA 塗り1つ）。セクションをアクセントで絨毯にしない。

---

## § C · フォント ペアリング

Custom は [`typography.md`](typography.md) の 7 トーン ペアリング — Editorial、Technical、Brutalist、Soft、Luxury、Playful、Austere、Workshop — から取る。各トーンに **free baseline** と **paid upgrade** がある。

### C.1 · 自由

カタログは Display-from-tone-X を Body-from-tone-X とペアにする。**Custom はトーンを混ぜられる** — それが要点。

- Editorial display ＋ Technical body（italic Fraunces wordmark ＋ Geist body） — 学究トーンの SaaS に効く。
- Brutalist display ＋ Editorial body（Anton ＋ Newsreader italic） — 左派のマニフェスト誌に効く。
- Playful display ＋ Austere body（Bricolage Grotesque ＋ Inter Tight） — クリエイター ツール ブランドに効く。
- Luxury display ＋ Technical body（Cormorant Garamond ＋ JetBrains Mono） — 手仕事の dev-tool に効く。

任意のトーン列から **display 1つ** と **body 1つ** を選ぶ。ページがコードや表データを持つなら任意の mono。

### C.2 · 規律

- **無料ベースラインのみ**。ユーザーが有料ライセンスを確認していない限り。[`typography.md`](typography.md) § "The discipline" に従う: "Never name a paid font in code without confirming the user is licensed."
- **禁止のデフォルトは依然禁止** — [`typography.md`](typography.md) § "Banned defaults" 通り、Inter / Roboto / Open Sans / Poppins / Lato / Work Sans / DM Sans / Montserrat / system-ui を display にすると Gate 1 fail。
- **バリアブル フォントを推奨**、利用可能なら（Fraunces、Bricolage Grotesque、Newsreader、Geist、EB Garamond、Inter Tight） — optical-size とウェイト軸でタイポグラフィを精密に制御できる。

### C.3 · ペアは読まれること

display ＋ body が決まったら、ページを脳内描画する。

- [`typography.md`](typography.md) § "Commit to extremes" に従い、display 書体は十分なウェイト コントラスト（200/400 の隣に 700/900）を持つか。
- body 書体は選んだ body サイズ（≥ 14 px の床、デフォルト 1 rem）で選んだ measure（45–75 ch）で読めるか。
- display も body も mono なら — ページ自体がデザイン（Terminal 美学、真の単一フォント specimen）であるときのみ許可。[`typography.md`](typography.md) line 7 参照。

どれかの答が no なら軌道修正 — 別の body 書体を選ぶか display ウェイトをずらす。

---

## § D · カスタム軸の計算

カスタム テーマは多様化ルールの3軸値を明示的に宣言し、[`SKILL.md`](../SKILL.md) § "Theme-diversification rule" がカタログ テーマと同じように発火するようにする。

### D.1 · Paper band

- **dark** — paper L < 30 %
- **mid** — paper L 30–85 %
- **light** — paper L > 85 %

### D.2 · Display style

選んだ display 書体に基づいて1つ選ぶ。

- **italic-serif** — Fraunces italic、Newsreader italic、EB Garamond italic、Cormorant italic
- **roman-serif** — Source Serif 4、Newsreader、Crimson Pro、Bitter、Cardo
- **geometric-sans** — Geist、Bricolage Grotesque、Inter Tight、Manrope、Sora
- **mono** — Geist Mono、JetBrains Mono、IBM Plex Mono、Space Mono
- **display-condensed-italic** — Migra italic、Tobias italic
- **display-condensed-bold** — Anton、Bebas Neue、Oswald、Barlow Condensed
- **display-heavy** — Inter Tight 900、Bricolage 800、Druk クラス
- **slab-serif** — Roboto Slab、Bitter heavy、Zilla Slab
- **system-native** — system-ui、Inter Tight 400（austere）
- **risograph-bold** — 手仕事感のあるボールド サンス
- **handwritten** — Caveat、Sacramento、Patrick Hand（稀、ブランドが要求するときのみ）

### D.3 · Accent hue band

- **warm** — 色相 10–60°（赤、オレンジ、アンバー）
- **cool** — 色相 200–300°（青、インディゴ、シアン）
- **neutral** — 有彩アクセントなし（austere、彩度 < 0.05）
- **chromatic-other** — warm / cool / neutral の外。具体アンカーをサブタグ化: `chromatic-green ~145°` · `chromatic-sage ~120°` · `chromatic-phosphor ~150°` · `chromatic-terracotta ~30°` · `chromatic-dusty-pink ~350°` · `chromatic-moss ~140°` · `chromatic-amber ~75°`。

### D.4 · どこに書くか

3つすべてをマクロ構造スタンプ（下記 § E）と `.hallmark/log.json` エントリ（下記 § F）に書く。永続記録となる。次の実行がこれを読む。

---

## § E · スタンプ形式

生成スタイルシートの先頭の CSS コメント（[`SKILL.md`](../SKILL.md) Step 6 § "Stamp the output" に従う）。

```css
/* Hallmark · macrostructure: <name> · <hero archetype + knobs>
 * theme: custom · vibe: "<4–8 words>" · paper: oklch(<L>% <C> <H>) · accent: oklch(<L>% <C> <H>)
 * display: <font name> · body: <font name> · axes: <paper-band> / <display-style> / <accent-hue>
 * studied: no · context: <user-provided | inferred> · v0.6.x
 */
```

具体例。

```css
/* Hallmark · macrostructure: Long Document · H5 hero knobs: salutation=time-stamp, body=2 paragraphs, signoff=initials
 * theme: custom · vibe: "archival warmth, hand-set, no varnish" · paper: oklch(94% 0.020 65) · accent: oklch(58% 0.16 35)
 * display: Fraunces italic · body: Source Serif 4 · axes: light / italic-serif / chromatic-terracotta
 * studied: no · context: explicit · v0.8.0
 */
```

スタンプが永続記録。`audit` がこれを読む。次の実行がこれを読む。ユーザーがこれを読む。

---

## § F · `.hallmark/log.json` エントリ形状

Custom 実行は既存スキーマを `theme_axes` フィールドと任意の `vibe` フィールドで拡張する。

```json
{ "date": "2026-05-01",
  "macrostructure": "Stat-Led",
  "theme": "custom",
  "theme_axes": "light / italic-serif / chromatic-terracotta",
  "vibe": "archival warmth, hand-set, no varnish",
  "enrichment": "none",
  "brief": "Coffeebox · subscription" }
```

カタログ エントリは引き続き `theme: <name>` を記録し `theme_axes` を省略する（カタログの軸は [`tokens.css`](../../site/css/tokens.css) から参照）。Step 2.5 ロジックは両方に同じ多様化チェックを使う。カタログ エントリは tokens.css から軸を読み、custom エントリはエントリから軸を読む。

ローテーション時、**custom 実行に続く custom 実行は、直前の custom と少なくとも1軸で違わせる必要がある** — カタログ対カタログと同じルール。カタログ実行に続く custom 実行は、カタログの軸と少なくとも1軸で違わせる。多様化ルールはテーマ経路ブラインド。

---

## § G · 3つのワークド例

モデルの模倣を促す具体生成。各々が要件、ユーザーの vibe 回答、構築したパレット、選んだペア、スタンプを示す。

### G.1 · アーカイブ カフェ — "Coffeebox"

**要件:** *"Build me a landing page for Coffeebox — a small-batch coffee subscription. Roast on Sunday, ship on Monday, drink Tuesday. Audience: people who already buy good coffee and want fewer trips to the shop. Tone: warm, hand-set, editorial — like a small café's chalkboard. Theme route: custom."*

**Vibe 回答:** *"archival warmth, hand-set, no varnish."*  **アンカー:** *"terracotta."*

**パレット:**
- paper `oklch(94% 0.020 65)` — warm-cream、色相 65（アンバー暖色）
- paper-2 `oklch(91% 0.022 65)` — 1ステップ elevation
- ink `oklch(22% 0.014 60)` — 暖色のダーク ブラウン ブラック
- ink-2 `oklch(40% 0.014 60)` — 暖色二次
- rule `oklch(78% 0.018 65)` — 暖色ヘアライン
- muted `oklch(54% 0.014 60)` — 暖色グレー
- accent `oklch(58% 0.16 35)` — テラコッタ（色相 35、彩度 0.16）
- accent-ink `oklch(96% 0.014 65)` — アクセント上テキストに paper
- focus `oklch(56% 0.20 35)` — アクセントの高彩度

**ペア:** display **Fraunces italic**（Editorial、無料） · body **Source Serif 4**（Editorial、無料） · mono **JetBrains Mono**（Technical、無料）。

**軸:** **light / italic-serif / chromatic-terracotta**。

**スタンプ:**
```css
/* Hallmark · macrostructure: Long Document · H5 hero knobs: salutation=time-stamp, body=2 paragraphs, signoff=initials
 * theme: custom · vibe: "archival warmth, hand-set, no varnish" · paper: oklch(94% 0.020 65) · accent: oklch(58% 0.16 35)
 * display: Fraunces italic · body: Source Serif 4 · axes: light / italic-serif / chromatic-terracotta
 * studied: no · context: explicit · v0.8.0
 */
```

### G.2 · インダストリアル フィンテック — "Loop"

**要件:** *"Loop is a real-time payment-rail observability platform for fintechs. Audience: platform engineers. Use case: try it / contact sales. Tone: industrial, cool, technical. Theme route: custom."*

**Vibe 回答:** *"industrial precision, cool, technical."*  **アンカー:** *"sea-blue."*

**パレット:**
- paper `oklch(13% 0.012 220)` — ダーク クール
- paper-2 `oklch(17% 0.014 220)` — 1ステップ上
- paper-3 `oklch(22% 0.014 220)` — 2ステップ上（パネル）
- ink `oklch(94% 0.010 220)` — クール ライト
- ink-2 `oklch(72% 0.010 220)`
- rule `oklch(30% 0.012 220)`
- muted `oklch(58% 0.012 220)`
- accent `oklch(72% 0.16 220)` — シーブルー（cool）
- focus `oklch(78% 0.20 220)`

**ペア:** display **Geist Mono 500**（Technical、無料） · body **Geist**（Technical、無料） · mono **Geist Mono**（Technical、無料）。

注: これは *単一ファミリー* ページ（Geist と Geist Mono は同じファミリーの異なる幅）。[`typography.md`](typography.md) line 7 が許可: "single-font pages are allowed only when the single font IS the design choice." インダストリアル プレシジョン フィンテックではそれがデザイン上の選択。

**軸:** **dark / mono / cool**。

**スタンプ:**
```css
/* Hallmark · macrostructure: Workbench · F2 sticky-scroll knobs: pinned=right, content=trace-panel, steps=3
 * theme: custom · vibe: "industrial precision, cool, technical" · paper: oklch(13% 0.012 220) · accent: oklch(72% 0.16 220)
 * display: Geist Mono 500 · body: Geist · axes: dark / mono / cool
 * studied: no · context: explicit · v0.8.0
 */
```

### G.3 · ボタニカル アポセカリー — "Mossroot"

**要件:** *"Mossroot is a small herbal apothecary in Porto. We make tinctures, salves, and tea blends. Audience: locals + visitors. Use: see what we make + visit. Tone: quiet, herbal, hand-poured. Theme route: custom."*

**Vibe 回答:** *"moss, lichen, soft pink, herbal."*  **アンカー:** *（省略 — vibe から拾う）*。

Vibe は2色相を命名する: *moss*（緑、〜140°）と *soft pink*（暖、〜350°）。**ソフト ピンクをアクセント** に選び（単一アンカー — custom はワン アクセント厳格）、モス グリーンを *paper の色味* として使う（彩度 0.018、145° 方向）。これでアクセントを分割せずにデュアル vibe を運ぶ。

**パレット:**
- paper `oklch(96% 0.018 145)` — モス色味のニア白
- paper-2 `oklch(93% 0.020 145)`
- ink `oklch(22% 0.014 140)` — モス色味の暗
- ink-2 `oklch(42% 0.014 140)`
- rule `oklch(82% 0.018 145)`
- muted `oklch(56% 0.014 140)`
- accent `oklch(72% 0.13 350)` — ダスティ ピンク（chromatic-other）
- focus `oklch(70% 0.18 350)`

**ペア:** display **Cormorant Garamond**（Luxury、無料） · body **EB Garamond**（Luxury、無料） · mono **Geist Mono**（このページでは稀、原料リスト用）。

**軸:** **light / roman-serif / chromatic-other (dusty-pink)**。

**スタンプ:**
```css
/* Hallmark · macrostructure: Catalogue · F1 catalogue knobs: tiles=8, columns=2, rule=hairline-between
 * theme: custom · vibe: "moss, lichen, soft pink, herbal" · paper: oklch(96% 0.018 145) · accent: oklch(72% 0.13 350)
 * display: Cormorant Garamond · body: EB Garamond · axes: light / roman-serif / chromatic-other (dusty-pink)
 * studied: no · context: explicit · v0.8.0
 */
```

---

## Custom が **しないこと**（再確認の価値）

1. **ルールを無視するテーマを発明しない。** すべての paper L 帯、アクセント彩度上限、中立色味付け要件、フォント禁止、スロップテスト ゲートは持ち越される。自由は *組み合わせ* — ルールではない。
2. **再利用のためにテーマを保存しない。** Custom 実行は出力ごと。スキルは [`tokens.css`](../../site/css/tokens.css) に書き戻さない。永続テーマを欲するなら、ユーザーが custom パレットを tokens.css に貼って命名する。
3. **複数のフォローアップ質問をしない。** 1つの vibe 回答（＋任意のアンカー）で十分。Step 1 のオーディエンス／用途／トーン＋要件＋マクロ構造選択で既にモデルに 80 % のシグナル。
4. **多様化ルールを緩めない。** Custom エントリはカタログ エントリと同じ方法で3軸を宣言する。ローテーション ルールは両方で発火する、テーマ経路ブラインド。
5. **Step 5 プレビューをバイパスしない。** Custom パレット＋ペアリングはコード出力前に平文で表面化し、ユーザーが早期に軌道修正できる。

これらの5行のいずれかが曲がるなら、custom 出力は過剰発明。監査して軌道修正する。
