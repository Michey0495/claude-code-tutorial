## 05 · Workbench

フレーム付きの製品スクリーンショットが主役。ページは実際に使う様子のガイドツアーになる。マーケコピーは控えめで、「これで何ができるか」を見せる。

- **Heading:** 小さく機能的に。ワークベンチ型は声を張り上げない。
- **Body:** スクリーンショットブロックの連続。各ブロックに短いキャプションとインライン注釈の矢印。
- **Divider:** スクリーンショットのフレーム自体が区切り。セクションはギャップとフレームで分かれる。
- **Button:** 3枚目のスクリーンショット後にスティッキー下部のCTAバー（「Try it →」）。文脈が積み上がってから出す。
- **Image:** 中心要素。ブラウザ／デバイスフレームで囲んだ実際の製品キャプチャ、注釈矢印付き。
- **Reveal:** キャプションにタイプアンマスク。スクリーンショットは即時表示。

SaaS、開発者ツール、IDE拡張向け。製品を動かす姿を見せること自体が販売になる場面。

製品が概念的・サービス主導のときは避ける。WorkbenchはUIがあって成立する。

参照: Linear.app、Vercel、Raycast、Arc Browser。

**冒頭文サンプル**（言い回しではなく*具体性*を真似る。ページはユーザーを案内する）:
> *"$ streampipe parse access.log --filter status=5xx | jq"* — マーケ的主張ではなく実コマンドで開く
> *"Read anything that emits lines. Files, pipes, sockets, kubectl logs."* — 入力を列挙し、抽象化を拒む
> *"Open the trace, find the span, fix the regression. No glossary required."* — 具体的な動詞3つ、その後に拒絶

```html
<header class="lite">…</header>
<section class="screenshot-frame">
  <figure><img src="step-1.png" /><figcaption>Open a project.</figcaption></figure>
</section>
<section class="screenshot-frame">…</section>
<aside class="sticky-cta">Try it free →</aside>
```

---
