## 01 · Bento Grid

異なるサイズのモジュールブロックを不規則なグリッドに配置する。各ブロックは機能、引用、画像、スタットのいずれか。視覚的なリズムはサイズの変化から生まれる。カードの均一性ではない。

- **Heading:** 固定高さのヒーロー（フルビューポートではない）に中央配置のディスプレイ。
- **Body:** 非対称なグリッド。8〜15ブロックを混合スパン（1×1, 2×1, 1×2, 2×2）で配置。
- **Divider:** 一定の12〜24pxギャップ。罫線なし。グリッドそのものがリズムを生む。
- **Button:** ヒーローには輪郭付きチップ。タイルの内側CTAはタイポグラフィックリンク。
- **Image:** 各ブロック内にタイトクロップ。フルブリードにはしない。
- **Reveal:** なし、もしくはタイル入場時の控えめなワンショットフェード。

「見せたい小さな要素が多数ある」ブリーフ、機能ページ、SaaSランディング、複数の等価なエントリーポイントが必要な場面で選ぶ。

単一のヒーローアイデアがメッセージのときは避ける。Bentoは注意を分散するので、一案件一ページにはMarqueeかStat-Ledを使う。

参照: Appleのページ内セクション、Framerの機能ページ、Tailwind UIテンプレート。

**冒頭文サンプル**（言い回しではなく*具体性*を真似る）:
> *"Tracejam · v0.4 · for SREs. Distributed tracing that explains itself."* — 実在のオブザーバビリティツールからの言い換え
> *"Resend is the email API for developers. Send transactional and marketing emails at scale."* — resend.com
> *"The product development system for teams and agents."* — linear.app

```html
<header class="hero-fixed">…</header>
<section class="bento">
  <article class="cell span-2x2">…</article>  <!-- hero feature -->
  <article class="cell span-1x1">…</article>
  <article class="cell span-2x1">…</article>  <!-- wide stat -->
  <article class="cell span-1x2">…</article>  <!-- tall image -->
  <article class="cell span-1x1">…</article>
  <article class="cell span-1x1">…</article>
</section>
```

---
