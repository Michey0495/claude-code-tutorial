## 17 · Type Specimen

書体がデザインそのもの。カスタム書体がブランドの証拠となるファウンドリのトップ、もしくはデザインシステムのマーケティング。

- **Heading:** 書体を複数サイズで組み、何ができるかを示す。
- **Body:** 段階的なデモンストレーション。ディスプレイサイズ、本文サイズ、イタリック、言語カバレッジ、OpenType機能。
- **Divider:** 見本のあいだに中央配置のキャプションラベル。
- **Button:** フッターに輪郭付き「Buy」または「Use it」。
- **Image:** なし。タイポグラフィが画像。
- **Reveal:** 各見本ブロックの初回描画でタイプアンマスク。

タイプファウンドリ、カスタム書体が差別化要因のデザインシステム、フォント製品ページで選ぶ。

既製の書体を使うブランドでは避ける。Type Specimenは祝うに値する固有性を必要とする。

参照: Klim Type Foundry、Pangram Pangram、Geist Pixel発表ページ。

**冒頭文サンプル**（*具体性*を真似る。Type Specimenの冒頭はファウンドリの声。書体名、ウェイト、用途を名指す）:
> *"Reckless Display, set in 96 pt."* — 書体名とサイズだけを名指す
> *"Eight weights. Three optical sizes. One good italic."* — 3つの短いフレーズでシステムを数える
> *"A type system for editorial."* — 動詞を拒んだ単一名詞句

---
