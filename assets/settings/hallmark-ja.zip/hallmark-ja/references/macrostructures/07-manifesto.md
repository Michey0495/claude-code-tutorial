## 07 · Manifesto

論争的な大型タイポ。宣言のエネルギー。何を売るかより先に、何を信じるべきかを読者に伝える。政治ポスター的な美意識を帯びることが多い。

- **Heading:** 全角大文字のディスプレイをわずかに傾ける（`-2°`〜`-4°`）、または動詞にカラーブロックのハイライトを重ねる。
- **Body:** 1つの主張だけを担う短い段落。部屋の向こうから読める大きさ。
- **Divider:** セクション間にブリードカラーのブロック。ヘアラインは使わない。
- **Button:** アクセント色の超大型ソリッドブロック。ファーストビューよりずっと下に置く。
- **Image:** なし、もしくはセクションブリードとして1枚の高コントラストB&W写真。
- **Reveal:** セクション入場時の水平スイープ。

ブランドのリポジショニング告知、ミッション主導のインディー製品、デザインスタジオの信条ページで選ぶ。

トランザクショナルなページでは避ける。Manifestoが売るのは*同意*であってアクションではない。

参照: Linearのポジショニングページ、エージェンシーのリブランドサイト、政治キャンペーンのランディングページ。

**冒頭文サンプル**（*具体性*を真似る。マニフェストはコミットする、ぼかさない）:
> *"WE ARE A STUDIO. WE ARE NOT A PLATFORM."* — Meridian (test 04) — 否定で定義する、全角大文字、アクセント語1つ
> *"We design products that last twelve years. We do not design products that need replacing every two."* — 具体的な数字、対の宣言
> *"Lightness above weightiness, elevate everyone you encounter."* — craigmod.com — 一行の原則、説明不要

```html
<section class="manifesto bleed-ink">
  <h1 class="caps display-xxl">WE BELIEVE <em class="block-accent">DESIGN</em> IS SLOW.</h1>
</section>
<section class="bleed-paper">
  <p class="claim">It costs less than the rework you'll do without it.</p>
</section>
```

---
