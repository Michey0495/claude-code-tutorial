## 14 · Narrative Workflow

番号付きの段階がユーザーの利用過程を物語る。各セクションが1フェーズ（1.0 → 2.0 → 3.0 → 4.0）。ページはプロセスのタイムラインになる。

- **Heading:** 大きな段階ラベル（`1.0 INTAKE`、`2.0 PLAN`）。
- **Body:** 各段階に短い説明と小さな製品ビジュアル。
- **Divider:** 段階間に太い番号付きの罫。
- **Button:** 段階内のリンク。フッターにグローバルの「Start at stage 1 →」を1つ。
- **Image:** 段階ごとに小さな製品キャプチャ、しばしば注釈付き。
- **Reveal:** 段階がビューポートに入るとき水平スイープ。

明示的なワークフローを持つ製品で選ぶ。プロジェクト管理、デザインから開発のパイプライン、執筆ツール。

*一瞬*で完結するツールでは避ける。Narrative Workflowは実在の連続性を必要とする。

参照: Linearのhow-it-worksページ、一部のFigmaマーケティングページ。

**冒頭文サンプル**（*具体性*を真似る。Narrative Workflowの冒頭は段階ラベル。番号付き、宣言的、プロセス用語）:
> *"01 · sourdough overnight · 02 · score at dawn · 03 · pull at seven."* — 番号付き3段階、マーケコピーなし
> *"1.0 · parse · 2.0 · filter · 3.0 · route."* — Streampipe (test 02) — バージョン付き番号、具体的な動詞3つ
> *"I. We design products that last twelve years. II. A material is sustainable when someone, somewhere, can repair it."* — Meridian — ローマ数字＋宣言

---
