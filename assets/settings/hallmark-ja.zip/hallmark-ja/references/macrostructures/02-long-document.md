## 02 · Long Document

メモや手紙、日誌のように読ませる。マーケティング的な構造を持たない。インラインのセクション見出しを挟む連続した散文。ページは製品を語る*文学*になる。

- **Heading:** 本文と同じ流れに置く。セクション見出しはスモールキャップスや太字の短いフレーズとして段落から立ち上がる。
- **Body:** 1カラム、行間を広く取る（1.65以上）、行長は60〜65ch。
- **Divider:** 余白。空白そのものが区切り。強調したい箇所だけ中央に装飾を置く。
- **Button:** 段落内のタイポグラフィックリンク。独立ブロックにはしない。
- **Image:** インライン、本文幅にサイズを合わせる。フルブリード禁止。
- **Reveal:** なし。ページはただ*そこに*ある。

ケーススタディ、創業者のポスト、ミッションページ、思想で売る製品向け。ブリーフが「物語を語る」であり「機能を並べる」ではないとき。

決定的なアクションが1つだけ必要な場面では避ける。Long DocumentはCTAを隠すため、トランザクショナルなページには合わない。

参照: Frank Chimeroのサイト、destroytoday.com、製品ページに仮装した長文Substackエッセイ。

**冒頭文サンプル**（言い回しではなく*具体性*を真似る）:
> *"Saturday, 6:14 a.m. The dough went in at midnight."* — タイムスタンプで開く。ブランドが日常の一瞬として自己紹介する
> *"A monthly art publication featuring contributions by some of the most engaged thinkers working today."* — e-flux.com/journal
> *"We design everything for everyone."* — pentagram.com — 動詞を拒み、デザインを普遍的な実践として扱う

```html
<article class="prose">
  <p class="lede">…</p>
  <p>…</p>
  <h2 class="inline">A small heading.</h2>
  <p>…</p>
  <blockquote>…</blockquote>
  <p>… <a href="">read more →</a> …</p>
</article>
```

---
