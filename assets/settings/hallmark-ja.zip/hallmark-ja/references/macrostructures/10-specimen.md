## 10 · Specimen *(デフォルトからは外した)*

左マージンに番号付きラベル、巨大なセリフディスプレイ、非対称なカラムスパン、ヘアライン罫、タイポグラフィックのみのCTA、たっぷりの余白。エディトリアル／タイプファウンドリの空気。

- **Heading:** 左マージンの番号＋ラベル（`01 — HELLO.`）に大きなセリフのフレーズを並べる。
- **Body:** 非対称スパン。狭いラベルカラムと広いコンテンツカラム。
- **Divider:** セクション間にヘアライン罫。
- **Button:** 矢印付きのタイポグラフィックリンク（「Open your studio →」）。箱もフィルもなし。
- **Image:** なし、もしくは広い左マージンに手描きSVGのアクセント。
- **Reveal:** 初回ロード時にフェードアップのスタガー。

ブリーフが明示的にエディトリアル、タイプファウンドリ、ジャーナル、見本帳のときだけ選ぶ。それ以外は別を選ぶこと。

**デフォルト使用禁止。** ブリーフが曖昧でここに着地したらやり直す。

参照: タイプファウンドリのトップ（Klim、Pangram Pangram、Production Type）、一部のエディトリアルポートフォリオ。

**冒頭文サンプル**（*具体性*を真似る。Specimenの冒頭はファウンドリの声で、タイプを物質文化として扱う）:
> *"A thing well made."* — klim.co.nz — 動詞を拒み、デザインを素材として扱う
> *"Type, set with care."* — Hallmark Specimen — 3語、コロンを暗示
> *"Creative direction, design and type for culture since 2003."* — apracticeforeverydaylife.com — 年で接地、領域を名指す

```html
<header class="specimen">
  <p class="num-label">01 — HELLO.</p>
  <h1 class="serif-xxl">A quiet <em>instrument.</em></h1>
  <p class="lede narrow">…</p>
  <a class="link">Open your studio →</a>
</header>
```

---
