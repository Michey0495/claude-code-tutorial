## 15 · Split Studio

二連画（ディプティック）。主要なコンテンツブロックがすべて画面を二分する。片側にテキスト、もう片側に証拠。下に進むごとに左右の向きが入れ替わる。

- **Heading:** 半分の幅を取る。もう半分にはスクリーンショットか引用が入る。
- **Body:** 左テキスト／右画像 と 右テキスト／左画像 のモジュールを交互に並べる。
- **Divider:** 半分のあいだに明確なガター。罫線は使わない。
- **Button:** テキスト側の下に輪郭付きチップ。
- **Image:** 各行でテキストの反対側に配置する。
- **Reveal:** 反対側の半分が少しスタガーしてクロスフェードで入る。

SaaSの機能ページ、説明とコードを並べる開発ツール、すべての主張に視覚的な証拠を添えたい場面で選ぶ。

ナラティブ型や写真主体のブランドでは避ける。Splitは注意を二分するので、単一フォーカスが必要なページもある。

参照: Vercelの機能ページ、Stripe Sessionsのプログラムページ、多くの開発ツールのトップ。

**冒頭文サンプル**（*具体性*を真似る。Split Studioの冒頭はポジショニング文と証拠カラムを対にする）:
> *"A studio for what's next."* — イタリックディスプレイ＋右側にセレクテッドワークのカラム
> *"Print discipline, on screen."* — Hallmark Newsprint — マストヘッド風の2フレーズ見出し
> *"We design and build distinctive products for ambitious teams."* — 動詞（design and build）と対象（ambitious teams）を名指す

---
