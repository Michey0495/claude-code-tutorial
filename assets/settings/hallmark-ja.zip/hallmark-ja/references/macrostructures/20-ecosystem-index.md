## 20 · Ecosystem Index

複数のディスカバリーサーフェスを並べる。Featured／Latest／By category／By people など。プラットフォームの価値は宣言ではなく、立ち上がりとブラウジングにある。

- **Heading:** 短いポジショニング段落。ディスプレイタイポは使わない。
- **Body:** 横並びレールやグリッドを複数。それぞれがコンテンツの異なる切り口を表に出す。
- **Divider:** レール名を冠した帯。
- **Button:** 各レール末尾の「See more →」。グローバルCTAはほぼ置かない。
- **Image:** あらゆる場所にサムネイル。ページは画像が密。
- **Reveal:** なし。

コミュニティプラットフォーム、コンテンツマーケットプレイス、デザインアセットストア、UGC／キュレーション系カタログの表紙で選ぶ。

単一プロダクトのページでは避ける。Ecosystemは複数の対象を表に出す必要がある。

参照: Are.na、Figma Community、Behance。

**冒頭文サンプル**（*具体性*を真似る。Ecosystem Indexの冒頭はサーフェスラベル。日付や件数を伴う）:
> *"Featured · Latest · By category."* — 区切られた3つのディスカバリーサーフェス
> *"What's on this week · Editor's pick · The whole catalogue."* — 頻度、キュレーション、網羅を名指す
> *"A toolkit for assembling new worlds from the scraps of the old."* — are.na — テンプレを破る二段目のコピー

---
