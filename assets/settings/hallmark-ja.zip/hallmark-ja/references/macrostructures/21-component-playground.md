## 21 · Component Playground

インタラクティブな「コード＋プレビュー」ブロックがページの主役。各ブロックは対象をプレビューし、コピペ方法を示す。

- **Heading:** カテゴリラベル（`Buttons`、`Forms`、`Cards`、`Layouts`）。
- **Body:** プレビューとコードのブロックを交互に並べる。フレームワーク切替タブを付けることが多い。
- **Divider:** カテゴリ帯。例の間に水平の罫。
- **Button:** すべてのコードブロックに「Copy」ボタン（成功は無言で示す）。
- **Image:** なし。プレビュー自体が画像。
- **Reveal:** なし。

デザインシステム、コンポーネントライブラリ、コードスニペットサイト、フレームワークのドキュメントで選ぶ。

マーケティングページでは避ける。Playgroundはユーティリティであり、ピッチではない。

参照: shadcn/ui、Tailwind UI、Once UI、MUIのデモ、Framer Motionの例。

**冒頭文サンプル**（*具体性*を真似る。Component Playgroundの冒頭は具体的に、主張ではなく実例で開く）:
> *"Try it inline. Then take it home."* — 短い命令文2つ
> *"Every example is editable. Every output is real."* — 主張と証拠を対にする
> *"From `npm install` to your first chart in eight lines."* — ステップ数を名指し、具体的に約束する

---
