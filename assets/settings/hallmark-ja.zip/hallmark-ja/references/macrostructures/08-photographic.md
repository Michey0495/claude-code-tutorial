## 08 · Photographic

各ファーストビューを1枚の巨大な画像が支配する。テキストは小さな注釈であって見出しではない。*読む*より先に*見る*ことを促す設計。

- **Heading:** 画像の隅近くに小さなキャプション。中央配置のディスプレイにはしない。
- **Body:** フルブリードの画像帯と細いテキスト帯が交互に並ぶ。
- **Divider:** 画像の縁が区切り。罫線は使わない。
- **Button:** キャプションの下に押し込んだタイポグラフィックリンク。
- **Image:** 主役。フルブリード、端から端まで、1ファーストビューに1枚が多い。
- **Reveal:** 空間的なモーションなし。写真自体に仕事をさせる。

ファッション、ホスピタリティ、写真ポートフォリオ、ライフスタイルEC、製品が*体感*であるブランドで選ぶ。

実写素材がないときは避ける。AI生成のストックはマクロ構造を台無しにする。

参照: Aimé Leon Dore、Mr Porter editorial、Stüssyのルックブック。

**冒頭文サンプル**（*具体性*を真似る。写真のキャプションは日付、場所、図版番号でマーケコピーではない）:
> *"Plate 47 · scored before the proof."* — Maple Street Bread (test 03) — 番号、工程上の一瞬
> *"Spring, 2026."* — アトリエ風 — 2語、句点
> *"From the working archive."* — 写真に出所を与え、説明しない

```html
<section class="photo-fold">
  <img class="bleed" src="hero.jpg" />
  <p class="caption">Spring, 2026.</p>
</section>
<section class="text-fold">
  <p class="lede">…</p>
</section>
<section class="photo-fold">…</section>
```

---
