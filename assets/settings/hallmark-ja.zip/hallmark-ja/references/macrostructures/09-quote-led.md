## 09 · Quote-Led

ヒーローはアトリビューション付きのプルクオート。見出しはブランドの声ではなく借り物の信用。ページはソーシャルプルーフから始まる。

- **Heading:** イタリックのディスプレイで顧客の引用（36〜60px）、下にスモールキャップスのアトリビューション。
- **Body:** 追加のテスティモニアル、ケーススタディ、控えめな機能リストへ続く。
- **Divider:** 中央のクオートマーク字形、もしくはテスティモニアル間のem罫。
- **Button:** アトリビューションの下のタイポグラフィックリンク（「Read the full case study →」）。
- **Image:** アトリビューションの脇に小さなアバターか企業ロゴ。それ以外は使わない。
- **Reveal:** ファーストビュー内はなし。下のセクションはスタガーしてもよい。

強い顧客の声を持つB2B製品、エージェンシーのケーススタディページ、ファンドレイジングサイト、「自分と同じ人が使っている」が決め手になる場面で選ぶ。

実在のテスティモニアルがない新製品では避ける。偽の引用は調べられた瞬間に信頼を壊す。

参照: 多くのB2B SaaSランディング、エージェンシーのトップ、大学の開発ページ。

**冒頭文サンプル**（*具体性*を真似る。Quote-Ledは他者に語らせ、出典を明示する）:
> *"I started listening on a long bus ride. By the third episode I'd missed my stop, and I didn't mind."* — Tide (test 01) — 物語形、リスナーの引用
> *"Restraint, repeated, becomes a signature."* — Hallmark Atelier — 短く哲学的、スタジオの署名
> *"It told me the span that regressed, the deploy that caused it, and the engineer to ask. We rolled back in eight minutes."* — Tracejam風 — 数字で結果を名指す

```html
<section class="quote-hero">
  <blockquote class="display-italic">"…"</blockquote>
  <p class="attribution">— Name, Title, Company</p>
  <a class="link">Read the case →</a>
</section>
<section class="more-quotes">…</section>
```

---
