## 18 · Portfolio Grid

フィルタ可能なプロジェクトカード。作品が製品となるスタジオやデザイナーのトップ。

- **Heading:** グリッドの上に短いタグラインのみ。ディスプレイタイポは使わない。
- **Body:** プロジェクトカードのレスポンシブグリッド。全カード同サイズ、または控えめなサイズ差。
- **Divider:** グリッドの上にフィルターバー。内部の罫線はなし。
- **Button:** カード内の「View case study」のみ。グローバルCTAは置かない。
- **Image:** カードごとにサムネイル。
- **Reveal:** フィルタ切替時のカードフェード。

デザインスタジオ、エージェンシー、写真家ポートフォリオ、作品そのものが営業材料となるクリエイティブ業全般で選ぶ。

製品向けでは避ける。Portfolio Gridはサービス業の形をしている。

参照: Pentagram、14islands、Locomotive、Bureau Borsche。

**冒頭文サンプル**（*具体性*を真似る。Portfolio Gridの冒頭は量と時期を名指す）:
> *"Selected work · 2018 — 2026."* — 期間、メタ情報2文字分
> *"Twelve projects, six clients, two countries."* — 数を3つ、形容詞なし
> *"Work, indexed by year."* — 短いラベル。索引がサイト全体

---
