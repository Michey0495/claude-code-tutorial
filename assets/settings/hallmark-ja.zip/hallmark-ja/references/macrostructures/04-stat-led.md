## 04 · Stat-Led

ヒーローは巨大な数字。指標、件数、パーセンテージ。それ以降のすべてがその数字を補強・修飾する。データがナラティブになる。

- **Heading:** 数値ディスプレイ（8〜12rem）、tabular figures、下に小さな修飾行。
- **Body:** 各セクションが補強用のスタットやチャートで構成される。
- **Divider:** スタットブロック間にヘアラインの罫、tabular-numsを全面使用。
- **Button:** 修飾行の下に輪郭付きチップを揃える。
- **Image:** チャートと小さなデータビジュアライゼーション。写真は使わない。
- **Reveal:** ヒーロー数字にティッカー効果。0からターゲット値へ約500msでカウントアップ。

「数字で証明できる」ブリーフ向け。エンタープライズ／B2B、ファンドレイズプラットフォーム、気候やインパクトのページ。

防御可能な単一指標を持たない製品では避ける。偽の巨大数字は数字がないより悪い。

参照: Ahrefs、Stripe Sessionsのスタットブロック、気候インパクトダッシュボード、ベンチャーファームのポートフォリオページ。

**冒頭文サンプル**（言い回しではなく*具体性*を真似る。数字が仕事をする）:
> *"+47% · faster · decide late."* — イタリック数字、3語の修飾
> *"4 seconds. From the alert link to the slow span."* — 数字とその対価を組にする
> *"434 total posts. New CSS you feel like you could use today."* — adam argyle, nerdy.dev — 件数がページを実体に接地する

```html
<section class="stat-hero">
  <div class="figure tnum">99.97<span class="unit">%</span></div>
  <p class="qualifier">uptime across 2026, measured externally.</p>
  <a class="cta-outline">Read the report →</a>
</section>
<section class="supporting-stats">…</section>
```

---
