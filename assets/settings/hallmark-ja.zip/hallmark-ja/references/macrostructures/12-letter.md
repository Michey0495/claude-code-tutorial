## 12 · Letter

一人称、書き言葉、親密。挨拶（「Dear friend,」）で始まる。ファーストビューにボタンを置かない。創業者からの個人的な手紙のように読ませる。

- **Heading:** セリフのイタリックで呼びかけ（「Dear reader,」）、本文の1.5〜2倍サイズ。
- **Body:** 散文、1カラム、行長は狭く（50ch）、タイプライターで打ったような佇まい。
- **Divider:** 段落の間隔のみ。たまに`* * *`を挟む程度。
- **Button:** フッターに署名後のリンク（「p.s. join us if you'd like →」）。
- **Image:** サインのスキャン1点、もしくは静かなインライン写真程度。
- **Reveal:** なし。

パーソナルブランド、インディー創業者の告知、サバティカルやピボットの案内、寄付呼びかけで選ぶ。

トランザクショナルなコマースでは避ける。Letterは親密、コマースは機能的。

参照: Frank Chimeroのサイト、創業者のお別れポスト、インディーニュースレターの表紙。

**冒頭文サンプル**（*具体性*を真似る。Letterの冒頭は一人称の挨拶、日付、必要なら場所も）:
> *"Hello, I'm Anya."* — Anya (test 06) — 一行、名前、句点
> *"Saturday, 6:14 a.m. The dough went in at midnight."* — 瞬間で開き、そこから説明する
> *"Hey there. This page is soft because the surface should be soft."* — Hallmark Plume — 口語の挨拶＋原則

---
