## 06 · Conversational FAQ

太字の問いと簡潔な答え。製品との誠実なインタビューのように読ませる。各Q/Aはアコーディオン形式が多い。

- **Heading:** 各セクションが*問い*そのもの。`?`で終わる短く直截なフレーズ。
- **Body:** 問いのすぐ下に2〜4段落の短い回答。
- **Divider:** Q/Aペア間に細い罫、または罫を引かず紙色を切り替える。
- **Button:** 回答内のタイポグラフィックリンク（「Read the full policy →」）。フッターに輪郭付きCTAを1つ。
- **Image:** ほぼなし。長い回答に1つダイアグラムを置く程度。テキスト中心。
- **Reveal:** 読み込み時はなし。アコーディオン展開は`grid-template-rows: 0fr → 1fr`に200ms `--ease-out`。

価格セクション付近、懐疑にぶつかる製品、教育や規制業界で選ぶ。

*主役*ページとしては避ける。FAQはページの冒頭を担う別のマクロ構造と組み合わせるのが普通。

参照: 多くのSaaS価格ページ、Casper、Substackヘルプページ。

**冒頭文サンプル**（*具体性*を真似る。問いは本物の問い、答えは短く具体）:
> *"What is this for? — A single-binary CLI for parsing log streams from stdin."* — フォームファクタと入力を名指す
> *"How is this different from X? — It's about time."* — cron.com — 重みのあるフレーズで斜めから答える
> *"Who built this? — Three of us, in Lisbon, since 2014."* — 日付＋場所＋人数、マーケコピーゼロ

```html
<section class="faq">
  <details>
    <summary><h2>How long does setup take?</h2></summary>
    <div class="answer">…</div>
  </details>
  <details>…</details>
</section>
```

---
