# プレビュー例ワークドサンプル

Step 5 プレビューブロックのサンプル4種。モデルが模倣するための題材で、マクロ構造ごとに変化を付けている。このファイルは、変則的なマクロ構造やカスタムテーマを選択し `SKILL.md § 5. Preview` の箇条書き仕様だけでは足場が足りないときにだけ読み込む。多くのビルドではこのファイルを読む必要はない。

---

*Long Document（編集色、モーションカット）:*
> **Hallmark · v1.0.0**
>
> - **Macrostructure** · Long Document
> - **Theme** · Linen（クールスレートペーパー · スチールブルー アクセント · ジオメトリックサンス）
> - **Enrichment** · Tier-B 手組み SVG（60行のコーヒー豆＋ `@property --rise` 6秒のブリージングループ）
> - **Sections** · マストヘッド · レター · 3つのノート · ビジット · コロフォン
> - **Motion** · 豆だけのブリージングループ（`prefers-reduced-motion` を尊重）
> - **Slop test** · 69 / 69 ✓
> - **Diversification** · プロジェクト初回

*Bento Grid（SaaS、モーション有効）:*
> **Hallmark · v1.0.0**
>
> - **Macrostructure** · Bento Grid
> - **Theme** · Linen（クールスレートペーパー · スチールブルー アクセント · ジオメトリックサンス）
> - **Enrichment** · E1 クリップエッジデモ動画、Tier-A CSSアートのトレースウォーターフォール
> - **Sections** · ヒーロー · 6タイルの Bento（スタット · スパークライン · クォート · コード · インテグレーション · スポットライト） · インデックスフッター
> - **Motion** · カウンター · プライシングリフト · インテグレーション帯の CSS マーキー
> - **Slop test** · 69 / 69 ✓
> - **Diversification** · Plain と紙の色相（ライトクール vs 純白）+ アクセント（インディゴ vs インクブルー）で差異化

*Manifesto（宣言調、エンリッチメントなし）:*
> **Hallmark · v1.0.0**
>
> - **Macrostructure** · Manifesto
> - **Theme** · Manifesto（ダーク · Inter Tight 900 · 単色レッドのブリード）
> - **Enrichment** · なし（タイポグラフィのみ。声がブランドを担う）
> - **Sections** · マストヘッド · タイトル · 5つの宣言 · ブリードバンド · 拒絶するもの · ワーキングルール · プラクティス · 読書 · コロフォン
> - **Motion** · なし。タイポグラフィのみ
> - **Slop test** · 69 / 69 ✓
> - **Diversification** · Linen と紙帯（ダーク vs ライト）+ ディスプレイスタイル（display-heavy vs geometric-sans）で差異化

*Custom（Coffeebox アーカイブカフェ）:*
> **Hallmark · v1.0.0**
>
> - **Macrostructure** · Long Document
> - **Theme** · custom（vibe: "archival warmth, hand-set, no varnish" · paper oklch(94% 0.020 65) · accent oklch(58% 0.16 35) テラコッタ · Fraunces italic display + Source Serif 4 body）
> - **Enrichment** · Tier-A ピュア CSS コーヒー豆（60行 SVG、ブリージングループは任意）
> - **Sections** · マストヘッド · レター · 3つのノート · ビジット · コロフォン
> - **Motion** · 豆のブリージングループ（reduced-motion フォールバック付き）
> - **Slop test** · 69 / 69 ✓
> - **Diversification** · カスタム軸: light / italic-serif / chromatic-terracotta。直前のカタログ Linen とはアクセント色相＋ディスプレイスタイルで差異化
