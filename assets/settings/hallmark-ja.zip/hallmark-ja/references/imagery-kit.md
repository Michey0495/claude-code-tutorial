# イメージリーキット — キュレーション済みの抽象アセット、ホスト済み、即利用可能

要件が非写真の画像を許容するときに Hallmark 出力が引ける、事前生成済みの抽象／装飾画像の小さなセット。キットは下記にある。

```
https://www.usehallmark.com/imagery/<category>/<file>
```

スキルはバイナリは同梱しない。マニフェストを同梱する。参照は絶対 URL。アセットが欠落（404）したら、エラーを出さず [`assets.md` § Placeholder strategy](assets.md) のソースカノン #2（手組み SVG）にフォールバックする。

**存在理由。** v0.9.0 の水彩スプリンクルは emit ごとに生成され、一貫性がなかった。キットは同じ美学を取り戻すが、離散的・差替え可能・意図的に構成されたアセットとして提供する。シニアフロントエンドエンジニアのように構成する。テキストの背後に重ねた透過 PNG、わざと中心からずらした位置、意図的に大きく、必要なら mix-blend-mode。「見出しの上に抽象グラデーション」ではない。それが AI のデフォルト。

---

## カテゴリ

| カテゴリ | 内容 | 形式 | 使用例 |
| --- | --- | --- | --- |
| **watercolor** | 全幅でソフトエッジの絵画的フィールド。パレットファミリーごとに暖色＋寒色のバリアント。 | WebP | セクション背景アクセント；ヒーロー半分フラッド；クォート背後の wash。 |
| **transparent** | 透明背景の有機的ブロブ／ブラシストローク／様式化マーク。 | PNG | レイヤード ヒーロー構成（大きく、中心からずらし、テキストの背後）。マスタークラスの一手。 |
| **ornament** | 手描きの小さなスタンプ、プレート、ローマ数字、装飾の華飾。 | SVG | クォートの傍；セクションラベル余白；レターのクロージング。 |
| **texture** | 控えめな紙、織り、リソドット、クロスハッチのフィールド。タイル可能。 | WebP | `mix-blend-mode: multiply` で本文グレイン；セクションディバイダーの帯。 |
| **silhouette** | 抽象のボトル／箱／デバイス／本／マグ／カード形状。 | PNG | ユーザーが写真を上げる前の空のプロダクトスロット；比較行。 |
| **pattern** | 布／紙／印刷物のように読む反復モチーフ。 | WebP | セクション帯のテクスチャ；装飾テキスト背後の全幅塗り。 |

**命名:** `<category>-<palette-family>-<variant>.<ext>` — 例 `watercolor-warm-01.webp`、`transparent-brush-cool-03.png`、`ornament-stamp-01.svg`、`texture-grain-paper-02.webp`。パレットファミリー: `warm` · `cool` · `neutral` · `chromatic`。

---

## マニフェスト（生成パスが出荷されるまでのプレースホルダ）

画像が `site/public/imagery/<category>/` に到着したら、ここにキー／値カタログとして載せる。

```
watercolor-warm-01.webp     1600×900   warm orange · cream paper      hero half-flood, atmospheric
watercolor-cool-01.webp     1600×900   cool blue · greyscale          quote-behind wash
transparent-brush-warm-01   1200×1200  burnt orange brushstroke       layered hero, off-centre
transparent-blob-cool-01    1200×1200  cobalt organic shape           layered hero, behind headline
ornament-stamp-01.svg       inline     ink-only stamp w/ numeral      label-gutter, letter close
texture-grain-paper-01      512×512    cream paper grain (tileable)   body grain, blend-multiply
silhouette-bottle-01.png    600×900    abstract bottle, transparent   empty product slot
silhouette-card-01.png      900×600    abstract product card          comparison row
pattern-cross-warm-01       400×400    cross-hatch warm (tileable)    section-band texture
```

スキルはアクティブテーマのパレットファミリー＋要件のトーンに合わせてアセットを選び、絶対 URL で参照する。選択ロジックは [SKILL.md](../SKILL.md) Step 4 にある。マニフェストを目視し、最も近いものを選び、ファイルが 404 ならフォールバックする。

---

## 使用パターン — シニアエンジニアの構成

### レイヤード ヒーロー構成（マスタークラスの一手）

ヒーローテキストの背後に透過抽象オブジェクト。思っているより画像を大きくする。それが意図的に感じさせる鍵。装飾ではない。

```css
.hero { position: relative; isolation: isolate; }

.hero__art {
  position: absolute;
  top: 50%;
  right: -10%;
  transform: translateY(-50%);
  width: clamp(60%, 80vh, 1400px);
  height: auto;
  z-index: 0;
  pointer-events: none;
  /* 任意の暖かみ: */
  mix-blend-mode: multiply;
  opacity: 0.85;
}

.hero__art--bias-left  { right: auto; left: -10%; }

.hero > * { position: relative; z-index: 1; }
```

片側（左か右、中央にはしない）に寄せる。テキストは `z-index: 1`、アートは `z-index: 0`。モバイルで検証する。アートは 320 px で見出しを避けるためにスケールダウンかシフトが必要な場合がある。

### セクション背景の wash

水彩ファイルを全幅セクションアクセントに。1ページ1セクションのみ。グローバルにしない。

```css
.section--wash { position: relative; isolation: isolate; }
.section--wash::before {
  content: "";
  position: absolute;
  inset: 0;
  background: url("https://www.usehallmark.com/imagery/watercolor/watercolor-warm-01.webp") center / cover no-repeat;
  opacity: 0.6;
  z-index: -1;
  pointer-events: none;
}
```

### 装飾

クォートの傍やセクションラベル余白にインライン装飾。小さく。ボーダーなし、シャドウなし、アニメーションなし。

```html
<p class="section-label">
  <span class="num">02</span>
  <img class="section-label__ornament" src="…/imagery/ornament/ornament-stamp-01.svg" alt="" aria-hidden="true" />
  <span>Examples</span>
</p>
```

```css
.section-label__ornament { width: 1.5em; height: auto; vertical-align: middle; }
```

### テクスチャ オーバーレイ

ベタ塗り色の上にグレイン。常に opacity を `0.15` で上限する。

```css
.texture-grain {
  background-image: url("…/imagery/texture/texture-grain-paper-01.webp"), var(--paper-fill);
  background-size: 256px 256px, cover;
  background-blend-mode: multiply;
  opacity: 1; /* グレインテクスチャはソースアセット側で 0.15 */
}
```

### 空状態

データが入る前のスロットに汎用シルエット。グレースケール調、開発者に対する「実写に置き換える」ヒント（HTML コメント）を可視に。

```html
<!-- TODO: 実物のプロダクト写真に置換、目標サイズ: 600×900 -->
<picture class="product-card__photo product-card__photo--empty">
  <img src="…/imagery/silhouette/silhouette-bottle-01.png" alt="Hand-poured ceramic vessel, studio lighting" />
</picture>
```

---

## アンチパターン

- **キット画像を文字通りの被写体にしない。** 抽象ボトルは実物のコーヒーショップ ヒーローの代替に *ならない*。それらは写真プレースホルダ（Picsum / Unsplash）を要する。キットは雰囲気／構成／装飾用であり、被写体の代替ではない。
- **3つ以上のキット要素を1ページに重ねない。** 抑制。ヒーローの透過オブジェクト1つ＋後段セクションの wash 1つが上限。
- **同じ水彩 wash を複数セクションに適用しない。** セクション アクセントであり、グローバル トリートメントではない。
- **モダンミニマル ジャンル（Stripe / Linear / ElevenLabs 系）でキット画像を使わない。** あのジャンルの要点は装飾画像の不在。
- **レイヤード ヒーロー アートを中央に置かない。** テキスト背後の中央は AI のデフォルト。片側に寄せて軸を外す。
- **アクティブな paper でテストせずに mix-blend-mode を使わない。** 暗キャンバスで `multiply` は反転、明 paper で `screen` は色あせ。テーマごとに目視で確認する。

---

## 生成パイプライン（帯域外、ワンタイム）

キットはパレットファミリーごとに1回生成し、後処理してマーケティングサイトの public フォルダにコミットする。

```
site/public/imagery/
  ├── watercolor/        ~6 files × 4 palette families = 24 WebPs
  ├── transparent/       ~6 files × 4 palette families = 24 PNGs
  ├── ornament/          ~8 SVGs (palette-agnostic, use currentColor)
  ├── texture/           ~6 tile-able WebPs
  ├── silhouette/        ~6 PNGs (palette-agnostic, transparent)
  └── pattern/           ~6 tile-able WebPs
```

**ツール。** Nanobanana 2 / Recraft V4 に参照画像を併用。カテゴリ別のプロンプトシードリストは各ファイルディレクトリの先頭の `prompts.md` に置く（1行プロンプト、再現性のため結果をシードでピン留め）。

**後処理。** トリム、必要に応じて透過背景、Hallmark の OKLCH パレットトークンに対する色補正、サイズのため WebP 保存、アルファが要るときは PNG。装飾はインライン SVG として `currentColor` を継承させる。

**総ターゲット重量。** 全カテゴリで ≤ 5 MB。個別ファイル ≤ 200 KB。可逆が要らない限り WebP q=80（装飾 → SVG、透過 → PNG ＋ `pngquant`）。

**再生成。** キットは更新可能なバッチとして扱う。一回きりではない。パレットカタログが変わったら（新テーマ、新アクセント色相）、関連パレットファミリーを再生成する。上記マニフェストは仕様。アセットは成果物。
