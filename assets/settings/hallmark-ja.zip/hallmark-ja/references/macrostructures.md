# マクロ構造

名前付きのランディングページ形状 21種。**コードを書く前に1つ選ぶ。** 各マクロ構造は完全な指紋。見出し配置、本文構成、ディバイダー、ボタンの声、画像の扱い、リビールパターンを1つの選択肢にまとめている。マクロ構造を選ぶ方が、`structure.md` から6軸を独立に選ぶより速く、エラーが少なく、*構造的にカテゴリ別の多様性*を生む。

Specimen マクロ構造（左マージン番号付きラベル＋巨大セリフ＋非対称スパン＋タイポグラフィのみの CTA）はこの21の1つ。**これはもうデフォルトではない。** 要件が明確に編集色／foundry 寄りである、もしくはユーザーが名指ししたときだけ手を伸ばす。

## 多様化ルール（必須）

選択前に、対象のコードベースに既存 CSS の `/* Hallmark · macrostructure: <name> · ... */` コメントを確認する。あれば、**選択は別のマクロ構造でなければならない。** 同じプロジェクト内で連続する Hallmark 出力2件が同じマクロ構造を共有してはならない。

要件が曖昧（テーマもトーンも無し）なら、11〜21に行く前に *最初の10* から選ぶ。最初の10は意図的に最強の非 Specimen 形状群で、約80%の要件をカバーする。

## ヒーローのポリッシュパターン

ヒーロー系マクロ構造（Marquee Hero · Stat-Led · Quote-Led · Letter · Photographic · Clipped）は、ベース形状の上に任意の **ポリッシュパターン** を1つ載せられる。HP1 Vertical-rail · HP2 Marquee-overflow · HP3 Cursor-spotlight · HP4 Decorative-numeral。ポリッシュパターンは *構造的*（レイアウト／タイプ／モーション）であり、装飾ではない。ヒーローのマクロ構造を置き換えずに共存する。各パターンの位置付けと適合は [`hero-enrichment.md`](hero-enrichment.md) § Hero shape polish を参照。

ヒーローはエンリッチメント原型（E1–E8）1つとポリッシュパターン（HP1–HP4）1つを同時に持てる。ただしポリッシュパターン2つの同居は不可。判断順序: マクロ構造 → エンリッチメントの要否 → ポリッシュの要否 → 余白規律。

## ナビとフッターの声

各マクロ構造は **ナビ原型**（N1–N9）と **フッター原型**（Ft1–Ft8）も示唆する。デフォルトは [`component-cookbook.md`](component-cookbook.md) § Navigation と § Footers のルーティング表にある。ヒーローのマクロ構造を選ぶときはナビとフッターも同時に選ぶ。これらはページ形状の一部であり、任意の装飾ではない。

---

## 21マクロ構造 — インデックス

**1つ選ぶ。その1つのファイルだけを** `references/macrostructures/` から読み込む。カタログ全体は読み込まない。スラッグは安定で、多様化ルールは `/* Hallmark · macrostructure: <name> · ... */` スタンプの `<name>` を読む。

- **01 · Bento Grid** — サイズが異なるモジュールブロックを不揃いなグリッドで配置。各ブロックはフィーチャー、引用、画像、スタット。視覚リズムはカードの均一性ではなくサイズの変化から生まれる。[`macrostructures/01-bento-grid.md`](macrostructures/01-bento-grid.md)
- **02 · Long Document** — メモ、手紙、日記のように読める。マーケティング構造はなし。インライン見出しを挟む連続散文。ページがプロダクトについての *literature* になる。[`macrostructures/02-long-document.md`](macrostructures/02-long-document.md)
- **03 · Marquee Hero** — ヒーローこそファーストビューのページ。大胆な一文か視覚要素1つがビューポートを埋める。サブヘッドなし、ファーストビューに CTA なし。ファーストビュー以降はページが別物（リスト、グリッド、散文）に変わる。[`macrostructures/03-marquee-hero.md`](macrostructures/03-marquee-hero.md)
- **04 · Stat-Led** — ヒーローは巨大な数字。メトリック、カウント、パーセント。続くものすべてがそれを支えるか修飾する。データがナラティブ。[`macrostructures/04-stat-led.md`](macrostructures/04-stat-led.md)
- **05 · Workbench** — フレーム付きのプロダクトスクリーンショットが主役。使用中のアプリのガイドツアー。マーケコピーは少なく、「これで何ができるか」を見せる。[`macrostructures/05-workbench.md`](macrostructures/05-workbench.md)
- **06 · Conversational FAQ** — 太字の質問、短い回答。プロダクトへの誠実なインタビューのように読める。Q/A をアコーディオンにすることが多い。[`macrostructures/06-conversational-faq.md`](macrostructures/06-conversational-faq.md)
- **07 · Manifesto** — 論争的な大きい文字。宣言のエネルギー。何を買うべきかを語る前に何を信じるべきかを告げる。政治ポスター的な美学が多い。[`macrostructures/07-manifesto.md`](macrostructures/07-manifesto.md)
- **08 · Photographic** — 各ファーストビューを巨大な単一画像が支配する。テキストは見出しではなく小さな注釈。デザインは *読む* より先に *見る* と告げる。[`macrostructures/08-photographic.md`](macrostructures/08-photographic.md)
- **09 · Quote-Led** — ヒーローは出典付きのプルクォート。見出しはブランドの声ではなく借りた信頼性。ページは社会的証明から始まる。[`macrostructures/09-quote-led.md`](macrostructures/09-quote-led.md)
- **10 · Specimen** — 番号付きの左マージンラベル、巨大セリフディスプレイ、非対称カラムスパン、ヘアラインルール、タイポグラフィのみの CTA、ゆったりした余白。編集色／type-foundry のエネルギー。[`macrostructures/10-specimen.md`](macrostructures/10-specimen.md)
- **11 · Catalogue** — 同種のバリエーション（書体、配色、SKU）を均一なグリッドで並べる。在庫の視覚インデックス。[`macrostructures/11-catalogue.md`](macrostructures/11-catalogue.md)
- **12 · Letter** — 一人称、書かれたもの、親密。挨拶で始まる（"Dear friend,"）。ファーストビューにボタンなし。創業者の私信のように読める。[`macrostructures/12-letter.md`](macrostructures/12-letter.md)
- **13 · Index-First** — ページ自体がリンクのリスト。ヒーロー画像なし、ナラティブな流れなし。デザインとしての純粋なナビゲーション。[`macrostructures/13-index-first.md`](macrostructures/13-index-first.md)
- **14 · Narrative Workflow** — 番号付きのステージで、プロダクトの使い方を時系列で語る。各セクションがフェーズ（1.0 → 2.0 → 3.0 → 4.0）。ページがプロセスタイムライン。[`macrostructures/14-narrative-workflow.md`](macrostructures/14-narrative-workflow.md)
- **15 · Split Studio** — ディプティック。主要なコンテンツブロックすべてが画面を分割する。片側にテキスト、もう片側に証拠。ペアの向きはページを下るごとに交互。[`macrostructures/15-split-studio.md`](macrostructures/15-split-studio.md)
- **16 · Feature Stack** — 固定の左ペイン（ラベル／説明）＋スクロール同期の右ペイン（関連詳細のスクリーンショットが循環）。映画的なペース。[`macrostructures/16-feature-stack.md`](macrostructures/16-feature-stack.md)
- **17 · Type Specimen** — 書体こそデザイン。foundry のホームページや、カスタム書体がブランドの証拠となるデザインシステムのマーケティング。[`macrostructures/17-type-specimen.md`](macrostructures/17-type-specimen.md)
- **18 · Portfolio Grid** — フィルタ可能なプロジェクトカード。スタジオやデザイナーのホームページで、仕事そのものがプロダクト。[`macrostructures/18-portfolio-grid.md`](macrostructures/18-portfolio-grid.md)
- **19 · Map / Diagram** — 大きな空間ダイアグラム1枚がページを構造化する。フローチャート、フロアプラン、ネットワークグラフ、システムマップ。情報を *空間的* に配置する。直線的ではない。[`macrostructures/19-map-diagram.md`](macrostructures/19-map-diagram.md)
- **20 · Ecosystem Index** — 複数の発見面（featured / latest / by category / by people）。プラットフォームの価値は宣言ではなく創発と回遊にある。[`macrostructures/20-ecosystem-index.md`](macrostructures/20-ecosystem-index.md)
- **21 · Component Playground** — インタラクティブなコード＋プレビュー ブロックが主役。各ブロックが何かをプレビューし、コピペ方法を見せる。[`macrostructures/21-component-playground.md`](macrostructures/21-component-playground.md)

---

## SaaS ページのシーケンス

マクロ構造が **Bento Grid · Stat-Led · Workbench · Marquee Hero** で、要件が B2B SaaS マーケティングページのとき、おおよそ次の順で各セクションを出す。必須はないが、2つ以上飛ばすと「ページが未完成」と読まれる。

1. **Hero** — マクロ構造別（Bento、Stat、Workbench、Marquee）。CTA 2つ（一次アクション＋二次「Talk to sales」）。
2. **社会的証明／ロゴウォール** — 顧客ロゴ6〜8枚、モノクロ（[`assets.md` § Logo walls](assets.md) 参照）。
3. **フィーチャー** — フィーチャーカード3〜6枚。マクロ構造で異なる（Bento はグリッド内にインライン、Stat-Led は通常サポートスタットグリッドの後）。
4. **テスティモニアル** — クォートカード2〜4枚。プルクォート＋氏名＋役職＋会社。写真は任意。「私たちは [product] を毎日使っています」は避ける。ユースケースに具体的な引用を（「Foundry のおかげで5週間で SOC2 を取得できた。ポリシーは1つも自分たちで書かなかった。」）。
5. **プライシング** — 比較表で2〜3層。各層のフィーチャーチェックリスト。中段の層に推奨バッジ。実価格を見せる。全層が「営業に連絡」だと、ブランドが買い手を信用していないサイン。
6. **FAQ** — 質問5〜10。Conversational FAQ 原型がここに合う（マクロ構造9参照）。
7. **最終 CTA ストリップ** — ボタン1つ＋一文のプロンプト。
8. **フッター** — インデックス型かタブ型、テーマに合わせて。

各セクション遷移はテーマに合わせた縦余白を使う。主要セクション間は最低でも `--space-3xl`。セクションを「行」に分割してサブルールを引かない。セクションの切れ目こそ視覚リズム。

**SaaS セクションの声のルール:**

- **プライシング:** 実価格を見せる。全層を「Contact us」にするのは、買い手を信用していないサイン。
- **テスティモニアル:** 引用者の役職 *と* 会社を入れる。抽象的な「Engineering Manager」はスロップ。実プロダクトなら実名。プレースホルダなら妥当な名前を。ただし "Jane Doe" / "John Smith" は禁止（ゲート20）。
- **FAQ:** 営業資料ではなく、人として答える。「はい — Stripe と Adyen は標準で対応しています」は「弊社プラットフォームは主要決済プロバイダと連携します」より良い。
- **CTA ストリップ:** ボタン1つ。2つではない。反復こそ行動喚起。

このシーケンスはコピペ用テンプレ **ではない**。*何があるべきか* のレシピ。マクロ構造が *各セクションの見た目* を決める。Bento Grid のページはグリッド内でフィーチャーと証拠を織り交ぜる。Stat-Led は縦に並べる。Marquee Hero はマーキー自体が社会的証明の役割を担う。

非 SaaS（Editorial、Manifesto、Letter、Long Document、Quote-Led）にはこのシーケンスは **適用されない**。パン屋にプライシング層比較は不要。

---

## 選び方

1. **要件を読む。** 1つのマクロ構造を強くシグナルする語に注目（「データ多め」「ストーリーを語る」「リンクのリスト」「小さなフィーチャーがたくさん」「個人的な手紙」）。
2. **コードベースを確認** して既存の `/* Hallmark · macrostructure: <name> · ... */` スタンプの有無を見る。あればその名前は候補から外す。
3. **要件のエネルギーをマクロ構造にマッチさせる** には「こういうときに手を伸ばす」行を使う。多くの要件は2〜4パターンに合致する。このユーザーの過去出力からカテゴリ的に最も遠いものを選ぶ。
4. コードを書く *前に* 平文で **選択を宣言する**。「Macrostructure: Bento Grid.」。それから CSS をスタンプ付きで書き始める。
5. 本当に迷うなら、*異なるカテゴリ* から3つ提示し（例: Bento + Long Document + Manifesto）、ユーザーに選ばせる。

目的は新奇性そのものではない。2つの異なる要件で Hallmark が作る2ページが *同じテンプレートの色違いではなく、別のサイトに見える* こと。
