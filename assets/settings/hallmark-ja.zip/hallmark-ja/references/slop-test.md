# スロップテスト — 60ゲート＋出力前セルフレビュー

出力を返す前にこのリストを通す。全項目が **no** であること。Step 5 プレビューブロックの `Slop test` 行を、今回の実行結果に合わせて更新する。

一部のゲートは **universal**（全ジャンルに適用）、一部は **genre-scoped**（アクティブジャンルが editorial、atmospheric、modern-minimal、playful のときのみ適用）。ジャンルの例外はインラインで注記する。ジャンル注記のないゲートは universal として扱う。

---

## 出力前セルフレビュー（6軸）

ゲートリスト *の前に* 実行する。後ではない。計画している出力を各軸 1〜5 で採点する。**どれかの軸で 3 未満なら、ゲート掃引の前にリビジョン パスを発動する**。既知の弱点を60ゲートのレビューに持ち込まない。

2パスが普通。3パスは、要件が間違っているサインであり、デザインの問題ではない。要件を読み直す。

| # | 軸 | 何を採点しているか |
|---|---|---|
| **A** | **哲学** | 明確な *why* — ページが取っている立場 — があるか。それともただのレイアウトか。 |
| **B** | **階層** | 読者が2秒で何が主、副、三次かを判別できるか。それともすべて同じウェイトか。 |
| **C** | **実装** | 細部（ルール太さ、アクセント占有率、テキスト折り返し、フォーカスリング、コントラスト）が仕様通りか。骨格が正しくてもスロッピーさがないか。 |
| **D** | **具体性** | *この要件* に見えるか。それとも誰のものでも通る「ページ」に見えるか。 |
| **E** | **抑制** | 役立っていないものを全て削除したか。装飾、冗長、パディングのためのパディング。 |
| **F** | **多様性** | この出力は同じプロジェクトで以前に出した Hallmark 出力と構造の指紋を共有しているか。視覚距離ではなく構造距離で採点する。色違いは多様性に数えない。 |

6つのスコアをファイル冒頭の1行スタンプ コメントに記録: `/* Hallmark · pre-emit critique: P5 H4 E5 S4 R5 V5 */`。以降の実行はこれを見て同じ弱点の反復を避ける。

---

## 視覚

1. ディスプレイフォントが Inter、Roboto、Open Sans、Poppins、Lato、システムデフォルトのいずれかか。
2. 紫から青（あるいはシアン→マゼンタ）のグラデーションがどこかにあるか。*ジャンル注記: atmospheric は背景にのみラジアル グラデーションを許可。テキストやピル ボタンには不可。*
3. アイコン上タイルの等幅3カラム カード グリッドがあるか。
4. カードがカードに入れ子になっているか。
5. `background-clip: text` のグラデーション見出しがあるか（universal、どのジャンルでもグラデーションテキスト不可）。
6. 太い色付き左右サイドストライプ ボーダーを使うカードがあるか。
7. ヒーローが `min-height: 100vh` ですべて中央寄せか。*ジャンル注記: atmospheric と playful は、キャンバス自体がデザインなら中央寄せヒーローを許可（Suno 風）。*
8. 純粋な `#000` または純粋な `#fff` をベース色に使っているか。*ジャンル注記: modern-minimal は純粋な `#fff` paper を許可（Stripe / ElevenLabs 系）。*

## 構造

9. 直前に作ったページと *同じ* 構造の指紋を使っているか。（ヒーロー → 3 フィーチャー → CTA → フッター は AI 構造テンプレ、却下）
10. セクションが等しい余白だけで区切られ、ルール、装飾、色シフトが無く、リズムが全セクション同一か。

## マイクロインタラクション

11. `transition-all`（または `transition: all`）をどこかで使っているか。プロパティを指定。
12. `hover:scale-105`（または任意の均一なホバースケール）が無関係な複数要素に適用されているか。
13. バウンシー／オーバーシュート イージング（`cubic-bezier(0.34, 1.56, ...)` 等）が UI 状態変化（ボタン、モーダル、ツールチップ）に使われているか。オーバーシュートは物理的インタラクションのみ。
14. 1つの要素が同時に *2つ以上* のホバー効果（translate ＋ scale ＋ shadow ＋ color ＋ rotate）を持っているか。
15. `width`、`height`、`top`、`left`、`margin`、`padding` のいずれかをアニメーションしているか。
16. フォーカスリングがフェードインしてくるか。フォーカスリングは即座に現れる。キーボードユーザーには即時のインジケータが要る。
17. ユーザーが既に効果を見られているアクションに対する祝祭的成功トーストがあるか。サイレント成功は taste、トーストは失敗と不可視効果のためのもの。
18. ツールチップのホバー遅延とフォーカス遅延が等しいか。ホバーは 800–1000 ms 遅延、フォーカスは 0 ms。
19. 自動回転コンテンツ（カルーセル、バナー、スタット）が hover/focus でのポーズに対応していないか（WCAG 2.2.2）。
20. プレースホルダ名 "Jane Doe / John Smith" やスタートアップ常套句（Acme、Nexus、Seamless、Unleash）があるか。

## 多様性

21. CSS 冒頭の `/* Hallmark · macrostructure: <name> · ... */` スタンプが欠落しているか。必ず存在すること。
22. 選んだマクロ構造が、このプロジェクトの過去の Hallmark 出力スタンプと同じか。ファイルシステムを読み、既存スタンプがあれば異なる選択にする。
23. 要件が明示的に editorial / foundry / specimen エネルギーを呼んでいないのに **Specimen** マクロ構造（番号付き左マージン ラベル＋巨大セリフ＋非対称スパン＋タイポグラフィのみ CTA）にデフォルトしたか（Specimen のフォールスルー は禁止）。*ジャンル注記: atmospheric、modern-minimal、playful は決して Specimen にデフォルトしない。editorial のみ、かつ要件が示唆したときのみ。*

## 実装ゲート

24. 中立色／サーフェス色のいずれかが `oklch(... 0 ...)`（彩度0）か。純グレーは平板に読まれる。すべての中立をアンカー色相に向けて色味を付ける。最低 0.005 彩度。*ジャンル注記: modern-minimal は彩度0の中立を許可（モノクロ Stripe / ElevenLabs 系）。*
25. アクセント色が単一ビューポートの約5%超を覆っているか（面積で数える: ベタ塗り、アクセントの大見出し、全幅アクセント背景）。yes なら退く。アクセントは強調用であり、埋める用ではない。*ジャンル注記: atmospheric はアクセント色のラジアル ブルームがキャンバスの約 20% まで覆うことを許可（ブルームがデザインだから）。*
26. パディング／ギャップ／マージンのいずれかが、命名された余白スケール（`--space-3xs` … `--space-5xl`、4 px の倍数）に乗っていない値か。任意の `padding: 17px` は痕跡。
27. いずれかの散文コンテナの `max-width` が 45–75 ch の範囲外か。measure は読まれること。45 ch 未満は途切れ、75 ch 超は視線を失う。
28. インタラクティブ要素のいずれかが `:focus-visible`、`:active`、`:disabled` のいずれかのスタイリングを欠いているか（8 状態がルール。Default ＋ Hover は2つだが、コード上は default ＋ hover ＋ focus-visible ＋ active ＋ disabled 以上が必要）。
29. `transform` / `animation` キーフレームのうち、`@media (prefers-reduced-motion: reduce)` フォールバックでカバーされていないものがあるか。すべてのモーションに reduced-motion 代替を。

## ヒーローエンリッチメント ゲート

（ページがエンリッチメントを持つとき。[`hero-enrichment.md`](hero-enrichment.md) 参照。）

30. ページにデモ動画があるとき、音付きで自動再生する／`poster` 欠落／`fetchpriority="high"` 欠落／ LCP 要素に `loading="lazy"` を使っているか（LCP キラーはここで失敗）。
31. ページに抽象背景があるとき、複数のアクセント色を使う／約 5% 超の占有／メッシュ グラデーションをページ全体でアニメーションしているか（Aurora ブロブとメッシュ全面はここで失敗）。*ジャンル注記: atmospheric は暖色トーンのラジアル ブルームを2つまで、約 20–30% の占有で許可。fixed-attached、アニメーションなし。*
32. ページが2つ以上のアイコンライブラリを混ぜているか（同一ページ上の Material ＋ Heroicons ＋ Lucide はアイコンセットの痕跡）。
33. ページにイラストがあるとき、手組み SVG か純 CSS シェイプが効くのに Lottie ライブラリをデフォルトにしたか（Lottie は最終手段、デフォルトではない）。

## 多様化ゲート

（`.hallmark/log.json` があれば相互参照。）

34. 過去の Hallmark 出力と同じ原型を使ったとき（`.hallmark/log.json` か最新マクロ構造スタンプ参照）、少なくとも1つの異なる *バリエーション ノブ* を選んだか。`tiles=6, spans=irregular, accent=corner-only` の Bento Grid を2つ作ると同じ Bento。[`component-cookbook.md`](component-cookbook.md) の原型内ノブはまさにこれを防ぐためにある。スタンプにノブ差分を記す。
35. ビジュアルのみの `<svg>`、custom-art `<div>`、`<canvas>`、装飾 figure のいずれかが `aria-label` または `aria-hidden="true"` を欠いているか。手組み CSS アートと SVG イラストにはアクセシブル名 *または* 明示的非表示が要る。これを飛ばすのは新しいアクセシビリティの痕跡。

## レイアウト安全ゲート

（ページは全ビューポートを生き残ること。）

36. ページが 320 px から 1920 px のいずれかのビューポートで横スクロールするか。描画ページを開き、その範囲で devtools 幅スライダーをドラッグする。どれかの幅で水平スクロールバーが出たら fail。修正は `html { overflow-x: clip; }` ＋ビューポート超過するクリップエッジ エンリッチメントの安全網としての `body { overflow-x: clip; }`。`overflow-x: clip`（`hidden` ではない）を使う。`clip` は子孫の `position: sticky` / `position: fixed` を保つ。（相互参照: [`layout-and-space.md` § Page-edge clipping](layout-and-space.md)。）
37. テキストへの装飾効果（ハイライター `<mark>` / `<em>` バンド / アクセント ストローク / 下線）すべてで、位置とサイズを目視確認したか。ハイライター バンドは x-height の背後（`linear-gradient(180deg, transparent ~38%, accent ~38%, accent ~92%, transparent ~92%)`）に座ること。ベースライン（太い下線として読まれる）ではない。下線は 1–2 px、ベースラインから 1–2 px オフセット、5+ px はだめ。装飾ストロークはビューポートの 5% を超えない（gate 25）。チェックは *視覚*。描画出力を想像し、バンドが正しい縦ゾーンに着地するか確認。
38. インタラクティブ バー（ナビ、ツールバー、コマンド バー、ヒーロー CTA 行、フッターリンク帯）が明示的に縦方向中央揃えされているか。デフォルトの flex レイアウトは `align-items: stretch` を継承する。これがボタンを兄弟テキストより背高くし、視覚ベースラインを壊す。高さの違う要素（ボタン＋テキスト、アイコン＋テキスト、mark ＋本文）が混じる flex 行ごとに `align-items: center` を宣言し、固有高のあるアイテムに `line-height: 1` を当てる。`html` からの `line-height: 1.55` の継承は行の縦リズムと戦う。

## タイポグラフィ規律ゲート

（3書体が上限。[`typography.md` § The 2+1 rule](typography.md) 参照。）

39. ページが **3つを超える** 個別 `font-family` を使っているか。カウント: `--font-display`、`--font-body`、最大1つの outlier（`--font-outlier` でワードマーク／ヒーロー スタット／プルクォート）。4つ目のファミリー（例: body ＋ display ＋ コードブロック内 mono ＋ ヒーロー用の別 display）はスロップ。異なるウェイトの同じファミリーは1ファミリーと数える。Mono は非コード文脈（キャプション、ラベル、数字）で使われるならファミリーに数える。4つ見つけたら、1つを body か display 面に戻す。
40. **outlier 書体が2スロットを超えて使われている**か。outlier はレジスターであり、3つ目のサーフェスではない。ワードマーク＋ヒーロー スタットが正規のペア、もしくはワードマーク＋マストヘッド、もしくはヒーロー スタット＋プルクォート。3スロット＝ outlier が3つ目の body フォントに昇格しているので、body 面に畳む。

## 入力状態ゲート

（入力は「ほぼ正しい」UI が負ける場所。[`interaction-and-states.md` § Input field states](interaction-and-states.md) 参照。）

41. 入力、テキストエリア、セレクトのいずれかが、状態間（default → hover → focus → error）で `border-width` を変えるか。default は 1 px、hover、focus、error も `border-width: 1px`。border-width の変化はレイアウトシフトを起こす。状態変化は `background-color`、`outline`、`box-shadow`、`border-color` に。`border-width` ではない。
42. 入力のフォーカスリングが `outline` ではなく `border` を使っているか。フォーカスリングは `outline: 2px solid var(--color-focus)` ＋ `outline-offset: 1px`。default 状態で `outline: 2px solid transparent` を予約し、活性化時の幾何シフトを防ぐ。`border` 変化によるフォーカスリングは痕跡。
43. 入力高が同じフォームの隣のボタン高と異なるか。フォーム入力とフォーム送信ボタンは単一の基準高を共有（44 px が床）。38 px input ＋ 44 px button は最も一般的なフォーム チューニング スロップで、未設計に読まれる。
44. ヘルパーテキスト用コンテナがヘルパー／エラー非表示時に畳まれているか。ヘルパー スロットは空のときも `min-height: 1lh` を確保すること。エラー出現でページが押し下がってはいけない。バリデーション時の縦ジャンプは痕跡。
45. 入力の disabled 状態が **`opacity: 0.5` のみ** で示されているか。Disabled には3つの独立したシグナルが要る: `opacity: 0.55` AND `cursor: not-allowed` AND `aria-disabled="true"`（またはネイティブ `disabled` 属性）。1チャネルは見逃せる、3つは見逃せない。

## コントラストと可読性

universal — 全ジャンルに適用。ユーザーが指摘した実世界の失敗を捕まえる。黒テキスト on 黒ボタン、暗セクションの読めないテキスト、サーフェスを反転した後にテキスト色を反転し忘れた ink-on-ink スロップ。

コントラスト計算: ページの全 `(color, background-color)` ペアに対して **APCA Lc** または **WCAG 2.1 比率** を走らせる。OKLCH の明度は速いプリチェック — `|L_text − L_bg| < 50 %` ならペアは 4.5:1 を落とす可能性が高い。フル計算で確認。

しきい値。
- 本文テキスト（24 px regular 未満 OR 18 px bold 未満）: **WCAG 4.5:1 / APCA Lc ≥ 60**。
- 大きいテキスト／アイコン／フォーカスリング: **WCAG 3:1 / APCA Lc ≥ 45**。

46. いずれかの **本文テキスト** が計算上の背景に対して **4.5:1** 未満のコントラスト比か。すべての `color` 宣言を実効 `background-color` とペアにして検証する。最も見逃すケース: カード内テキストが `color` を継承しているがカードが `background: var(--color-paper-2)` に切り替わり、テキストが明度的に近すぎる場合。`color: var(--color-muted)` が `background: var(--color-paper-3)` に乗る場合 — 両方とも中明度で fail。

47. いずれかの **大きいテキスト**（≥ 24 px regular OR ≥ 18 px bold）または **アイコン** または **`:focus-visible` リング** が背景に対して **3:1** 未満か。同じ計算、緩いしきい値。特にフォーカスリングを確認。`outline: 2px solid var(--color-focus)` は `--color-focus` が要素 *と* ページサーフェスの *両方* に対して ≥ 3:1 のときのみ通る。

48. いずれかの **ボタン** が塗り上で `color` ≈ `background-color` になっていないか。カナリア チェック: 計算後のテキスト色と計算後の背景色が OKLCH で **明度 5 % 以内 AND 彩度 0.05 以内** なら、ゲート fail。`color: var(--color-ink)` が `background: var(--color-ink)` に乗る一般的バグ（黒 on 黒スロップ）を捕える — LLM が塗り上のテキストに `--color-accent-ink`（または `--color-paper`）を使うのを忘れたケース。

49. ページのどこかで `--color-accent` が塗り（ボタン、バッジ、サーフェス）に使われているとき、`--color-accent-ink` が（`:root` かテーマ トークンで）**定義 AND 適用** されているか。`--color-accent-ink` が無いと、`color: white` 1行のミスで低コントラストに転落する。このトークンは存在し、`--color-accent` に対して ≥ APCA Lc 60 / WCAG 4.5:1 を検証済みで、アクセントがテキストを乗せたサーフェスを塗るすべての箇所で適用されること。

50. いずれかの **暗セクション**（`background-color` の OKLCH 明度 < 50 % のセクションかパネル）が、サーフェスを反転したのにページ既定の `color: var(--color-ink)` を使ったテキストを乗せていないか。ink-on-ink。暗サーフェスに切り替えたセクションはテキスト色も切り替える（通常は `--color-paper`）。ネストした子も継承させる。修正は明示的に: `background: <dark>` を設定するクラスは同じルールで `color: <light>` を設定するか、それを設定する親で包む。最頻出の失敗: アクセントか ink で塗られた `.vs__col:first-child` の中のパネルが既定 ink 色のテキストのまま。

Step 6 の CSS スタンプには結果を記録: 全5ゲート通過なら `· contrast: pass (46–50)`、どれか open なら `· contrast: FAIL gates <list>`。出荷前に修正。

## ナビ・フッター・ヒーロー構造のスロップ

universal — 全ジャンルに適用。ナビ、フッター、ヒーロー形状で最も認識される AI 指紋を捕える。構造指紋ゲート（gate 9）と並走する。gate 9 は *ページ* 指紋、51–55 はその上に乗る *chrome* 指紋を捕える。

51. **ナビ指紋。** ページの `<nav>`（または最上位の `role="banner"` の `<header>`）が AI デフォルト — ワードマーク左＋4〜5本のインライン テキストリンク中央／右寄せ＋右にボタン＋ビューポート全幅＋ 1 px ヘアライン border-bottom ＋白背景 — か。yes なら fail。例外は要件が N1 を明示的に正当化する場合（ページが2宛先しかない *かつ* ジャンルのルーティング表が N1 を許可する）のみ。Hallmark 出力は [`component-cookbook.md`](component-cookbook.md) § Navigation の N1、N3、N4、N5、N6、N7、N8、N9 を回す。

52. **フッター指紋。** `<footer>` が AI デフォルト — 4カラムのリンク（Product / Company / Resources / Legal）＋ソーシャル アイコン行＋最下部の極小コピーライト＋ 1 px ヘアライン top-border ＋中立グレー背景 — か。yes なら fail。例外はページが genuine な docs ルートかハブの場合。それ以外は [`component-cookbook.md`](component-cookbook.md) § Footers の Ft1、Ft2、Ft4、Ft5、Ft6、Ft7、Ft8 を既定にする。

53. **ヒーローすべて中央寄せ。** eyebrow、title、lede、CTA が同じ縦軸に積まれて中央寄せか。auto-fail。最大2要素までを中央寄せにし、他は揃えを崩す。中央寄せ narrow ヒーローは editorial / salon / atelier ボイスでのみ許容され、その場合でも eyebrow か CTA は軸を外す（margin-aligned、右寄せ、または数字アンカー）。

54. **ヒーロー パディング非対称。** ヒーローコンテナの `padding-block-end` が `padding-block-start` の 1.3 倍以上か。ヒーローが対称に padding すると（あるいは上に *より多く* padding すると）、ページから浮く。ヒーローはページに *沈み込む* べきで、底のパディングを重くして次セクションのリズムに引き込む。描画出力のヒーロー要素で計算。

55. **目的のない装飾。** ヒーローに装飾要素（カーソル、スキャンライン、グラデーション ブロブ、抽象形状、装飾、バッジ、ステッカー）があり、コンテンツに意味的アンカーがないか。fail。装飾は動機付けが要る: タイプしたコマンド内のカーソル（「次に入力する」を示す）、issue / year / version / chapter を命名する数字、インタラクションに応答するグラデーション（HP3 カーソル スポットライト）、著者性や日付を命名するスタンプ。コーナーの "42" でエディション意味なし、ヒーロー横の浮遊カーソル、配色根拠のない Pantone チップ — これらはスロップ。

Step 6 の CSS スタンプにコントラストと併記: `· nav: N# · footer: Ft# · slop: pass (51–55)`。51–55 のいずれかが fail なら、出荷前に修正。

## 正直な文言・捏造コンテンツの拒否

universal — 全ジャンルに適用。ページがユーザーのプロダクト、チーム、市場について事実を発明してはならない。

56. **発明されたメトリック。** ページに定量的主張（"10× faster"、"saves 5 hours per week"、"trusted by 50,000+ teams"、"99.9 % uptime"、"+47 % conversion"）があり、ユーザーが提供しておらず、出典もなく、モデルが stat-led レイアウト、比較行、proof バーを埋めるために捏造したものがあるか。yes なら fail。修正の選択肢: 数字を `—` とラベル付きグレー ブロックに置換、ユーザーへの質問に置換（"metric to confirm"）、proof スロットなしでセクションを再構築。stat-led マクロ構造は、スタットが装飾になった瞬間にスロップ。*（[anti-patterns.md § Invented metrics](anti-patterns.md) 参照。）*

## 再描画された UI クローム

universal。Hallmark はユーザー既存のクローム（ブラウザ、OS、IDE）を再描画せず、再利用すること。

57. **再描画されたクローム。** Hallmark が偽のブラウザバー（URL ピル＋信号機ドット）、偽のフォンフレーム（角丸長方形＋ノッチ＋スピーカースリット）、偽のコードブロック フレーム（`<pre>` の周りのウィンドウ クローム模倣）、偽のターミナル フレーム、偽の IDE クローム（ファイルタブ＋アクティビティ バー＋サイドバー）を HTML/CSS か SVG で手組みしたか。yes なら fail。再描画クロームは「AI生成に見える」最強の痕跡の1つ — モデルがユーザー環境に既存する UI を発明した。修正: `<picture>` か `<figure>` で実スクリーンショットを使うか、クロームを省いてコンテンツ自体で立たせる。*（[anti-patterns.md § Re-drawn UI chrome](anti-patterns.md) 参照。）*

## トークン規律

universal。テーマは実行冒頭でパレットとフォントスタックを選ぶ。以降の実行はトークンを消費するのみ、発明しない。

58. **レンダ途中のトークン即興。** Hallmark が `:root` / `[data-theme="..."]` で定義したデザイントークンの *外* で、色値（`#hex`、`oklch(...)`、`rgb(...)`、`hsl(...)`）または `font-family` 宣言を導入したか。yes なら fail。アーティファクトの全色と全フォントは命名トークン（`var(--color-accent)`、`font-family: var(--font-display)`）を参照すること。インラインの OKLCH や使い捨ての hex はレンダ途中の即興 — モデルがテーマを選んだ後に忘れてフリースタイルした。修正: 値を命名変数としてトークンブロックに引き上げる、または既存トークンに置換。*（[SKILL.md § Locked tokens](../SKILL.md) と [anti-patterns.md § Mid-render token improvisation](anti-patterns.md) 参照。）*

## レスポンシブ — クリック可能アフォーダンス

universal。ボタン、リンク、ナビ項目はビューポートが縮んでも単一行アフォーダンスとして読めること。

59. **2行のクリック可能テキスト。** ボタン ラベル、主要ナビ リンク、フッター リンク、タブ ラベル、パンくず、CTA テキストのいずれかが、320 px から 1920 px のビューポートで2行以上に折り返すか。yes なら fail。クリック可能テキストが2行で読まれると壊れて見える — 訪問者は意図ではなくスタイル エラーとして読む。修正: ラベルを短くする（最良の修正、"Get started free" → "Start free"）、アフォーダンスに `white-space: nowrap` を当てて親をリフローさせる、狭い幅で非必須ナビ項目を `hidden=until-found` で落とす、ナビをシート／メニューに畳む。CTA やナビ リンクを絶対に折らせない。*（[responsive.md § Clickable text — never wraps](responsive.md) 参照。）*

60. **絵文字を機能アイコンに使う。** フィーチャー カード、価値訴求、ステップ番号、プライシング層のいずれかが絵文字グリフ（✨ 🚀 ⚡ 🔥 🎯 ✅）を主アイコンにしているか。yes なら fail。絵文字アイコンは最強の「AI デフォルト」痕跡の1つ — モデルがアイコンライブラリを選ぶ、カスタムマークを作る、アイコンを省くのではなく Unicode グリフに手を伸ばした。修正: 単一のアイコンライブラリを選ぶ（Lucide / Phosphor / Heroicons — [assets.md](assets.md) 参照）、カスタム SVG を作る、アイコンを落としてタイポグラフィで主導する。

Step 6 の CSS スタンプに結果を記録: `· honest: pass (56) · chrome: pass (57) · tokens: pass (58) · responsive: pass (59) · icons: pass (60)`。fail は出荷前に修正。

## モバイル レスポンシブネス — 妥協不可

universal。emit する全ページは 320 px、375 px、414 px、768 px の CSS ピクセル幅で完璧にレンダリングすること。ゲート36（横スクロールなし）と59（2行クリック可能テキストなし）が headline のケースをすでにカバーする。下記 61–65 はマーケティング サイトのレスポンシブネス パスで判明したパターンを成文化する。完了とする前に各ビューポートを目視する。

61. **画像を含むグリッド トラックに `minmax(0, 1fr)` がない。** いずれかの `grid-template-columns`（または `grid-template-rows`）が `1fr` トラックを含み、そのトラック内に `<img>` / `<picture>` / 画像を含む要素が描画されるか。yes ならトラックは `minmax(0, 1fr)` でなければならない。素の `1fr` は `minmax(auto, 1fr)` に解決され、`auto` の最小は最大コンテンツの固有幅 — 1024+ px のネイティブ画像なら 1024+ px の最小、つまり電話でビューポートを超える。修正はトラックごとに1文字: `1fr` → `minmax(0, 1fr)`。

62. **ルートに `overflow-x: clip` がない。** アーティファクトが `html` と `body` の両方に `overflow-x: clip` を持たないか。yes なら fail。`clip`（`hidden` ではない）は横スクロールを防ぎつつスクロール コンテキストを作らない。`position: sticky` の子孫が機能し続ける。emit する全ページで必須。ベース リセットに追加: `html, body { overflow-x: clip; }`。

63. **ディスプレイ ヘッダーに長単語折り返しがない。** display サイズのテキストを描画する要素（`h1`、`.hero__display`、`.section__title`、`.skill-row__title`、ヒーロー相当クラス）のいずれかが `overflow-wrap: anywhere; min-width: 0` を欠くか。yes なら fail。長いハイフン付き単語（"AI-generated"、大文字の複合ブランド名）はビューポートを超える。break のチャンスはハイフンだけだから。`overflow-wrap: anywhere` は最後の手段として単語内ブレイクを許す。

64. **テーマ別セクション見出しオーバーライドにモバイル畳みがない。** テーマかバリアントが `.section__head { grid-template-columns: ... }` を `1fr` 以外にオーバーライドするとき、モバイル畳みルールも含むか、もしくは `@media (max-width: 48rem)` に同じ specificity で `[data-theme] .section__head { grid-template-columns: 1fr }` のグローバルが存在するか。どちらも無ければ fail。テーマ別2カラム見出しはモバイルでテンプレートを保ち、タイトルがセクション ラベルに巻き、ページが壊れて読まれる（最も視認しやすいのは Sport: イタリック Anton タイトルが "02 / EXAMPLES" と重なる）。

65. **CSS のみのラジオ タブ パターンがスクロール ジャンプする。** タブ トグルを `<input type="radio">` 兄弟＋ `:checked` セレクタで実装するとき、アーティファクトが (a) ラジオを通常のドキュメントフローに置きサイズ 0 ＋ opacity 0 にする（`position: absolute; top: 0` にしない）、または (b) ラベル クリックを横取りし `e.preventDefault()` を呼び `radio.checked = true` を手動で設定し `change` をディスパッチし `{ preventScroll: true }` でフォーカスする JS ハンドラを出荷する、のいずれかを満たすか。ラジオが `position: absolute; top: 0` で JS ガードも無いなら fail。デフォルト位置のラジオはタブ クリックごとにページがセクションの先頭にジャンプする — 全ビューポートで visible だがモバイルで最も破壊的。

66. **見出しの傍のセクション eyebrow / タグ（tag-left、header-right）。** どれかのセクションが eyebrow / 番号 / mono-cap ラベル（`01 · THE TOUR`、`02 / FEATURES`、`Chapter Three`）をセクション見出しの左、または右のカラムに、同じ水平行で描画するか。auto-fail。このパターンは数秒でテンプレ的編集系 SaaS の痕跡として読まれる。eyebrow を使う場合は（[`anti-patterns.md § Eyebrow on every section`](anti-patterns.md) 参照 — デフォルトは OFF）、見出しは **同じカラムの直下** に来る。縦積みのみ。具体: **クラス名がなんであれ（`.section__head`、`.workbench__head`、`.pricing__head`、`.catches__head`、`.foo__intro` 等、マクロ構造／セクション別の任意）、いずれの `<header>`、`<div>`、`<section>` ラッパーも** eyebrow / ラベル / 番号 / kicker 要素 AND 見出し要素の両方を含むなら、必ず単一カラム レイアウトに解決すること: `display: block`、`display: flex; flex-direction: column`、または `display: grid; grid-template-columns: 1fr`（または `minmax(0, 1fr)`）。そうしたラッパーへの multi-column グリッド（`grid-template-columns: 1fr 2fr`、`minmax(0, 0.4fr) minmax(0, 1fr)`、`auto 1fr` 等）は禁止。**ルールは *コンテンツの形* — 同じラッパー内の eyebrow ＋見出し — に拘束され、特定のクラス名 allowlist ではない。** [`structure.md`](structure.md) の「Left-margin」軸と [`layout-and-space.md`](layout-and-space.md) の「Hanging headers」パターンは、eyebrow を伴う見出しについて本ルールが優越する。**「構造的対比を保つ」「この参照をミラーする」「前のビルドに合わせる」指示でバイパス不可** — 参照ビルドが禁止パターンを出荷していても（rule-66 以前のビルドは大抵そう）、新ビルドでは無言で平坦化する。ルールが対比に勝つ。参照ビルドはこのゲート以前のものかもしれない。ゲートが権威。

67. **全大文字ディスプレイ見出しに `line-height < 1.0` →大文字衝突で折り返す。** display サイズ要素（`.hero__display`、`.section__title`、`h1`、`h2`、または `≥ --text-2xl` のいずれか）が `text-transform: uppercase` AND `line-height`（または `--lh-tight`）`1.0` 未満を宣言するか。yes なら fail。大文字グリフにはディセンダーがなく、キャップトップが行ボックスの最上部に座る — `line-height: 0.94`（旧 Manifesto / Sport / Brutal デフォルト）ではタイトルが折り返したとき、N+1 行目のキャップトップが N 行目のベースラインまたはコンマと視覚的に衝突する。コンデンスド ディスプレイ書体（Anton、Inter Tight 900、Bebas Neue）は悪化させる。**全大文字ディスプレイ見出しの床は `line-height: 1.0`、推奨 `1.02–1.08`**。テーマの `--lh-tight` を ≥ 1.0 に上げるか、display 要素から `text-transform: uppercase` を外す。2行 `.section__title` が末尾コンマで折り返したとき最も visible（"SAME PROMPT, TWO / DIFFERENT OUTPUTS."）— コンマ＋大文字 D が単一グリフ ブロブに融合する。

68. **sticky なページ ナビの下の `top: 0` の sticky 要素 → ブリード。** アーティファクトが、`top: 0` で sticky な `<header>` / `<nav>` / `.banner` も存在するときに（つまりページに `top: 0` で sticky な要素が2つあるとき）、最上位のナビ／バナー／ヘッダー *以外* の要素で `position: sticky; top: 0;` を宣言するか。auto-fail。両方ともスクロール中にビューポート上端にスティックして重なり、DOM 上で深い要素がナビの上に描画される（「セクション ヘッダーがナビ バーにブリードする」グリッチとして見える）。修正: `--banner-height` トークン（ナビ デザインによって 44–64 px）を定義し、二次的 sticky のすべてを `top: var(--banner-height)` にオフセット、ナビの **下** に docking する。ナビにはページ内 sticky 要素より高い z-index を与える — `--z-sticky`（ページ内、例 200）と `--z-sticky-nav`（トップ ナビ、例 300）を分けて、sticky ボックスと一時的に重なってもナビが常に上に描画される。このゲートはページが実際に sticky 要素（S3 sticky-pinned セクション見出し、F2 sticky-scroll フィーチャースタック、sticky 目次）を持つときのみ発火。sticky 動作のないページは自明にパス。

69. **解析した DNA がカタログ テーマに捨てられた。** 会話の前段で `study` 診断が出ており、AND ビルドの CSS スタンプの `theme:` フィールドが、ユーザーの明示的な切替（"use Linen instead"、"ignore the DNA"、"rotate to a different theme"）なしに、`studied-DNA (source: ...)` ではなくカタログ テーマ（Specimen、Atelier、Brutal、Salon、Newsprint、Linen、Studio、Manifesto、Terminal、Midnight、Almanac、Garden、Quiet、Riso、Sport、Bloom、Coral、Violet、Aurora、Halo、Plume、Editorial）を命名しているか。auto-fail。解析した DNA はシステムであるはずだった（SKILL.md § 2.6 Condition 0）。カタログへの後退はアトラクタの引力。修正: 解析した DNA のトークン（paper OKLCH、accent OKLCH、命名候補フォント、マクロ構造、原型）を直接使って再出力し、スタンプを `theme: studied-DNA (source: <URL or image>)` に更新し、インライン値を入れる。会話スコープに最近の study が無いとき、本ゲートは自明にパス。

Step 6 の CSS スタンプにモバイルのパスをコントラストと併記: `· mobile: pass (36, 59, 61–69)`。

---

いずれかの答が **yes** なら、修正する。スロップを出荷しない。
