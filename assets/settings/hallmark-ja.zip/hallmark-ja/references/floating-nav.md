# スクロール時の浮遊ナビ — クロスフェードモーフ

**N10 · Floating-on-scroll morph** のレシピ（[`component-cookbook.md` § Navigation](component-cookbook.md) 参照）。1つの DOM、2つのビジュアルモード、単一クラスのトグル、1本のタイミングカーブ。AI のデフォルトは下記の4法則をすべて踏み外す。N10 がクックブック中もっとも厳しいナビである理由はそこにある。

## 構造

`<header>` 1つに内側ラッパー。外側が **デフォルトバー** のビジュアルを担い、内側が **浮遊ピル** のビジュアルを担う。スクロール閾値を超えると `.is-floating` がトグルし、各レイヤーがそれぞれの見た目をクロスフェードで切り替える。

```html
<header class="nav">
  <div class="nav__inner">
    <a class="wordmark">Hallmark</a>
    <ul class="nav__links">…</ul>
    <a class="cta">Install</a>
  </div>
</header>
```

## 4つの法則（妥協不可）

**1. ナビ総高は一定に保つ。** 状態切替時に外側の高さが変わると、それ以下のピクセル全部が縦にずれる。ユーザーには「スクロール中にページが跳ねた」と映る。内側の縮小を外側の `padding-block` で相殺し、両状態で合計が同じになるようにする。

**2. 可視オフセットは `transform: translateY()` を使う。`padding` / `margin` は絶対に使わない。** ピルはビューポート上端から浮いていて、息継ぎの余白を持つべき。外側に padding を足す素朴な対処は法則1を破る。`transform` はレイアウトに影響しない。ピルは視覚的に下がるが、ボックスはその場に留まる。

**3. 共有ビジュアルすべてをクロスフェードで所有させる。** 外側がデフォルトで持つプロパティ（background、border、backdrop-filter、box-shadow）すべてを、`.is-floating` で明示的に無効化し、かつトランジションリストに入れる。1つでも忘れると（たとえばフローティング時の外側に `backdrop-filter: blur(14px)` が残っていれば）、見えない blur 帯が背景を横切って引きずられる。

**4. 全プロパティに単一のタイミングカーブ。** 8つのプロパティを8本のカーブで動かすと、8つのアニメーションに見える。同じ8つを `var(--dur-mid)` + `var(--ease-out)` で動かせば、1つのモーションに見える。`cubic-bezier(0.16, 1, 0.3, 1)`（指数 ease-out）、約520ms を使う。

## プロパティモーフ（10プロパティ、1本のカーブ）

| Element | Property | Default | Floating |
|---|---|---|---|
| `.nav` | `padding-block` | `0` | `var(--space-2xs)` |
| `.nav` | `background-color` | dark/0.62 | `transparent` |
| `.nav` | `border-block-end-color` | rule | `transparent` |
| `.nav` | `backdrop-filter` | `saturate(1.4) blur(14px)` | `blur(0)` |
| `.nav__inner` | `max-width` | `var(--page-max)` | `~58rem` |
| `.nav__inner` | `min-height` | `60px` | `52px` |
| `.nav__inner` | `padding-block` | `12px` | `4px` |
| `.nav__inner` | `border-radius` | `0` | `var(--radius-pill, 999px)` |
| `.nav__inner` | `background-color` | `transparent` | dark/0.82 |
| `.nav__inner` | `backdrop-filter` | `blur(0)` | `blur(18px)` |
| `.nav__inner` | `box-shadow` | `none` | drop + tinted glow + inset hairline |
| `.nav__inner` | `transform` | `translateY(0)` | `translateY(12px)` |

`none` ではなく `blur(0)` を使う。`none` はスナップする。`blur(0)` はトランジションする。`backdrop-filter` のトランジションは 2024+ ベースライン（Chrome 107+、Safari 14+、Firefox 103+）。

## スクロールハンドラ

```js
(() => {
  const nav = document.querySelector(".nav");
  if (!nav) return;
  const THRESHOLD = 80;          // ≥ 60 px。マイクロスクロールの揺れを避ける
  let floating = false;
  let ticking = false;
  const update = () => {
    const next = window.scrollY > THRESHOLD;
    if (next !== floating) {     // boolean-flip ガード。状態変化ごとに1回だけトグル
      floating = next;
      nav.classList.toggle("is-floating", floating);
    }
  };
  window.addEventListener("scroll", () => {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => { update(); ticking = false; });
  }, { passive: true });          // モバイルスクロール性能。メインスレッドを空ける
  update();
})();
```

3つの規律。
- **`passive: true`** — リスナーは `preventDefault` しないので、ブラウザはメインスレッドをスクロールに専念できる。
- **`requestAnimationFrame` スロットル** — 60回／秒に制限し、ペイントに揃える。
- **boolean-flip ガード** — クラス操作は状態変化ごとに1回だけ走り、スクロールイベントごとには走らない。

## Hallmark が拒否するアンチパターン

1. `<header>` 要素を2つ用意して opacity でスワップする。DOM が倍になり、フォーカス順が衝突し、コンテンツが非同期化しうる。
2. `top` / `margin-top` をアニメーションして浮遊オフセットを足す。レイアウトを誘発する。`transform` だけが正しいレバー。
3. フローティング状態で `backdrop-filter: none` を使う。スナップする。`blur(0)` を使ってトランジションさせる。
4. 状態間でナビ高さが変わる。コンテンツのジッターを起こす。このパターンで最も致命的なミス。
5. プロパティごとに別の duration（「半径だけ速く」「シャドウを遅らせる」）。すべてが動いていても壊れて見える。1本のカーブで通す。
6. `{ passive: true }` も rAF スロットルも無い `scroll` イベント。どちらもモバイルスクロール性能を殺す。
7. しきい値 = 0（わずかなスクロールでモーフが発火）。落ち着かない。≥ 60 px を使う。
8. boolean-flip ガードを忘れて、スクロールイベントごとにクラスをトグルする。レイアウトスラッシュを起こす。

このパターンが効くのは抑制されているから。1つに集約されたモーフ、装飾なし。磨きはタイミングカーブ、シャドウスタック、高さ一定の計算に注ぐ。「もっと盛る」方向には注がない。
