# エクスポート形式

[`SKILL.md`](../SKILL.md) Step 6 から、デザインシステムをポータブル トークンとして出力するときに読み込まれる。Hallmark が常に書く4つの正典的形式を定義する。

1. **`tokens.css`** — 真正のソース。ページ CSS と共に常に出力。
2. **Tailwind v4 `@theme`** — Tailwind を使うプロジェクト向け。複数ページ プロジェクトの `design.md` Exports セクションに出力。
3. **DTCG `tokens.json`** — トークン パイプライン（Style Dictionary、Token Studio、Cobalt）を使うプロジェクト向け。`design.md` に出力。
4. **shadcn/ui CSS variables** — shadcn/ui のコンポーネント ライブラリを使うプロジェクト向け。`design.md` に出力。

出力ルール: `tokens.css` は常に書く。他の3つは `design.md` 内にインラインで存在し、ユーザーが必要なものを新プロジェクトにコピーする。**新しい動詞コマンドは作らない。** これは全ビルドの副作用。

---

## トークンの分類 — Hallmark の真正のソース

すべての Hallmark 出力は下記のトークン（あるいはページが使わないものを除いた部分集合）を書く。名前がソース。他の形式はすべて翻訳。

| Hallmark token | Type | Example value |
| --- | --- | --- |
| `--color-paper` | 色 | `oklch(96% 0.018 80)` |
| `--color-paper-2` | 色 | `oklch(94% 0.020 80)` |
| `--color-paper-3` | 色 | `oklch(91% 0.022 80)` |
| `--color-ink` | 色 | `oklch(15% 0.012 80)` |
| `--color-ink-2` | 色 | `oklch(28% 0.014 80)` |
| `--color-rule` | 色 | `oklch(86% 0.018 80)` |
| `--color-rule-2` | 色 | `oklch(72% 0.020 80)` |
| `--color-muted` | 色 | `oklch(50% 0.014 80)` |
| `--color-neutral` | 色 | `oklch(38% 0.012 80)` |
| `--color-accent` | 色 | `oklch(58% 0.16 70)` |
| `--color-accent-ink` | 色 | （アクセント塗りの上のテキスト、≥ APCA 7:1） |
| `--color-focus` | 色 | （多くの場合 = 高彩度のアクセント） |
| `--font-display` | フォント | `"Fraunces", ui-serif, Georgia, serif` |
| `--font-body` | フォント | `"Geist", ui-sans-serif, system-ui, sans-serif` |
| `--font-outlier` | フォント | `"Geist Mono", ui-monospace, monospace` |
| `--space-3xs` … `--space-5xl` | 長さ | 4-pt スケール: `0.25rem` … `8rem` |
| `--text-xs` … `--text-display` | 長さ | 1.25（major-third）比のスケール |
| `--ease-out` / `--ease-in` / `--ease-in-out` | イージング | `cubic-bezier(0.16, 1, 0.3, 1)` 等 |
| `--dur-micro` / `--dur-short` / `--dur-long` | 時間 | `120ms` / `220ms` / `420ms` |
| `--rule-hair` / `--rule-fine` | 長さ | `1px` / `2px` |
| `--radius-card` / `--radius-pill` / `--radius-input` | 長さ | テーマで変動 |
| `--shadow-card` | シャドウ | テーマで変動 |

ページが *追加の* トークンを導入するなら、役割で命名して `tokens.css` に加える。`tokens.css` にないトークン名を下流で発明しない — 真正のソースは真正のソース。

---

## Format 1 — `tokens.css`

ソース。`:root` のプレーンな CSS カスタム プロパティ。すべての Hallmark ページ CSS はこのファイルを冒頭でインポートする。

```css
@import "tokens.css";
/* ページ CSS が続く — var(--color-paper) を使い、生値は使わない */
```

あるいはプロジェクトの CSS バンドラ／フレームワークが裸の `@import` を尊重しないなら、プロジェクトの既存エントリポイントが最初に `tokens.css` を取り込む。ページ CSS は依然としてトークン名でトークンを参照し、生値では参照しない。

**ワークド例 — editorial テーマ（Specimen 風）:**

```css
:root {
  --color-paper:        oklch(96% 0.018 80);
  --color-paper-2:      oklch(94% 0.020 80);
  --color-paper-3:      oklch(91% 0.022 80);
  --color-rule:         oklch(86% 0.020 78);
  --color-rule-2:       oklch(72% 0.022 78);
  --color-muted:        oklch(50% 0.018 78);
  --color-neutral:      oklch(38% 0.014 76);
  --color-ink-2:        oklch(28% 0.012 75);
  --color-ink:          oklch(15% 0.010 75);
  --color-accent:       oklch(58% 0.16 60);
  --color-accent-ink:   oklch(98% 0.012 75);
  --color-focus:        oklch(58% 0.16 60);

  --font-display: "Fraunces", "Cardo", ui-serif, Georgia, serif;
  --font-body:    "Geist", "Söhne", ui-sans-serif, system-ui, sans-serif;
  --font-outlier: "Geist Mono", "JetBrains Mono", ui-monospace, monospace;

  --display-weight: 400;
  --display-style:  italic;
  --tracking-display: -0.02em;
  --tracking-label:   0.10em;

  --text-xs:      0.75rem;
  --text-sm:      0.875rem;
  --text-md:      1.125rem;
  --text-lg:      1.375rem;
  --text-xl:      1.75rem;
  --text-2xl:     2.25rem;
  --text-display: clamp(3rem, 6vw + 1rem, 6.5rem);

  --space-3xs: 0.25rem;
  --space-2xs: 0.5rem;
  --space-xs:  0.75rem;
  --space-sm:  1rem;
  --space-md:  1.5rem;
  --space-lg:  2rem;
  --space-xl:  3rem;
  --space-2xl: 4.5rem;
  --space-3xl: 7rem;
  --space-4xl: 11rem;

  --rule-hair: 0.5px;
  --rule-fine: 1px;
  --radius-card:  0;
  --radius-pill:  0;
  --radius-input: 0;

  --ease-out:    cubic-bezier(0.16, 1, 0.3, 1);
  --ease-in:     cubic-bezier(0.7, 0, 0.84, 0);
  --ease-in-out: cubic-bezier(0.65, 0, 0.35, 1);

  --dur-micro: 120ms;
  --dur-short: 220ms;
  --dur-long:  420ms;
}
```

**ワークド例 — modern-minimal テーマ（Quiet 風）:**

```css
:root {
  --color-paper:      oklch(100%  0     0);
  --color-paper-2:    oklch(98.5% 0     0);
  --color-paper-3:    oklch(96%   0     0);
  --color-rule:       oklch(91%   0     0);
  --color-rule-2:     oklch(82%   0     0);
  --color-muted:      oklch(55%   0     0);
  --color-neutral:    oklch(40%   0     0);
  --color-ink-2:      oklch(28%   0     0);
  --color-ink:        oklch(15%   0     0);
  --color-accent:     oklch(15%   0     0);
  --color-accent-ink: oklch(100%  0     0);
  --color-focus:      oklch(60%   0.10  240);

  --font-display: "Geist", "Inter", ui-sans-serif, system-ui, sans-serif;
  --font-body:    "Geist", "Inter", ui-sans-serif, system-ui, sans-serif;
  --font-outlier: "Geist Mono", ui-monospace, "SF Mono", Menlo, monospace;

  --display-weight: 600;
  --display-style:  normal;
  --tracking-display: -0.025em;

  --radius-card:  8px;
  --radius-pill:  999px;
  --radius-input: 8px;
}
```

---

## Format 2 — Tailwind v4 `@theme`

Tailwind v4 は `@theme` 内の CSS 変数を読み、ユーティリティ（`bg-paper`、`text-ink` 等）を自動生成する。Hallmark トークンからの翻訳は直接 — 同じ変数名、同じ OKLCH 値。

```css
@theme {
  /* 色 */
  --color-paper:        oklch(96% 0.018 80);
  --color-paper-2:      oklch(94% 0.020 80);
  --color-paper-3:      oklch(91% 0.022 80);
  --color-rule:         oklch(86% 0.020 78);
  --color-rule-2:       oklch(72% 0.022 78);
  --color-muted:        oklch(50% 0.018 78);
  --color-neutral:      oklch(38% 0.014 76);
  --color-ink-2:        oklch(28% 0.012 75);
  --color-ink:          oklch(15% 0.010 75);
  --color-accent:       oklch(58% 0.16 60);
  --color-focus:        oklch(58% 0.16 60);

  /* フォント */
  --font-display: "Fraunces", "Cardo", ui-serif, Georgia, serif;
  --font-body:    "Geist", ui-sans-serif, system-ui, sans-serif;
  --font-outlier: "Geist Mono", ui-monospace, monospace;

  /* スペーシング — Tailwind はデフォルトで --spacing-* を読む。Hallmark の --space-* も併存させる */
  --spacing-3xs: 0.25rem;
  --spacing-2xs: 0.5rem;
  --spacing-xs:  0.75rem;
  --spacing-sm:  1rem;
  --spacing-md:  1.5rem;
  --spacing-lg:  2rem;
  --spacing-xl:  3rem;
  --spacing-2xl: 4.5rem;

  /* タイプ スケール — Tailwind は --text-* を読む */
  --text-xs:      0.75rem;
  --text-sm:      0.875rem;
  --text-md:      1.125rem;
  --text-lg:      1.375rem;
  --text-xl:      1.75rem;
  --text-2xl:     2.25rem;

  /* 角丸 */
  --radius-card:  0;
  --radius-pill:  0;
  --radius-input: 0;

  /* イージング — Tailwind は --ease-* を読む */
  --ease-out:    cubic-bezier(0.16, 1, 0.3, 1);
  --ease-in:     cubic-bezier(0.7, 0, 0.84, 0);
  --ease-in-out: cubic-bezier(0.65, 0, 0.35, 1);
}
```

注記。
- Tailwind v4 はスペーシング ユーティリティのために `--spacing-*`（`ing` あり）を期待。Hallmark の `--space-*` を `--spacing-*` にミラーして両名を動かす。
- `--text-*` はそのまま動く（Tailwind v4 が `text-md` 等で拾う）。
- `--font-*` は `font-display` / `font-body` / `font-outlier` ユーティリティになる。
- ユーザーの `tailwind.config.{ts,js}` には `@source` 指令が必要かもしれないが、`theme.extend` は不要 — v4 は `@theme` を直接読む。

---

## Format 3 — DTCG `tokens.json`

W3C Design Tokens Community Group 形式。Style Dictionary、Cobalt、Token Studio を使うプロジェクト向け。パス ベース、OKLCH は文字列値として残す、`$type` は必須。

```json
{
  "$schema": "https://design-tokens.github.io/community-group/format/",
  "color": {
    "paper":   { "$value": "oklch(96% 0.018 80)", "$type": "color" },
    "paper-2": { "$value": "oklch(94% 0.020 80)", "$type": "color" },
    "paper-3": { "$value": "oklch(91% 0.022 80)", "$type": "color" },
    "rule":    { "$value": "oklch(86% 0.020 78)", "$type": "color" },
    "rule-2":  { "$value": "oklch(72% 0.022 78)", "$type": "color" },
    "muted":   { "$value": "oklch(50% 0.018 78)", "$type": "color" },
    "neutral": { "$value": "oklch(38% 0.014 76)", "$type": "color" },
    "ink-2":   { "$value": "oklch(28% 0.012 75)", "$type": "color" },
    "ink":     { "$value": "oklch(15% 0.010 75)", "$type": "color" },
    "accent":  { "$value": "oklch(58% 0.16 60)",  "$type": "color" },
    "focus":   { "$value": "oklch(58% 0.16 60)",  "$type": "color" }
  },
  "font": {
    "display": { "$value": "Fraunces, Cardo, ui-serif, Georgia, serif", "$type": "fontFamily" },
    "body":    { "$value": "Geist, ui-sans-serif, system-ui, sans-serif", "$type": "fontFamily" },
    "outlier": { "$value": "Geist Mono, ui-monospace, monospace",         "$type": "fontFamily" }
  },
  "size": {
    "text-xs":      { "$value": "0.75rem",  "$type": "dimension" },
    "text-sm":      { "$value": "0.875rem", "$type": "dimension" },
    "text-md":      { "$value": "1.125rem", "$type": "dimension" },
    "text-lg":      { "$value": "1.375rem", "$type": "dimension" },
    "text-xl":      { "$value": "1.75rem",  "$type": "dimension" },
    "text-2xl":     { "$value": "2.25rem",  "$type": "dimension" },
    "text-display": { "$value": "6rem",     "$type": "dimension" }
  },
  "space": {
    "3xs": { "$value": "0.25rem", "$type": "dimension" },
    "2xs": { "$value": "0.5rem",  "$type": "dimension" },
    "xs":  { "$value": "0.75rem", "$type": "dimension" },
    "sm":  { "$value": "1rem",    "$type": "dimension" },
    "md":  { "$value": "1.5rem",  "$type": "dimension" },
    "lg":  { "$value": "2rem",    "$type": "dimension" },
    "xl":  { "$value": "3rem",    "$type": "dimension" },
    "2xl": { "$value": "4.5rem",  "$type": "dimension" },
    "3xl": { "$value": "7rem",    "$type": "dimension" },
    "4xl": { "$value": "11rem",   "$type": "dimension" }
  },
  "duration": {
    "micro": { "$value": "120ms", "$type": "duration" },
    "short": { "$value": "220ms", "$type": "duration" },
    "long":  { "$value": "420ms", "$type": "duration" }
  }
}
```

注記。
- DTCG はモダンなツーリングで `oklch(...)` 文字列を受け付ける。ユーザーのパイプラインが受け付けないなら hex（lossy、フラグを立てる）か `color(oklch ...)`（CSS Color 4）に変換。
- `text-display` 値はポータビリティのため固定 `6rem`。レスポンシブな `clamp(...)` は CSS に属する。トークン JSON には属さない。

---

## Format 4 — shadcn/ui CSS variables

shadcn/ui のコンポーネント ライブラリは特定の名前、特定の形の CSS カスタム プロパティを読む。値は **スペース区切り** の三つ組（`oklch()` ラッパーなし、コンマなし）で、shadcn が `oklch(<value> / <alpha>)` で合成できるようにする。

Hallmark トークンからの翻訳。

```css
:root {
  --background:           96%   0.018 80;     /* paper */
  --foreground:           15%   0.010 75;     /* ink */

  --card:                 94%   0.020 80;     /* paper-2 */
  --card-foreground:      15%   0.010 75;     /* ink */

  --popover:              94%   0.020 80;     /* paper-2 */
  --popover-foreground:   15%   0.010 75;     /* ink */

  --primary:              58%   0.16  60;     /* accent */
  --primary-foreground:   98%   0.012 75;     /* accent-ink */

  --secondary:            91%   0.022 80;     /* paper-3 */
  --secondary-foreground: 28%   0.012 75;     /* ink-2 */

  --muted:                86%   0.020 78;     /* rule */
  --muted-foreground:     50%   0.018 78;     /* muted */

  --accent:               58%   0.16  60;     /* accent（Hallmark では primary と同値） */
  --accent-foreground:    98%   0.012 75;

  --destructive:          58%   0.20  25;     /* 暖色レッド、固定 */
  --destructive-foreground: 98% 0.012 75;

  --border:               86%   0.020 78;     /* rule */
  --input:                86%   0.020 78;     /* rule */
  --ring:                 58%   0.16  60;     /* focus */

  --radius:               0;                   /* radius-card、shadcn は1値を使う */
}
```

それからユーザーの `tailwind.config.ts`（または v4 `@theme`）が `oklch(var(--background))` で読む。Hallmark の accent → shadcn の primary が正典マッピング、secondary → paper-3。

ユーザーがダーク バリアントを欲するなら、`.dark` セレクタ下にダーク テーマ トークンをミラーする（Hallmark の Midnight / Bloom / Terminal が値を供給する）。

---

## 出力ルール

SKILL.md Step 6 がエクスポートを出すとき。

1. **常に** `tokens.css` をページ CSS の隣（複数ファイル プロジェクトではプロジェクト ルート）に書く。Format 1。
2. **`design.md` 管理プロジェクト**（複数ページ）では、4つの形式すべてを `design.md` の Exports セクションにインラインで埋める。ユーザーが必要なものをコピーする。
3. **Tailwind プロジェクト**（プリフライトで検出）では、加えて Tailwind `@theme` ブロックをビルド出力に表示し、ユーザーが貼る場所を知らせる（通常 `app/globals.css` 等）。

複数ページ システムにアップグレードしない限り、ユーザーは `design.md` からコピーできるので、単一ページ プロジェクトで tokens.json や shadcn 変数を一斉に出力しない。
