# インタラクションと状態

すべてのインタラクティブ要素には8つの状態がある。AI 生成 UI のほとんどは2つ（default、hover）だけスタイリングし、残りを忘れる。そこでインターフェイスが壊れる。

## 8つの状態

| 状態 | いつ | 扱い |
| --- | --- | --- |
| Default | 安静時 | 基本スタイル |
| Hover | ポインタが乗る（`@media (hover: hover)` 内のみ） | 小さなシフト: 色、1px の translate、控えめなボーダー |
| Focus | キーボードまたはプログラム的フォーカス | 可視リング、`:focus-visible` |
| Active / Pressed | 押下中 | 沈み込む: より暗く、translate(0 1px) |
| Disabled | インタラクティブでない | 不透明度低下（0.5）＋ `cursor: not-allowed` ＋ `aria-disabled` |
| Loading | 処理中 | インライン スピナーまたはプログレス、ラベルは可読のまま |
| Error | 失敗状態 | 赤ボーダー、エラー アイコン、メッセージ、`aria-invalid` |
| Success | 完了 | 緑のチェック、確認、オートディスミス |

本番要素のいずれかでこれらが欠けているなら、その要素は未完成。

## フォーカスリング

常時、すべてのインタラクティブ要素に可視。ほとんどのブラウザのデフォルトのフォーカスリングで十分だが、カスタムの方がよい。

```css
:focus { outline: none; }
:focus-visible {
  outline: 2px solid var(--color-focus);
  outline-offset: 2px;
  border-radius: inherit;
}
```

要件。

- 2–3 px、要素とページ両方に対して ≥ 3:1 のコントラスト。
- 要素から 2 px オフセット。
- `:focus-visible` を使う。`:focus` ではない。キーボード限定にする。
- 置換なしで `outline: none` を絶対にしない。`outline: none` で他のフォーカス スタイルなしは最頻出のアクセシビリティ バグで、即時の監査失敗。

## ヒットターゲット

タッチで届く要素は最低 44×44 CSS px。視覚サイズを変えずにヒットターゲットを広げるには padding か `::before` オーバーレイ。

```css
.icon-btn {
  position: relative;
}
.icon-btn::before {
  content: "";
  position: absolute;
  inset: -12px;
}
```

## フォーム

- ラベルは入力の上、可視。プレースホルダをラベル代わりにしない。
- プレースホルダはフォーマットを示すもので、指示ではない。`Placeholder: 01 Jan 2026` であり `Placeholder: Enter your birth date` ではない。
- ヘルパー テキストは入力の下。エラー テキストはヘルパー テキストを置換する。
- バリデーションは **blur** で行う。キーストロークごとには行わない。フィールドが一度 blur されたら（"touched" パターン）、以降は変更時に再バリデーション。
- エラーメッセージ: (1) 何が壊れたか、(2) なぜ、(3) どうするか。可能なら1文。
- エラーは `aria-describedby` で関連付ける。フィールドに `aria-invalid="true"` を設定する。
- 必須フィールドは `aria-required` でマークし、色だけでマークしない。
- 送信ボタンは、フォームが既知の無効状態かインフライト状態のときのみ無効化する。アイドル時に無効化しない。

## 入力フィールドの状態 — 網羅チェックリスト

「ほぼ正しい」UI が最も負ける場所。default ＋ hover の2状態しか持たず、focus で border-width が異なる入力フィールドは、デフォルト設定画面のように読める。幾何がシフトし、目が気付き、ページがチューニング不足に感じる。テキスト input、textarea、select、combobox はすべて下記を満たす。

### レイアウトシフトなしの法則

**ボーダー太さは全状態で一定。** default · hover · focus · error · disabled で `border-width` の値は変えない。focus でのレイアウトシフトは痕跡。状態変化は `background-color`、`outline`、`box-shadow` に。`border-width` には行かない。

```css
.input {
  border: 1px solid var(--color-rule-2);   /* 1px、常に。全状態 */
  outline: 2px solid transparent;          /* フォーカス リング用の予約スロット。活性化時のシフトなし */
  outline-offset: 1px;
}
```

outline を 2 px で透明から始めると、フォーカス リングが現れる時点でボックス幾何は既に正しい。レイアウトシフトなし、ペイントスラッシュなし。

### 状態別レシピ

| 状態 | 扱い | なぜ |
| --- | --- | --- |
| **Default** | `border: 1px solid var(--color-rule-2)` · `background: var(--color-paper)` · プレースホルダは `var(--color-muted)` | 可視のフィールド、読める空シグナル |
| **Hover** | `background: var(--color-paper-2)`（paper より 4–6 % 暗い） · ボーダーは変えない | 控えめな背景シフト、ボーダー フラッシュなし。ボーダー色だけの変化は見逃せる。 |
| **Focus** | `outline: 2px solid var(--color-focus)` · `outline-offset: 1px` · ボーダーは `var(--color-ink-2)` に深まってよいが幅は 1 px のまま | outline がフォーカス シグナル、アニメーションしない、要素 AND ページに対し ≥ 3:1 のコントラスト。 |
| **Active / typing** | focus と同じ。「typing」状態を別に作らない。 | focus が既に「ここがアクティブ」を語る。第2のシグナルはノイズ。 |
| **Filled** | default と同じ。値が状態を担う。空との視覚区別が欲しければ控えめな ink-2 ボーダーを足す。 | ユーザーのコンテンツとスタイル付き chrome の変化で戦わない。 |
| **Disabled** | `opacity: 0.55` · `cursor: not-allowed` · プレースホルダ `var(--color-rule-2)` · `aria-disabled="true"` · `tabindex="-1"` | 3つの独立シグナル（不透明度 ＋ カーソル ＋ 色）。単一チャネルに全負荷を載せない。 |
| **Error** | `border-color: var(--color-error, oklch(58% 0.20 25))` · ヘルパー テキストをエラー メッセージで置換 · `aria-invalid="true"` · 右端に小さな ⚠ グリフ | ボーダー色の反転は OK。ヘルパー テキストと aria もシグナルするから。色だけにしない。 |
| **Success** | 控えめなアクセント色ボーダー（既定より 3 % 高い彩度） · 小さな ✓ グリフ · ユーザーが再編集したら自動クリア | 静か。難しかった成功でない限り祝祭は要らない。 |
| **Loading**（検証中、非同期） | 右端に標準グリフ スロットを置換するインライン スピナー · フィールドは編集可能のままだが submit は無効 | フィールドからユーザーを締め出さない。打った内容を直したいかもしれない。 |

### 高さとリズム

- **入力高 = ボタン高。** 44 px のボタンと 38 px の入力が混じるページは未チューニングに感じる。1つの基準高（44 px がタッチ ターゲットの床）を選び、すべての入力 AND 隣接ボタンに適用。
- **縦パディング = `(高さ − line-height-px) / 2`。** マジック ナンバーなし。
- **右端スロットを予約。** すべての入力に約 24 px の右端スロットを、任意のクリア ボタン、エラー グリフ、ローディング スピナー用に予約。未使用ならスロットは空。アイコン出現時にリフローしない。

### ラベル、ヘルパー、エラー

- **ラベルは入力の上**、4–8 px のギャップ。インラインにしない（プレースホルダ＝ラベルは痕跡）。
- **ヘルパー テキストは入力の下**、約 4 px のギャップ。ラベルと同じ `font-size`、視覚ウェイトは低め。
- **エラーはヘルパーを置換** — 同じ位置、同じサイズ、エラー色。同時に両方は出さない（バリデーション時の縦ジャンプの原因）。
- **ヘルパーは安定した高さ。** 空のときも1行分の高さを予約し、エラーが現れてもページが下に押されない。CSS: ヘルパー コンテナに `min-height: 1lh`。

### Don't list

- 状態間で `border-width`、`padding`、`height` をトランジションしない。必ずレイアウト シフト。
- フォーカス リングの `opacity` や `transform` をトランジションしない。フォーカスは即時。
- ホバー効果を `@media (hover: hover)` の中に置く — いや、置く。タッチ ユーザーが状態に閉じ込められないように。
- 「待って、ロード中」を示すためにフィールドを disabled にしない。loading 状態にしてフィールドは編集可能のまま。
- `:focus` で `cursor` を変えない。ポインタは既にビーム。戦わない。
- 明示的な置換なしで focus に `outline: none` を使わない。

### 特定コントロールのオーバーライド

- **Textarea.** input と同じルール、加えて `resize: vertical`（`none` も `both` も小さい textarea には不可）、複数行 UX のため `min-height: 6rem`。
- **Select.** カスタム スタイルの `<select>` はネイティブの a11y（キーボード、スクリーン リーダー）を複製できる場合のみ。できないならネイティブのままラッパーをスタイリング。
- **チェックボックス／ラジオ。** モダン ブラウザでは `accent-color: var(--color-accent)` で安価で正しいスタイル。デザインが要求するときのみカスタムを作る。カスタム時もフォーカス リングは 1 px outline-offset。
- **トグル／スイッチ。** これはチェックボックス。同じ a11y ルール。視覚デザインで契約は変わらない。
- **Range / slider.** thumb がフォーカス状態を得る。トラックではない。視覚サイズが小さくても thumb のヒット ターゲットは ≥ 44 px（透明拡張を使う）。
- **File input.** 常にスタイル付き label でラップ。ネイティブの `<input type="file">` はスタイル不可。label がサーフェス。
- **Combobox / search.** リストボックスは下、`aria-expanded` が visibility を反映、矢印キーで循環、Enter で選択、Escape で閉じる。リストボックスはページ コンテンツを押さない（`position: absolute` ＋親 `position: relative`）。

## モーダルとオーバーレイ

- ネイティブの `<dialog>` 要素を使う。フォーカス トラップ、Escape で閉じる、`::backdrop` スタイリングを無料で扱う。
- モーダル背後のページ コンテンツには `inert` を設定し、タブ順が漏れないようにする。
- 閉じる条件: Escape キー、バックドロップ クリック、明示的な閉じるボタン。
- 最初のフォーカスは閉じるボタンではなく最初のインタラクティブ要素へ。

## ドロップダウン、ツールチップ、ポップオーバー

- Popover API（`popover` 属性）を使う。light-dismiss、stacking、Escape を無料で扱い、すべてのモダン ブラウザで動く。
- 利用可能なら CSS Anchor Positioning でポジショニング。フォールバックは `position: fixed` ＋ `getBoundingClientRect()`。
- ドロップダウンを `overflow: hidden` のコンテナ内に escape なしで置かない。クリップされる。
- ビューポート端に近づいたら反転。

## 確認より Undo

- 可逆アクションは確認ダイアログを飛ばす。実行する。Undo ボタン付きのトーストを 5–10 秒表示する。
- 破壊的で不可逆なアクション（アカウント削除、テーブル削除）には確認を残す。OK クリックではなく、破壊対象の名前をユーザーにタイプさせる。

## ローディングと空状態

- 形状が予測可能なコンテンツ（リスト、カード、テーブル）には **スケルトン** スクリーン、スピナーより優先。
- ボタン内状態には **インライン スピナー**。ラベルを置換、横に足さない。
- **空状態** には常に: イラストかアイコン（小さく）、なぜ空かを説明する1行、修正アクション。
- 文脈なしの汎用 "No results" を出さない。

## 禁止

- プレースホルダ＝ラベル。
- ホバー専用機能（タッチ ユーザーはホバーできない）。
- 置換なしでフォーカス リングを削る。
- 低リスク アクションの確認ダイアログ。
- 44 px 未満のタッチ ターゲット。
- インタラクティブ要素のカスタム カーソル。
- なぜ無効かの説明がない disabled 要素。
- 色だけのエラー状態。
- スケルトンがレイアウトを示せるところでのスピナー。

---

## コントラスト規律

Hallmark 出力は出荷前にスロップテストのゲート 46–50 を通すこと。ページ上の全 `(color, background-color)` ペアのコントラストを計算する。Hallmark 出力がつまずく典型的な失敗。

1. **反転サーフェス上のテキスト。** `.section--ink { background: var(--color-ink); }` がサーフェスを暗に反転、ネストしたテキストは `color: var(--color-ink)` を継承 → ink-on-ink。修正: 暗 `background` を設定するルールは同じルールで `color: var(--color-paper)` も設定する。
2. **アクセント塗りの上のボタン テキスト。** `background: var(--color-accent); color: white;` — だが白が 4.5:1 を満たすのは `--color-accent` が十分暗いときだけ。代わりに `var(--color-accent-ink)` を使う。テーマが ≥ APCA Lc 60 を保証している。
3. **色付き紙の上のミュート テキスト。** `color: var(--color-muted); background: var(--color-paper-3);` — どちらも中明度で 4.5:1 を割ることが多い。`--color-neutral`（暗め）を使うか、背景を `--color-paper` に持ち上げる。
4. **アクセント色ボタン上のフォーカス リング。** ボタン塗りが `--color-accent` のときの `outline: 2px solid var(--color-focus);` — `--color-focus = --color-accent` だとリングが消える。コントラスト ペアを使う: `--color-focus` を要素 AND ページに対して ≥ 3:1 のコントラストを持つ色に設定。

### 計算

ページが実際にレンダリングする `(text-colour, background-colour)` ペアごとに。

- **APCA Lc**（推奨、知覚的）または **WCAG 2.1 ratio** を走らせる。
- プリチェック: OKLCH の両方で `|L_a − L_b| < 50 %` ならフル チェックを促す。
- 本文テキストは **APCA Lc ≥ 60** ≈ WCAG 4.5:1 で通る。
- 大きいテキスト／フォーカス リング／アイコンは **APCA Lc ≥ 45** ≈ WCAG 3:1 で通る。

### トークン契約

すべてのテーマは `--color-accent-ink` を定義する必要がある。`--color-accent` がテキストを乗せたサーフェスを塗るときに使うテキスト色。accent-ink 色はテーマ構築時にアクセントに対して ≥ APCA Lc 60 で検証されている。`background: var(--color-accent)` を使う Hallmark コードは `color: var(--color-accent-ink)` も設定する。ハードコードの `color: white` にフォールバックするのは痕跡 — テーマのアクセントが明色である可能性があり、白 on 明は bug。

### サーフェスが反転するとき

ルール: **`background-color` をオーバーライドするルールは適切な `color` も指定する。** サーフェス反転クラスで継承に頼らない。例。

```css
/* 誤り — テキストは color: var(--color-ink) を継承、セクションは暗、ink-on-ink */
.section--manifesto { background: var(--color-ink); }

/* 正 */
.section--manifesto {
  background: var(--color-ink);
  color: var(--color-paper);
}
```

テーマ別オーバーライド `[data-theme="manifesto"] .vs__col:first-child { background: var(--color-ink); }` も同様 — 同時に `color: var(--color-paper)` を設定するか、親で宣言して子孫に明示的に継承させる。
