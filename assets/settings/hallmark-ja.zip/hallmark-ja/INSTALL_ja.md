# Hallmark（日本語版）インストール手順

Anti-AI-slop デザインスキル。AI コーディングアシスタントが生成する UI を「生成物っぽさ」から脱却させるためのスキル。原典は [nutlope/hallmark](https://github.com/nutlope/hallmark) v1.0.0。

## 動作確認済みエージェント

Claude Code、Cursor、Codex、Cline、OpenCode、Gemini CLI、Continue、GitHub Copilot、Warp、Kiro CLI、Antigravity、Hermes Agent、OpenClaw

## Windows でのインストール

プロジェクトローカルに置く場合:

```powershell
Expand-Archive -Path hallmark-ja_YYYYMMDD.zip -DestinationPath .
mkdir .\.agents\skills\ -Force
Move-Item .\hallmark-ja .\.agents\skills\hallmark
```

Claude Code でグローバル利用する場合:

```powershell
Expand-Archive -Path hallmark-ja_YYYYMMDD.zip -DestinationPath $env:USERPROFILE\.claude\skills\
Rename-Item $env:USERPROFILE\.claude\skills\hallmark-ja $env:USERPROFILE\.claude\skills\hallmark
```

## macOS でのインストール

プロジェクトローカル:

```bash
unzip hallmark-ja_YYYYMMDD.zip
mkdir -p .agents/skills
mv hallmark-ja .agents/skills/hallmark
```

Claude Code グローバル:

```bash
unzip hallmark-ja_YYYYMMDD.zip -d ~/.claude/skills/
mv ~/.claude/skills/hallmark-ja ~/.claude/skills/hallmark
```

## 使い方

Hallmark には標準動作と 3 つの動詞コマンドがある。

| 呼び出し方 | 動作 |
|---|---|
| （指定なし） | 新規ページ・アプリの設計依頼として標準フローを実行 |
| `hallmark audit <対象>` | 対象を読み、アンチパターンに照らして改善リストを返す。編集はしない |
| `hallmark redesign <対象>` | 既存実装の境界内で、視覚構造を再設計 |
| `hallmark study <URL／スクショ>` | 参照デザインから DNA（マクロ構造・アーキタイプ・タイポ・配色）を抽出 |

詳細は `SKILL.md` を読む。各リファレンスは `references/` 配下。

## 翻訳について

- 翻訳バージョン: 1.0.0-ja（原典 v1.0.0 ベース）
- 翻訳日: 2026-05-21
- 翻訳方針: スキル本体 SKILL.md と全リファレンスを日本語化。コードブロック・識別子・URL・コンポーネント ID（`h1-marquee` 等）は原文維持
- 原典マーケティングサイト（`site/`）は本パッケージから除外

ライセンスは原典に準拠（`LICENSE` 参照）。
