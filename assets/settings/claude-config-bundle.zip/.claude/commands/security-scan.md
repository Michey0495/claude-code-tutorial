---
description: ハードコードされた秘密情報・脆弱な依存・OWASP Top 10 に該当する実装パターンを検出する。security-auditor サブエージェントに委譲する。
---

# /security-scan

`security-auditor` Subagent に委譲して、リポジトリ全体のセキュリティ観点レビューを取得します。コミット前というより、フェーズ完了時のチェックポイント用です。

## 実行フロー

1. `security-auditor` Subagent を起動
2. 以下の観点でスキャンを依頼
   - API キー・パスワード・接続文字列のハードコード
   - SQL インジェクション可能性（生 SQL 連結、文字列フォーマット）
   - XSS 対策不足（フロント側の `dangerouslySetInnerHTML` 等）
   - 認可漏れ（本研修では認証なしだが、IDOR 的なパス指定の検証）
   - 依存ライブラリの既知脆弱性（`pip list` と `npm list` の結果から）
   - ログへの機密情報漏えい
   - 例外メッセージへの内部情報露出
3. 検出結果を CRITICAL / MAJOR / MINOR で分類して返す

## 期待される出力

```
[security-scan] スキャン対象: 全リポジトリ
[security-auditor] 完了: 検査ファイル 47 / 検出 3

CRITICAL (1):
  backend/app/services/llm_client.py L12:
  ANTHROPIC_API_KEY を環境変数から読まず、ハードコードされた文字列を fallback としています。
  影響: リポジトリが流出した際に API キーが露出
  修正: ハードコード値を削除し、未設定時は明示的な ValueError を投げる

MAJOR (1):
  backend/app/repositories/risk_repository.py L34:
  WHERE 句に `f"... WHERE pm_name = '{pm_name}'"` の文字列連結があります。
  影響: SQL インジェクション
  修正: SQLAlchemy の bindparam または ORM フィルタを使う

MINOR (1):
  frontend/src/components/RiskDetail.tsx L67:
  `dangerouslySetInnerHTML` で markdown を直接埋め込んでいます。
  影響: 信頼できないテキストでの XSS
  修正: react-markdown のような検証済みパーサに置き換える

依存ライブラリ脆弱性: 検出なし
```

## 使用上の注意

- Subagent 経由で実行し、親コンテキストにスキャン結果を持ち込まない
- API キーが本物だった場合は、検出後すぐにキーをローテートする
- 偽陽性が出た場合は、該当行に `# security-scan: ignore` コメントを付ける（Subagent はそれを読んでスキップする）
