---
description: ステージ済みの変更（git diff --cached）を CLAUDE.md と DESIGN.md の規約に照らしてレビューする。code-reviewer サブエージェントに委譲する。
---

# /review-changes

`git diff --cached` の差分を Claude Code 単独で読まず、`code-reviewer` Subagent に委譲してレビューを取得します。コミット直前の自己レビュー用です。

## 実行フロー

1. `git diff --cached --stat` で対象ファイルを把握
2. ステージ済みファイルがなければ「対象なし」で終了
3. `code-reviewer` Subagent を起動。差分全体と関連する CLAUDE.md・DESIGN.md・docs/api-spec.md を渡す
4. Subagent から「critical / major / minor / info」分類のフィードバックを受け取る
5. critical / major があればコミット前に修正することを推奨する旨を表示

## 期待される出力

```
[review-changes] 対象: 3 files / +124 -18
  backend/app/api/risks.py
  backend/app/services/risk_service.py
  docs/api-spec.md

[code-reviewer] レビュー完了

CRITICAL: なし
MAJOR (1):
  backend/app/api/risks.py L45: Repository を経由せず直接 SQLAlchemy session を使っています。
                                CLAUDE.md のレイヤー方針に違反します。
                                修正: app/repositories/risk_repository.py に list_by_pm を追加し、サービス経由で呼び出してください。

MINOR (2):
  backend/app/services/risk_service.py L18: 関数名 `get_by_pm` よりも `list_by_pm` が一覧返却の慣例に沿います。
  docs/api-spec.md L120: クエリパラメータの説明に「任意」マークが抜けています。

INFO (0): なし

このまま commit すると CLAUDE.md 違反が残ります。修正後に /review-changes を再実行してください。
```

## 使用上の注意

- 親コンテキストを汚さないため必ず Subagent 経由で実行する
- レビュー対象は staged のみ。working tree の変更は対象外
- 巨大な diff（500 行超）の場合は Subagent 内でファイル単位に分割される
