---
description: 新規 API エンドポイントを追加する。仕様書、ルーター、サービス、リポジトリ、テストを一気通貫で作成し、最後に api-spec-checker で整合性を確認する。
argument-hint: <method> <path> [概要]
---

# /add-endpoint

新規エンドポイントを追加するワンショットコマンド。CLAUDE.md のレイヤー方針に沿って、仕様書とコードを同時に整えます。

## 引数

- `$1`：HTTP メソッド（GET / POST / PUT / DELETE）
- `$2`：URL パス。例：`/api/risks/by-pm/{pm_name}`
- `$3`：概要（任意、1 行）

## 実行フロー

1. 既存仕様（`docs/api-spec.md`）と既存実装（`backend/app/api/`）を読み、命名・パターンを把握
2. 仕様書に新規エンドポイント節を追加（リクエスト・レスポンス・エラーコード）
3. `backend/app/schemas/` に Pydantic スキーマを追加
4. `backend/app/repositories/` に DB アクセス関数を追加（必要に応じて）
5. `backend/app/services/` にビジネスロジックを追加
6. `backend/app/api/` のルーターに登録
7. `backend/tests/api/` にテストケースを追加（正常系 1 + 異常系 1〜2）
8. `api-spec-checker` Skill で整合性を確認
9. `pytest backend/tests/api/test_<resource>.py` を実行

## 期待される出力

```
[add-endpoint] 仕様追加: GET /api/risks/by-pm/{pm_name}
[add-endpoint] スキーマ: backend/app/schemas/risk.py に RiskByPmResponse を追加
[add-endpoint] リポジトリ: list_risks_by_pm を追加
[add-endpoint] サービス: get_risks_by_pm を追加
[add-endpoint] ルーター: backend/app/api/risks.py に登録
[add-endpoint] テスト: backend/tests/api/test_risks.py に 3 ケース追加
[api-spec-checker] 仕様と実装の差分なし
[pytest] 3 passed
```

## 使用上の注意

- メソッド・パスの組み合わせが既存と重複する場合は、追加前にエラーで停止する
- レイヤー間の依存方向（api → service → repository → model）を必ず守る
- パスパラメータの型は `int` か `str` に限定。enum を直接受けない（service で変換する）
- 1 コマンドで複数エンドポイントを追加しない（1 PR 1 機能）
