---
description: ヒアリング起こしを取り込んで Risk テーブルに登録する。transcript-extractor → risk-classifier → DB 登録の一連を 1 コマンドで実行する。
argument-hint: <transcript_path> [project_id]
---

# /analyze-transcript

引数のヒアリング起こしファイルを読み、論点を抽出して Risk として登録します。

## 引数

- `$1`：ヒアリング起こしのファイルパス（必須）。例：`docs/source-materials/interview-transcripts/01_tanaka.md`
- `$2`：Project の id（省略時は MTKZ-CRM-2026 にあたる id=1）

## 実行フロー

1. `$1` を読み込む。存在しない場合はエラーを返して終了
2. `transcript-extractor` Skill で構造化 JSON を取得
3. JSON の `issues[]` 各項目を `risk-classifier` Skill に渡し、severity と category を判定
4. 結果を Risk テーブルに登録（`POST /api/projects/{id}/analyze` 相当）
5. 登録した Risk の一覧と、severity 別件数のサマリーを表示

## 期待される出力

```
[analyze-transcript] 入力: docs/source-materials/interview-transcripts/01_tanaka.md
[analyze-transcript] project_id=1 (MTKZ-CRM-2026)
[transcript-extractor] 抽出: issues=8, decisions=3, homework=2
[risk-classifier] 判定完了
  CRITICAL: 1 件
  MAJOR:    4 件
  MINOR:    2 件
  INFO:     1 件
[analyze-transcript] DB 登録完了: 8 件

新規登録 Risk:
  #21 MAJOR/SCOPE  シンガポール現地保管要請が要件定義 Sign Off 後に追加
  #22 MAJOR/QUALITY UAT 計画書未着手、英文ライター稼働確保なし
  #23 CRITICAL/COST  ベトナム子会社負担分 1,920 万円承認が 5 月取締役会まで持ち越し
  ...
```

## 失敗時のハンドリング

- ファイル不在：`SOURCE_FILE_NOT_FOUND` で終了
- transcript-extractor の出力が JSON として不正：3 回までリトライし、それでも失敗なら手動レビュー要求
- DB 登録失敗：抽出済み JSON を `tmp/analyze-{timestamp}.json` に保存してから終了

## 使用上の注意

- 実行前に backend が起動していることを確認する（http://localhost:8000/api）
- 同じファイルを 2 回実行すると重複登録になる。重複検出は本コマンドの責務外
- トークン消費の概算：1 ファイル 6,000〜10,000 字で input 4,000〜7,000 tokens、output 1,500〜2,500 tokens
