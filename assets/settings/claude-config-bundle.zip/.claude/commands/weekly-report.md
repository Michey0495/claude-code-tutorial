---
description: 直近 1 週間の Risk 検出傾向と open Risk 件数の推移を要約し、PMO 向けの週次レポートを Markdown で出力する。
argument-hint: [project_id]
---

# /weekly-report

PMO 向けの週次レポートを生成します。Risk テーブルと StatusReport を集計し、定型フォーマットの Markdown を吐き出します。

## 引数

- `$1`：Project の id（省略時は全案件横断のサマリー）

## 実行フロー

1. `GET /api/metrics/risk-trend?weeks=4` で直近 4 週の検出件数推移を取得
2. `GET /api/risks?resolved=false` で open Risk を取得
3. `GET /api/projects/{id}/reports` で直近の週次レポートを取得（引数指定時のみ）
4. 集計結果を以下のフォーマットで Markdown 化
5. `tmp/weekly-report-YYYYMMDD.md` に保存し、概要を画面に出力

## レポートフォーマット

```markdown
# 週次ヘルスチェック {YYYY-MM-DD}

## 1. サマリー

- 全案件 status：GREEN 2 / YELLOW 1 / RED 0
- open Risk：CRITICAL 3 / MAJOR 7 / MINOR 5 / INFO 2
- 直近 1 週間で新規検出：5 件、解消：3 件

## 2. CRITICAL Risk 一覧

| ID | 案件 | severity | category | 要約 | 推奨対応 |
|---|---|---|---|---|---|
| #23 | MTKZ-CRM-2026 | CRITICAL | COST | ... | ... |

## 3. 案件別ハイライト

### MTKZ-CRM-2026（status: YELLOW）

- 進行フェーズ：基本設計
- 直近の変化：シンガポール現地保管要請の影響評価着手
- 今週のアクション：Steering Committee 提案、UAT 計画書ドラフト着手者決定

## 4. 推移グラフ（テキスト版）

```
週     CRITICAL  MAJOR  MINOR  INFO
W-3    0         3      2      1
W-2    1         5      3      1
W-1    2         6      4      2
今週   3         7      5      2
```

## 5. ネクスト

- 来週の Steering Committee 提案 3 件
- UAT 計画書ドラフト着手の決定（4/30 まで）
```

## 使用上の注意

- 出力は読みやすさ優先で、過度な装飾はつけない
- 数字は API レスポンスから直接転記する。LLM に再計算させない
- Markdown 内に絵文字は使わない（DESIGN.md 準拠）
- 個人名は出すが、評価コメントは付けない（事実報告に徹する）
