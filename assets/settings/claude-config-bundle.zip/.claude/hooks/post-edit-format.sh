#!/usr/bin/env bash
# 編集後フォーマット実行 PostToolUse Hook
# 対象拡張子に応じて ruff / prettier を呼ぶ
set -euo pipefail

input=$(cat)

file_path=$(printf '%s' "$input" | python3 - <<'PY'
import json, sys
data = json.load(sys.stdin)
print(data.get("tool_input", {}).get("file_path", ""))
PY
)

if [ -z "$file_path" ]; then
  exit 0
fi

case "$file_path" in
  *.py)
    if command -v ruff >/dev/null 2>&1; then
      ruff format "$file_path" >/dev/null 2>&1 || true
    fi
    ;;
  *.ts|*.tsx|*.js|*.jsx|*.json|*.md|*.css|*.html)
    if command -v prettier >/dev/null 2>&1; then
      prettier --write "$file_path" >/dev/null 2>&1 || true
    fi
    ;;
esac

exit 0
