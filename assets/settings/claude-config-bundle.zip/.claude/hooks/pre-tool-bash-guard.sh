#!/usr/bin/env bash
# 危険な Bash 実行を検出して停止させる PreToolUse Hook
# Claude Code が標準入力で渡す JSON を読み、tool_input.command の中身を検査する

set -euo pipefail

input=$(cat)

command_text=$(printf '%s' "$input" | python3 - <<'PY'
import json, sys
data = json.load(sys.stdin)
print(data.get("tool_input", {}).get("command", ""))
PY
)

deny_patterns=(
  'rm[[:space:]]+-rf'
  'git[[:space:]]+push[[:space:]]+--force'
  'git[[:space:]]+reset[[:space:]]+--hard'
  'sudo[[:space:]]'
  'curl[[:space:]]+.*\|[[:space:]]*(bash|sh)'
  'wget[[:space:]]+.*\|[[:space:]]*(bash|sh)'
  ':(){:|:&};:'
)

for p in "${deny_patterns[@]}"; do
  if printf '%s' "$command_text" | grep -E "$p" > /dev/null; then
    cat <<EOF >&2
[pre-tool-bash-guard] 危険コマンドを検出しました。
パターン: $p
コマンド: $command_text
このコマンドは拒否します。意図がある場合は人間が直接実行してください。
EOF
    exit 2
  fi
done

exit 0
