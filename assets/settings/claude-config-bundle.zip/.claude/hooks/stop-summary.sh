#!/usr/bin/env bash
# セッション終了時に差分サマリーをログ出力する Stop Hook
set -euo pipefail

log_dir=".claude/.logs"
mkdir -p "$log_dir"
log_file="$log_dir/stop-summary-$(date +%Y%m%d-%H%M%S).log"

{
  echo "=== Stop Summary $(date -Iseconds) ==="
  echo ""
  echo "## Git status"
  git -c color.ui=never status --short 2>/dev/null || echo "(not a git repository)"
  echo ""
  echo "## Staged diff stats"
  git -c color.ui=never diff --cached --stat 2>/dev/null || true
  echo ""
  echo "## Working tree diff stats"
  git -c color.ui=never diff --stat 2>/dev/null || true
} > "$log_file"

echo "[stop-summary] $log_file に保存しました"
exit 0
