---
name: api-spec-checker
description: バックエンド実装が docs/api-spec.md に準拠しているかをチェックする。エンドポイントの追加・変更時に CLAUDE.md の規約と仕様書の両方に照らして差分を報告する。
---

# api-spec-checker

`docs/api-spec.md` と `backend/app/api/` 配下の実装を突き合わせ、仕様と実装の差分を構造化して返します。新規エンドポイント追加後の自己レビューや、PR レビュー時の事前チェックに使います。

## 入力フォーマット

```
target: <"all" | "endpoint:GET /api/projects/{id}" | "model:Risk">
```

- `all`：仕様全体を実装と突き合わせ
- `endpoint:METHOD PATH`：特定エンドポイントのみ
- `model:NAME`：特定モデルのみ（Project / Risk / Stakeholder / StatusReport）

## 出力フォーマット

```json
{
  "summary": {
    "endpoints_total": 18,
    "endpoints_match": 16,
    "endpoints_diff": 2,
    "models_total": 4,
    "models_match": 4
  },
  "diffs": [
    {
      "kind": "endpoint",
      "spec_ref": "docs/api-spec.md L88",
      "impl_ref": "backend/app/api/risks.py L42",
      "issue": "spec ではクエリパラメータ resolved=bool を受けるが、実装で未対応",
      "severity": "MAJOR"
    },
    {
      "kind": "model",
      "spec_ref": "docs/api-spec.md L40 (Risk.source_ref)",
      "impl_ref": "backend/app/models/risk.py L18",
      "issue": "source_ref のカラムが nullable=True で実装。仕様の記載は `任意` だが文中に optional マーク不在",
      "severity": "MINOR"
    }
  ],
  "missing_in_impl": [],
  "missing_in_spec": []
}
```

## チェック観点

1. URL パターン（メソッド + パス）の一致
2. クエリパラメータの一致
3. リクエストボディスキーマの一致
4. レスポンススキーマの一致（フィールド名・型・必須/任意）
5. エラーコードの一致（`docs/api-spec.md` セクション 4 と `app/exceptions.py` の対応）
6. データモデルのフィールド一致（カラム名・型・enum 値）

## severity の判定

- CRITICAL：仕様にあるエンドポイントが実装にない、またはレスポンスの主要フィールドが欠落
- MAJOR：クエリパラメータ未対応、エラーコード未定義、フィールド型違い
- MINOR：nullable 解釈の差、命名の表記揺れ
- INFO：コメント・docstring レベルの差

## 使用上の注意

- 仕様書（`docs/api-spec.md`）が信頼できる前提で動く。仕様書側の更新が漏れているケースは `missing_in_spec` で報告する
- 実装側の意図的な仕様逸脱は、CLAUDE.md または該当ファイルのコメントで明示されているかをあわせて確認する
- 出力は CI でも読める JSON 形式に固定する
