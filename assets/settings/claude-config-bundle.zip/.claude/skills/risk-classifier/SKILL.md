---
name: risk-classifier
description: 案件リスクの severity（CRITICAL / MAJOR / MINOR / INFO）と category（SCHEDULE / SCOPE / QUALITY / COST / TEAM / EXTERNAL）を判定する。Risk テーブルへの登録前段や、ヒアリング起こしから抽出した論点の重み付けに使う。
---

# risk-classifier

案件リスクの 1 行サマリー（または論点メモ）を入力として、severity と category を判定し、根拠と推奨対応を返します。

## 入力フォーマット

```
summary: <1 行の論点>
context: <任意。前提や周辺情報。300 字以内>
project_phase: <REQUIREMENT / BASIC_DESIGN / DETAIL_DESIGN / IMPLEMENTATION / UAT / RELEASE / WARRANTY のいずれか。任意>
```

## 出力フォーマット

```
severity: <CRITICAL / MAJOR / MINOR / INFO>
category: <SCHEDULE / SCOPE / QUALITY / COST / TEAM / EXTERNAL>
rationale: <50〜150 字の判定根拠>
suggestion: <50〜150 字の推奨対応>
```

## 判定基準

### Severity

- CRITICAL：本番リリース日が動く、または金銭的損失が予算の 5% 以上、または法的・コンプラ違反の懸念
- MAJOR：フェーズの遅延が 1 週間以上、または品質基準を満たせない懸念、または 1 名以上のキーマン離脱リスク
- MINOR：吸収可能な遅延、軽微な仕様調整、運用回避で済む課題
- INFO：判定保留、情報共有のみ、現時点でアクション不要

### Category

- SCHEDULE：日程・マイルストーン
- SCOPE：機能要件・非機能要件の追加削除
- QUALITY：テスト計画・品質基準・バグ
- COST：予算・工数・追加発注
- TEAM：体制・スキル・離任
- EXTERNAL：法令・監督官庁・取引先・競合

## 出力例

入力：

```
summary: シンガポール現地保管要請が要件定義 Sign Off 後に追加
context: 4 月 19 日に現地法人 IT マネージャーから本社 IT 統括部へ要請。本社データセンター集約の前提を変える要件で、判断は 6 月中旬までに必要。山田課長から「現地法令というよりはマネージャー個人の不安」とのコメントあり
project_phase: BASIC_DESIGN
```

出力：

```
severity: MAJOR
category: SCOPE
rationale: 基本設計のアーキテクチャ前提を覆す可能性があり、要件根拠が不明確なため要確認。法令違反確定なら CRITICAL に格上げ
suggestion: 6 月中旬までに現地法務部から根拠条文を取得。条文存在なら本社集約方針を維持、存在ならマルチサイト対応を基本設計に追加
```

## 使用上の注意

- 判定根拠は短く、論理が追える形で書く
- 推奨対応は具体的なアクションと期限を含める
- ヒアリング起こしの長文を直接渡さない。事前に要点 1〜2 行に圧縮する
