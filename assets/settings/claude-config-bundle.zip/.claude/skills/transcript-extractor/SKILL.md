---
name: transcript-extractor
description: ヒアリング起こしの長文から、論点・決定事項・宿題・固有名詞を構造化抽出する。risk-classifier に渡す前段として使う。
---

# transcript-extractor

ヒアリング起こし（インタビュー文字起こし）から、案件管理に必要な情報を JSON で抽出します。生のテキストを毎回 LLM に投入するとトークン消費が膨らむため、本 Skill で構造化したうえで後段の処理に渡します。

## 入力フォーマット

```
transcript_path: <docs/source-materials/interview-transcripts/ 配下のファイルパス>
project_id: <Project の id（任意）>
```

ファイル本体は実行側で読み込んでから渡します。

## 出力フォーマット

```json
{
  "session": {
    "date": "2026-04-21",
    "duration_min": 70,
    "participants": ["田中 真司", "佐藤 由香", "山田 健太郎", "安田"]
  },
  "issues": [
    {
      "summary": "シンガポール現地保管要請が要件定義 Sign Off 後に追加",
      "context": "4 月 19 日に現地法人 IT マネージャーから本社 IT 統括部へ要請",
      "speaker": "田中",
      "section_ref": "01_tanaka.md L25-L30"
    }
  ],
  "decisions": [
    {
      "summary": "Steering Committee で優先順位を上げる",
      "deadline": "2026-04-28",
      "owner": "田中"
    }
  ],
  "homework": [
    {
      "summary": "UAT 計画書のドラフト着手者を決定",
      "owner": "田中",
      "due": "2026-04-30"
    }
  ],
  "stakeholders_mentioned": [
    { "name": "山下 管理部長", "role": "シンガポール法人 管理部長", "context": "現地法務見解の窓口" }
  ]
}
```

## 抽出方針

- issues は「現状の課題」「将来のリスク」を含む。判定は risk-classifier に委ね、本 Skill では事実だけ抜く
- decisions は「その場で確定したこと」のみ。検討中・保留は含めない
- homework は「期日付きで誰かが持ち帰った宿題」
- stakeholders_mentioned は「文中に登場するが起こしの出席者ではない人」

## 抽出時の禁止事項

- 推測・解釈を加えない（「〜と思われる」は出力しない）
- 発言を要約しすぎて意味を変えない
- 数字（日付・件数・金額）は原文どおり保持
- 固有名詞（人名・組織名・システム名）は原文どおり保持
- 個人情報（電話番号・メール・住所）が出てきても出力に含めない

## 使用上の注意

- 1 ファイルあたり 6,000〜10,000 字程度を想定
- 出力は project_id と紐付けて Risk テーブル登録の前段で使う
- 複数ファイルを同時に渡さない。1 ファイルずつ処理する
